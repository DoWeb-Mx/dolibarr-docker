<?php
/* Copyright (C) 2026		Rubén Trujillo 			<ruben@doweb.mx>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Library javascript to enable Browser notifications
 */

if (!defined('NOREQUIREUSER')) {
	define('NOREQUIREUSER', '1');
}
if (!defined('NOREQUIREDB')) {
	define('NOREQUIREDB', '1');
}
if (!defined('NOREQUIRESOC')) {
	define('NOREQUIRESOC', '1');
}
if (!defined('NOREQUIRETRAN')) {
	define('NOREQUIRETRAN', '1');
}
if (!defined('NOCSRFCHECK')) {
	define('NOCSRFCHECK', 1);
}
if (!defined('NOTOKENRENEWAL')) {
	define('NOTOKENRENEWAL', 1);
}
if (!defined('NOLOGIN')) {
	define('NOLOGIN', 1);
}
if (!defined('NOREQUIREMENU')) {
	define('NOREQUIREMENU', 1);
}
if (!defined('NOREQUIREHTML')) {
	define('NOREQUIREHTML', 1);
}
if (!defined('NOREQUIREAJAX')) {
	define('NOREQUIREAJAX', '1');
}


/**
 * \file    cfdimx/js/cfdimx.js.php
 * \ingroup cfdimx
 * \brief   JavaScript file for module CFDIMX.
 */

// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) {
	$res = @include str_replace("..", "", $_SERVER["CONTEXT_DOCUMENT_ROOT"])."/main.inc.php";
}
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME'];
$tmp2 = realpath(__FILE__);
$i = strlen($tmp) - 1;
$j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
	$i--;
	$j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/../main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1))."/../main.inc.php";
}
// Try main.inc.php using relative path
if (!$res && file_exists("../../main.inc.php")) {
	$res = @include "../../main.inc.php";
}
if (!$res && file_exists("../../../main.inc.php")) {
	$res = @include "../../../main.inc.php";
}
if (!$res) {
	die("Include of main fails");
}

// Define js type
header('Content-Type: application/javascript');
// Important: Following code is to cache this file to avoid page request by browser at each Dolibarr page access.
// You can use CTRL+F5 to refresh your browser cache.
{/* <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/i18n/es.js"></script> */ }
if (empty($dolibarr_nocache)) {
	header('Cache-Control: max-age=3600, public, must-revalidate');
} else {
	header('Cache-Control: no-cache');
}

?>

	/* Javascript library of module CFDIMX */
	$(document).ready(function () {

		(function ($) {
			function initSatSelects() {
				const isEditMode = $('input[name="action"]').val() === 'edit' ||
					$('input[name="action"]').val() === 'create' ||
					$('input[name="action"]').val() === 'add' ||
					window.location.search.includes('action=edit');

				const satConfigs = {
					'options_cfdi_claveprodserv': 'prodserv',
					'options_cfdi_claveunidad': 'unidad',
				};

				$.each(satConfigs, function (fieldName, type) {
					if (isEditMode) {
						let $el = $('[name="' + fieldName + '"]');
						if ($el.length === 0) return;

						if ($el.is('input')) {
							const $newSelect = $('<select></select>').attr({
								'name': $el.attr('name'),
								'id': $el.attr('id'),
								'class': $el.attr('class')
							});
							const val = $el.val();
							$el.replaceWith($newSelect);
							$el = $newSelect;
							if (val) $el.append(new Option(val, val, true, true));
						}

						$el.select2({
							language: "es",
							placeholder: "Busque en el catálogo SAT...",
							allowClear: true,
							minimumInputLength: 1,
							width: '100%',
							ajax: {
								url: '/custom/cfdimx/ajax/select2.php',
								dataType: 'json',
								delay: 250,
								data: function (params) { return { type: type, q: params.term }; },
								processResults: function (data) { return { results: data }; },
								cache: true
							}
						});

						const currentId = $el.val();
						if (currentId && currentId !== "0") {
							fetchSingleDescription(currentId, type, function (text) {
								var newOption = new Option(text, currentId, true, true);
								$el.empty().append(newOption).trigger('change');
							});
						}

					} else {						

						const $hiddenInput = $('input[name="' + fieldName + '"]');

						if ($hiddenInput.length > 0) {
							const $cell = $hiddenInput.parent();
							const currentId = $hiddenInput.val();

							if (currentId && currentId !== "0" && !$cell.text().includes(' - ')) {

								fetchSingleDescription(currentId, type, function (text) {

									$cell.contents().filter(function () {
										return this.nodeType === 3;
									}).remove();

									$cell.prepend(text);
								});
							}
						}
					}
				});
			}

			function fetchSingleDescription(id, type, callback) {
				console.log("executing fetchSingleDescription");
				$.ajax({
					type: 'GET',
					url: '/custom/cfdimx/ajax/select2.php',
					data: { action: 'fetch_single', id: id, type: type },
					dataType: 'json'
				}).then(function (data) {
					if (data && data.length > 0) {
						callback(data[0].text);
					}
				});
			}

			$(document).ready(function () {
				setTimeout(initSatSelects, 500);
			});
		})(jQuery);

	});


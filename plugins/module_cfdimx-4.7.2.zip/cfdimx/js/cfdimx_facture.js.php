<?php
/* Copyright (C) 2026		Rubén Trujillo 			<ruben@doweb.mx>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Library javascript to enable Browser notifications
 */

if (!defined('NOREQUIREUSER')) {
	define('NOREQUIREUSER', '1');
}
if (!defined('NOREQUIREDB')) {
	define('NOREQUIREDB', '1');
}
if (!defined('NOREQUIRESOC')) {
	define('NOREQUIRESOC', '1');
}
if (!defined('NOREQUIRETRAN')) {
	define('NOREQUIRETRAN', '1');
}
if (!defined('NOCSRFCHECK')) {
	define('NOCSRFCHECK', 1);
}
if (!defined('NOTOKENRENEWAL')) {
	define('NOTOKENRENEWAL', 1);
}
if (!defined('NOLOGIN')) {
	define('NOLOGIN', 1);
}
if (!defined('NOREQUIREMENU')) {
	define('NOREQUIREMENU', 1);
}
if (!defined('NOREQUIREHTML')) {
	define('NOREQUIREHTML', 1);
}
if (!defined('NOREQUIREAJAX')) {
	define('NOREQUIREAJAX', '1');
}


/**
 * \file    cfdimx/js/cfdimx.js.php
 * \ingroup cfdimx
 * \brief   JavaScript file for module CFDIMX.
 */

// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) {
	$res = @include str_replace("..", "", $_SERVER["CONTEXT_DOCUMENT_ROOT"])."/main.inc.php";
}
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME'];
$tmp2 = realpath(__FILE__);
$i = strlen($tmp) - 1;
$j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
	$i--;
	$j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/../main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1))."/../main.inc.php";
}
// Try main.inc.php using relative path
if (!$res && file_exists("../../main.inc.php")) {
	$res = @include "../../main.inc.php";
}
if (!$res && file_exists("../../../main.inc.php")) {
	$res = @include "../../../main.inc.php";
}
if (!$res) {
	die("Include of main fails");
}

// Define js type
header('Content-Type: application/javascript');
// Important: Following code is to cache this file to avoid page request by browser at each Dolibarr page access.
// You can use CTRL+F5 to refresh your browser cache.
if (empty($dolibarr_nocache)) {
	header('Cache-Control: max-age=3600, public, must-revalidate');
} else {
	header('Cache-Control: no-cache');
}

?>

	$(document).ready(function () {

		const path = window.location.pathname;

		if (path.includes('compta/facture/card.php')) {

			var cfdi_uuid = $('input[name="options_cfdi_uuid"]').val();
			var facture_type = $('input[name="options_cfdi_tipofactura"]').val();

			if (facture_type == "FAC") {
				if (cfdi_uuid && cfdi_uuid.length > 10) {

					//remove modify button
					$(".butAction[href*='action=modif']").remove();

					//remove delete button
					$(".butActionDelete").remove();

				}
			}

			/**ORGANIZA CAMPOS CFDI */
			var camposAMover = [
				'#options_cfdi_tipofactura',
				//'#options_cfdi_metodopago',
				//'#options_cfdi_usocfdi',
				'#options_cfdi_uuid',
				//'tr[id^="trextrafieldseparatorcfdi_separator1_"]',
				//'#options_cfdi_motivo_cancel',
				//'#options_cfdi_folio_sustituto',
				//'tr[id^="trextrafieldseparatorcfdi_separator2_"]',
				'#options_cfdi_tipo_relacion',
			];

			// Buscamos la fila de referencia "Moneda" una sola vez			
			var $filaDestino = $('td:contains("Moneda")')
				.closest('table')
				.closest('tr');						

			if ($filaDestino.length) {

				camposAMover.reverse().forEach(function (selector) {
					var $filaOrigen = $(selector).closest('tr').not('.moved');

					if ($filaOrigen.length) {
						$filaOrigen.addClass('moved');
						$filaOrigen.insertAfter($filaDestino);
					}
				});

				$('.moved').each(function () {
					var idOriginal = $(this).find('[id]').attr('id');
					$('.moved').find('[id="' + idOriginal + '"]').closest('tr').not(':first').remove();
				});
			} else {
				console.warn("No se encontró la fila de destino 'Moneda'.");
			}
		}

	});

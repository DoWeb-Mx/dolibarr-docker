<?php
/* Copyright (C) 2026		Rubén Trujillo 			<ruben@doweb.mx>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Library javascript to enable Browser notifications
 */

if (!defined('NOREQUIREUSER')) {
	define('NOREQUIREUSER', '1');
}
if (!defined('NOREQUIREDB')) {
	define('NOREQUIREDB', '1');
}
if (!defined('NOREQUIRESOC')) {
	define('NOREQUIRESOC', '1');
}
if (!defined('NOREQUIRETRAN')) {
	define('NOREQUIRETRAN', '1');
}
if (!defined('NOCSRFCHECK')) {
	define('NOCSRFCHECK', 1);
}
if (!defined('NOTOKENRENEWAL')) {
	define('NOTOKENRENEWAL', 1);
}
if (!defined('NOLOGIN')) {
	define('NOLOGIN', 1);
}
if (!defined('NOREQUIREMENU')) {
	define('NOREQUIREMENU', 1);
}
if (!defined('NOREQUIREHTML')) {
	define('NOREQUIREHTML', 1);
}
if (!defined('NOREQUIREAJAX')) {
	define('NOREQUIREAJAX', '1');
}


/**
 * \file    cfdimx/js/cfdimx.js.php
 * \ingroup cfdimx
 * \brief   JavaScript file for module CFDIMX.
 */

// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) {
	$res = @include str_replace("..", "", $_SERVER["CONTEXT_DOCUMENT_ROOT"])."/main.inc.php";
}
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME'];
$tmp2 = realpath(__FILE__);
$i = strlen($tmp) - 1;
$j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
	$i--;
	$j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/../main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1))."/../main.inc.php";
}
// Try main.inc.php using relative path
if (!$res && file_exists("../../main.inc.php")) {
	$res = @include "../../main.inc.php";
}
if (!$res && file_exists("../../../main.inc.php")) {
	$res = @include "../../../main.inc.php";
}
if (!$res) {
	die("Include of main fails");
}

// Define js type
header('Content-Type: application/javascript');
// Important: Following code is to cache this file to avoid page request by browser at each Dolibarr page access.
// You can use CTRL+F5 to refresh your browser cache.
if (empty($dolibarr_nocache)) {
	header('Cache-Control: max-age=3600, public, must-revalidate');
} else {
	header('Cache-Control: no-cache');
}

?>

	/* Javascript library of module CFDIMX */
	$(document).ready(function () {

		const path = window.location.pathname;

		var isEditMode = $('input[name="action"][value="add"]').length > 0 || $('input[name="action"][value="update"]').length > 0

		// societe/card.php
		if (path.includes('societe/card.php')) {

			if (isEditMode) {

				var inputExt = $('input[name="options_cfdi_numext"]');
				var inputInt = $('input[name="options_cfdi_numint"]');
				var inputColonia = $('input[name="options_cfdi_colonia"]');
				var inputUsoCFDI = $('[name="options_cfdi_usocfdi"]');
				var inputRegimen = $('[name="options_cfdi_regimenfiscal"]');

				var rowAddress = $('textarea[name="address"]').closest('tr');
				var rowFormeJuridique = $('[name="forme_juridique_code"]').closest('tr');

				// Bloque de Dirección (Se mantiene igual)
				if (rowAddress.length && inputExt.length && inputInt.length) {
					var originalRowExt = inputExt.closest('tr');
					var originalRowInt = inputInt.closest('tr');
					var newRowNums = $('<tr>');

					newRowNums.append($('<td>').text('Núm. Exterior'));
					newRowNums.append($('<td>').append(inputExt.attr('size', 10)));
					newRowNums.append($('<td>').text('Núm. Interior'));
					newRowNums.append($('<td>').append(inputInt.attr('size', 10)));

					rowAddress.after(newRowNums);

					originalRowExt.remove();
					originalRowInt.remove();

					if (inputColonia.length) {
						var originalRowColonia = inputColonia.closest('tr');
						var newRowColonia = $('<tr>');
						newRowColonia.append($('<td>').text('Colonia'));
						var tdColoniaVal = $('<td colspan="3">').append(inputColonia.css('width', '90%'));
						newRowColonia.append(tdColoniaVal);
						newRowNums.after(newRowColonia);
						originalRowColonia.remove();
					}
				}

				// Bloque Fiscal: Ajuste de tamaño y posición
				if (rowFormeJuridique.length && inputUsoCFDI.length) {
					var originalRowUso = inputUsoCFDI.closest('tr');
					var originalRowRegimen = inputRegimen.closest('tr');

					var newRowUso = $('<tr class="morefields">');
					newRowUso.append($('<td>').text('Uso de CFDI'));

					// Ajustamos el CSS del select antes de insertarlo para asegurar consistencia
					var tdUsoVal = $('<td class="maxwidthonsmartphone" colspan="3">').append(inputUsoCFDI.css('width', 'auto'));
					newRowUso.append(tdUsoVal);

					rowFormeJuridique.after(newRowUso);

					if (originalRowRegimen.length) {
						// Forzamos el ancho del select de Régimen Fiscal también al 100%
						inputRegimen.css('width', 'auto');
						originalRowRegimen.find('td:last').attr('colspan', '3');
						newRowUso.before(originalRowRegimen);
					}

					originalRowUso.remove();
					rowFormeJuridique.remove();

					// RE-AJUSTE DE SELECT2 CON ANCHO DEFINIDO
					if ($.fn.select2) {
						// Usamos width: '100%' en la configuración de Select2 para ambos campos
						inputUsoCFDI.select2({ width: 'auto' });
						if (inputRegimen.length) {
							inputRegimen.select2({ width: 'auto' });
						}
					}
				}
			} else {

				$('[id^="societe_extras_cfdi_numext"]').closest('tr').remove();
				$('[id^="societe_extras_cfdi_numint"]').closest('tr').remove();
				$('[id^="societe_extras_cfdi_colonia"]').closest('tr').remove();
				$('[id^="societe_extras_cfdi_email1"]').closest('tr').remove();
				$('[id^="societe_extras_cfdi_email2"]').closest('tr').remove();
				$('[id^="societe_extras_cfdi_email3"]').closest('tr').remove();

				$('tr').filter(function () {
					return $(this).find('td:first').text().trim() === "Tipo de entidad comercial";
				}).hide();

				/**ORGANIZA CAMPOS CFDI */
				var moveFields = [
					'#options_cfdi_uid',
					'#options_cfdi_regimenfiscal',
					'#options_cfdi_usocfdi',
					//'#options_cfdi_email1'
				];

				// Buscamos la fila de referencia "Moneda" una sola vez			
				var $destiny = $('td:contains("Código de cliente")')
					.closest('tr');

				if ($destiny.length) {

					moveFields.reverse().forEach(function (selector) {
						var $origin = $(selector).closest('tr').not('.moved');

						if ($origin.length) {
							$origin.addClass('moved');
							$origin.insertAfter($destiny);
						}
					});

					$('.moved').each(function () {
						var idOriginal = $(this).find('[id]').attr('id');
						$('.moved').find('[id="' + idOriginal + '"]').closest('tr').not(':first').remove();
					});
				} else {
					console.warn("No se encontró la fila de destino 'Moneda'.");
				}

			}
		}
	});


# Changelog - Módulo CFDIMX

## [4.7.2] - 2026-05-12

### 🐛 Bugs Fixed

- **CFDI-71 (Precisión Decimal):** Se corrigió un error en el redondeo de los nodos de impuestos y conceptos. Anteriormente, el sistema generaba archivos inválidos en la primera descarga debido a discrepancias de decimales.

### 🚀 Nuevas Funcionalidades

- **Sistema de Rotación de Logs:** Implementación de una cola de hasta 10 archivos de respaldo (`cfdimx_events-1.log` a `-10.log`). Esto previene que un solo archivo de log crezca indefinidamente y agote el almacenamiento del servidor.
- **Descarga de Diagnóstico Masivo:** Nueva funcionalidad en la consola de administración que permite exportar todos los logs (principal + rotaciones) en un único archivo comprimido `.zip`.
- **Limpieza Integral:** Se añadió un proceso de purga que elimina tanto el log activo como sus históricos de forma segura desde la interfaz.

---

## [4.7.1] - 08-MAY-2026

### 🚀 Nuevas Funcionalidades

- **Régimen Fiscal Global:** Se agrega un nuevo campo adicional (extrafield) en facturas para gestionar el régimen fiscal en todos los países.
- **Pagos Masivos Individuales:** Se habilita la lógica para generar un complemento de pago independiente por cada factura seleccionada en el proceso masivo.
- **Cancelación Automática de CFDI:** Implementación del trigger para cancelar el CFDI del complemento de pago al eliminar el registro de pago en Dolibarr.

### 🛠️ Mejoras y Ajustes

- **Optimización de Visibilidad:** Reconfiguración del comportamiento de vista para los extrafields en facturas, terceros y plantillas de documentos.
- **Integración Documental:** Los complementos de pago ahora se asocian en la pantalla de factura y se integran automáticamente en el archivo ZIP enviado al cliente.
- **Limpieza de Interfaz:** Se eliminaron los archivos adjuntos de los complementos en la pantalla de pago para centralizar la gestión documental únicamente desde la factura.
- **Estandarización de CFDI:** Se deshabilita el uso de PDFs personalizados para todos los CFDI, asegurando el cumplimiento del estándar fiscal.

### 🐛 Bugs Fixed

- _Sin correcciones reportadas en esta versión._

---

## [4.7.0] - 23-ABR-2026

### 🐛 Bugs Fixed

- **CFDI-62 (Precisión Decimal):** Se corrigió el error en el timbrado derivado de cálculos de base de impuestos en cero. Se optimizó el redondeo aritmético para asegurar que la base gravable sea congruente con los decimales permitidos por el SAT.

### 🚀 Nuevas Funcionalidades

- 🏗️ **Notas de Crédito (Egresos):**
  - [x] **Relación Automática:** Implementación de lógica para vincular folios fiscales (UUID) de origen de forma masiva.
  - [x] **Tipos de Relación:** Integración de catálogo SAT para selección manual/automática de relación (01, 03).
  - [x] **Formato PDF:**
    - Inclusión de tabla detallada de **CFDI Relacionados**.
    - Desglose de retenciones e impuestos trasladados alineado a la normativa 2026.

---

## [4.6.2] - 15-ABR-2026

### 🐛 Bugs Fixed

- **CFDI-65 (Regeneración de PDF):** Se forzó la regeneración del documento PDF tras el proceso de cancelación. Esto asegura que la marca de agua de "CANCELADA" se visualice de inmediato sin intervención manual del usuario

---

## [4.6.1] - 10-ABR-2026

### 🚀 Nuevas Funcionalidades

- **Pruebas de Aceptación (QA):** Implementación de suite de pruebas automatizadas con Codeception para asegurar la integridad de procesos críticos (Clientes, Productos y Diccionarios SAT).
- **Mejora en Trazabilidad:** Optimización de logs internos; ahora incluyen tracking de inicio/fin de funciones y referencia de la clase ejecutora para un debug más eficiente.

### 🐛 Bugs Fixed

- **CFDI-62 (Precisión Decimal):** Corrección en el cálculo de importes con IVA incluido (ej. 999.99). Se ajustó el sistema para respetar el límite de **6 posiciones decimales** requerido por el SAT.
- **CFDI-60 (PDF):** Se habilitó la inclusión de **Documentos Relacionados** en los formatos de impresión PDF.
- **CFDI-57 (PDF):** Corrección en la persistencia de datos del receptor; ahora se imprimen correctamente desde la primera generación del documento sin requerir regeneración manual.
- **CFDI-59 (Cancelación):** Automatización de la actualización de archivos y resguardo del **Acuse de Cancelación** tras el proceso de anulación.
- **Traducciones:** Ajuste semántico en flujos de facturación; se sustituyó el término **"Abandonada"** por **"Cancelada"** para una mejor interpretación contable.
<!-- ### 🧪 Reporte de Pruebas de Regresión (QA)
| Módulo | Escenario | Resultado |
| :--- | :--- | :--- |
| **SAT** | Descarga de Diccionarios | ✅ OK |
| **Clientes** | Creación (Campos Obligatorios) | ✅ OK |
| **Clientes** | Creación (Validación de Errores) | ✅ OK |
| **Clientes** | Modificación de Datos | ✅ OK |
| **Productos** | Creación y Filtros | ✅ OK |
| **Productos** | Modificación de Datos | ✅ OK | -->

---

## [4.6.0] - 08-ABR-2026

### 🚀 Nuevas Funcionalidades

- **Cancelación de CFDI:** Se implementa el proceso completo de cancelación de facturas (aplicable a documentos sin pagos registrados).
- **Gestión desde Panel:** Solicitudes de cancelación gestionadas directamente desde la interfaz nativa de Dolibarr.
- **Acuses de Cancelación:** Descarga automática de acuses de cancelación y asociación directa al registro de la factura.
- **Etiquetado de PDF:** Evaluación dinámica del estado de la factura para la inclusión de la pleca roja de "CANCELADA" en el header del documento.

### 🛠️ Mejoras y Ajustes

- **CFDI-54:** Se agregaron validaciones de campos mínimos obligatorios en la ficha de Terceros para garantizar el timbrado.
- **Precisión en Decimales:** Optimización del flujo de cálculo en facturación para prevenir errores en límites inferiores y superiores cuando el sistema no está configurado a 6 decimales.

---

## [v4.5.1] - 06-ABR-2026 (Hotfix)

### 🐛 Bugs Fixed

- **CFDI-51** Corregido error que impedía mostrar la lista desplegable de claves para productos y servicios de la base de datos del SAT.
- **PDF-CORE** Ajuste en el cálculo de salto de página (cfdimxCheckAndAddPage) para evitar saltos prematuros con pocas partidas.

### 🔧 Ajustes Técnicos

- Reducción del margen de seguridad de página de 25mm a 15mm.
- Optimización de espacio para el bloque de totales (QR y Sellos) para maximizar el uso de la hoja.

---

## [v4.5.0] - 04-ABR-2026

### 🚀 Nuevas Funcionalidades

- **Unificación de Identidad Visual:** Se implementó el motor de renderizado de facturas validadas en el estado **Borrador**, permitiendo una previsualización idéntica al documento final antes de su emisión.
- **Soporte para Remisiones:** Los borradores de facturas no fiscales ahora adoptan el formato oficial de **Notas de Remisión**, garantizando consistencia visual en documentos administrativos.
- **Optimización de Documentos No Fiscales:** Se eliminaron dinámicamente las secciones de "Cadena Original" y "Sellos Digitales del SAT" en documentos sin efectos fiscales para evitar confusiones legales y limpiar la interfaz del PDF.

### ⚙️ Arquitectura de Datos y Estabilidad

- **Modularización de Capa JS:** Se refactorizó la lógica de JavaScript, separando las clases por módulo. Esto mejora significativamente el rendimiento de carga y facilita el mantenimiento preventivo en pantallas específicas del sistema.

---

## [v4.4.0] - 03-ABR-2026

## 🚀 Nuevas Funcionalidades

- **Motor de PDF Personalizado:** Implementación de un nuevo layout avanzado para facturación, optimizando la estructura visual y el cumplimiento de estándares.
- **Control de Desglose de Impuestos:** Se añade una nueva opción de configuración que permite decidir si se detallan o no los impuestos en el documento generado.
- **Personalización de Identidad Visual:** \* Implementación de selectores de color para encabezados, títulos y fondos de tablas.
  - Soporte para configuración de paleta de colores corporativa directamente desde el panel de administración.
- **Optimización de Rendimiento:** Rediseño del flujo de datos de la empresa mediante el uso de variables de configuración global, reduciendo las consultas a la base de datos durante la generación de documentos.

---

## [v4.3.4] - 01-ABR-2026

## 🚀 Nuevas Funcionalidades

- **Facturación (Detalle de Líneas):** Se optimiza la visualización de las partidas incluyendo la descripción personalizada del producto/servicio inmediatamente después de las fechas de periodo o duración, mejorando la lectura del PDF.

---

## [v4.3.3] - 01-ABR-2026

## 🚀 Nuevas Funcionalidades

- **Cuentas Bancarias:** Se añade un nuevo campo específico para la **CLAVE Bancaria Estandarizada (CLABE)** de 18 dígitos, optimizado para el sistema financiero en México.
- **Plantillas de Facturación:** Incorporación de campos adicionales para incluir automáticamente la relación de contrato y la referencia del cliente dentro de las notas de la factura.
- **Módulos de Facturas, Recurrentes y Contratos:** Unificación de campos extra para mejorar la trazabilidad entre los contratos y sus referencias comerciales en los documentos generados.
- **Integridad Fiscal:** Se implementa el **bloqueo automático** de las acciones de edición y eliminación para facturas que ya cuentan con sello fiscal (UUID), garantizando el cumplimiento normativo.
- **Gestión de Archivos (ZIP):** Generación automática de archivos comprimidos (.zip) que integran el XML y PDF timbrados, estableciéndolos como adjunto principal para el envío de correos electrónicos.
- **Terceros (Razón Social):** Optimización del motor de persistencia para respetar y conservar las **comillas dobles (")** dentro del nombre del cliente, asegurando la coincidencia exacta con la Constancia de Situación Fiscal.

### 🐛 Bugs

- **Generación de CFDI:** Se corrigió la lógica de obtención del **Régimen Fiscal del Emisor**; ahora se sincroniza directamente desde el motor de facturación (PAC) para evitar discrepancias con los datos del ERP.
- **Módulo de Envío:** Corrección de tipo de dato en la variable de envío de facturas; se cambió de _string_ a _booleano_ para asegurar el comportamiento correcto del flujo de salida.
- **Complementos de Pago:** Ajuste de validación lógica en el envío de complementos, corrigiendo la interpretación del estado de entrega para evitar errores de proceso.

---

## [v4.3.2] - 28-Mar-2026

## 🚀 Nuevas Funcionalidades

- **Búsqueda Inteligente (AJAX):** Se implementó búsqueda asíncrona en los campos de **Clave SAT** y **Unidad**. Ahora el sistema no se congela al editar productos, ya que busca los datos en tiempo real mientras escribes.
- **Descripciones Enriquecidas:** Al visualizar un producto, el sistema ahora muestra automáticamente el nombre completo del servicio (ej. _81111811 - Soporte_) en lugar de solo el código numérico.

## 🐛 Bugs

- **Concatenación de Fechas:** Se corrigió la lógica de descripción para incluir automáticamente el periodo de servicio (ej. _De 01/03/2026 a 28/02/2027_) al final del texto, asegurando que la información sea explícita en la factura.
- **Diseño de Interfaz:** Se acortó la etiqueta de "Registro de Identidad Tributaria" a **Reg. Id. Trib.** para evitar que se vea encima de otros campos.

### ⚙️ Arquitectura de Datos y Estabilidad

- **Optimización de Campos:** Migración de los campos de catálogo SAT de tipo `lista` a `texto (varchar)`. Esto reduce drásticamente el consumo de memoria del servidor.
- **Localización Bancaria:** El campo genérico de banco ahora está configurado específicamente como **Cuenta CLABE (18 dígitos)** para el estándar mexicano.

---

## [v4.3.1] - 27-Mar-2026

### 🐛 Bugs

- **Blindaje de Timbrado:** Se bloqueó la validación y contabilización de facturas si la API de timbrado devuelve un error, garantizando la integridad fiscal.
- **Corrección de Interfaz (Catálogos):** Se resolvió el fallo visual en la edición de Productos/Servicios; ahora las Claves SAT guardadas se muestran correctamente al abrir el registro.

---

## [v4.3.0] - 26-Mar-2026

### 🎉 Nuevas Funcionalidades

- **Complemento de Pago (REP) 2.0:** Lanzamiento de la arquitectura de Recibo Electrónico de Pago plenamente integrada.

### ⚙️ Arquitectura de Datos y Estabilidad

- **Persistencia de Versión:** Modificación del ciclo de vida del módulo para mantener los registros de versión en la base de datos tras la desactivación.
- **Sistema de Migración Robusta:** Implementación de lógica defensiva en scripts SQL (`DROP` antes de `ADD`) para prevenir errores de índices duplicados.
- **Estandarización de Prefijos:** Uso mandatorio de `llx_` en archivos SQL para garantizar la portabilidad entre diferentes instalaciones.

### 🚀 Optimización de Rendimiento

- **Indexación de Catálogos:** Creación de índices en los campos `id`, `catalogue` y `rowid` de las tablas maestras para acelerar el autocompletado AJAX.
- **Refactorización SQL:** Eliminación de redundancias en la estructura de tablas para mejorar la velocidad de escritura.

### 🐛 Bugs y Ajustes Técnicos

- **Control de Errores:** Mejora en el manejo de excepciones durante la ejecución de `ALTER TABLE` para asegurar que el botón de activación siempre responda correctamente.

---

## [v4.2.0] - 23-Mar-2026

### ✨ Nueva Regla de Cumplimiento (Compliance)

- **Normalización de Caracteres:** Transformación automática a MAYÚSCULAS en campos críticos para el SAT v4.0.

### ⚙️ Arquitectura de Datos y Automatización

- **Scripts de Migración Secuencial:** Introducción del sistema de actualizaciones automáticas basado en archivos SQL incrementales.

---

## [v4.2.0] - 23-Mar-2026

### ✨ Nueva Regla de Cumplimiento (Compliance)

- **Normalización de Caracteres:** Implementación de transformación automática a MAYÚSCULAS en campos críticos (Nombre, RFC, Receptor) para alineación estricta con los requerimientos técnicos del SAT v4.0.

### ⚙️ Arquitectura de Datos y Automatización

- **Scripts de Migración Secuencial:** Introducción de un sistema de actualizaciones automáticas basado en archivos SQL incrementales (ubicados en `/sql/`). Esto garantiza que las transiciones de versión (ej. v3.5.0 a v4.2.0) ejecuten todos los cambios estructurales de forma ordenada y sin intervención manual.
- **Auto-configuración de Visibilidad:** Configuración automática de los atributos extra (`extrafields`) para que sean visibles por defecto en los listados de Terceros y Productos al activar o actualizar el módulo.
- **Compatibilidad de Prefijos:** Optimización de scripts de base de datos para utilizar el estándar `llx_`, permitiendo que el motor de Dolibarr traduzca los prefijos dinámicamente según la configuración de cada instalación.

### 🛠️ Mejoras de Interfaz y UX

- **Corrección de Vista de Lectura:** Ajuste lógico en el frontend para asegurar que los buscadores dinámicos (AJAX) solo se rendericen en modo edición/creación. Se eliminó la aparición de inputs redundantes en las fichas de consulta.
- **Visualización Pro:** Ajuste estético de iconos y títulos en el panel de administración para una navegación más intuitiva y coherente con el core de Dolibarr.

### 📊 Diagnóstico y Rendimiento

- **Logs de Diagnóstico Optimizados:** - Reordenamiento de la salida de logs a **modo ascendente**, permitiendo una lectura cronológica natural de las peticiones y respuestas.
  - Mejora en el contraste de colores para una identificación inmediata de errores técnicos en el panel de diagnóstico.
- **Optimización AJAX (Selectores SAT):** Refactorización integral de los campos "Clave SAT" y "Clave Unidad" para maximizar el rendimiento. Se eliminó la exposición de lógica SQL en el frontend, delegando la carga de datos de forma segura al backend.

---

## [v4.1.0] - 22-Mar-2026

### ✨ Nuevas Funcionalidades (Panel de Administración)

- **Nuevo Visor de Logs en Tiempo Real:** Se añadió una pestaña dedicada de "Logs" en la configuración del módulo para monitorear eventos de timbrado y respuestas de la API sin salir de Dolibarr.
- **Descarga Directa de Diagnósticos:** Implementación de un botón de descarga segura para el archivo `cfdimx_events.log`, facilitando el envío de reportes a soporte técnico.
- **Purga de Registros:** Se integró la función de "Limpiar Log" con confirmación de seguridad para mantener el almacenamiento optimizado.

### 🛠️ Mejoras y Optimizaciones

- **Reimplentación del Motor de Logging:** Se reactivó y optimizó la escritura de eventos en la ruta estándar de documentos (`documents/cfdimx/temp/`).
- **Interfaz de Terminal Avanzada:** - El visor ahora utiliza un esquema de colores de alta intensidad (Neon) para identificar rápidamente niveles de error, información y depuración.
  - Se implementó **Word Wrap** (ajuste de línea) con sangría francesa para mejorar la lectura de tramas JSON largas.
  - El orden de visualización es ahora **descendente** (lo más reciente primero).
- **Diseño Responsivo:** El visor de logs ahora es 100% adaptable al ancho de la pantalla, evitando que líneas largas rompan la interfaz de Dolibarr.

### 🔧 Seguridad y Estándares

- **Cumplimiento de Purga Core:** La ubicación del log se alineó con los estándares de Dolibarr para permitir que las tareas programadas del sistema (Cron) identifiquen y procesen archivos temporales antiguos.
- **Control de Acceso:** Restricción estricta de las nuevas herramientas de diagnóstico solo para usuarios con permisos de Administrador.

---

## [v4.0] - 21-Mar-2026

> 📝 **Nota de versión:** Re-arquitectura integral del módulo. Depreciación del sistema basado en _triggers_ en favor de una **Plantilla Nativa de Documentos**, garantizando máxima estabilidad y compatibilidad con **Dolibarr 23**.

### 🎉 Nuevas Funcionalidades

- **Nuevo Motor de Documentos:** Implementación del modelo `pdf_cfdimx`. Integración nativa del botón "Generar" para la descarga directa de archivos PDF y XML oficiales vía API.
- **Sincronización de Entidades:** Optimización del flujo de actualización para Productos y Terceros, incorporando validación de cambios delta previa al envío.
- **Campos Fiscales Extendidos:** Integración de campos `UID` (Terceros) y `UUID` (Facturas) en el diccionario nativo para un rastreo fiscal bidireccional preciso.
- **Indexación ECM Automatizada:** Registro sistemático de comprobantes en el gestor documental de Dolibarr (`llx_documents`), habilitando la visualización inmediata en la pestaña de "Archivos vinculados".
- **Blindaje de Borradores:** Restricción de ejecución en facturas estado _Draft_, eliminando peticiones redundantes a la API y saturación de logs durante la edición de líneas.

### 🛑 Depreciado / Eliminado

- **Limpieza de Herramientas de Debug:** Se eliminan las opciones de `debugmode` y diagnóstico avanzado manuales; el módulo ahora utiliza el sistema de logs nativo de Dolibarr.
- **Simplificación de Interfaz:** Se retira la descarga de logs desde la configuración del módulo; los registros se gestionan directamente desde el servidor.
- **Módulo de Pagos (REP):** Se deshabilita temporalmente el soporte para Complementos de Pago para una futura implementación bajo la nueva arquitectura nativa.

### 🐛 Bugs

- **Resolución:** Corregido el estilo de parámetros en `setEventMessages` (cambio de `warn` a `warnings`).
- **Resolución:** Eliminación de archivos huérfanos sin extensión y corrección de duplicidad en escrituras de disco.
- **Resolución:** Solucionado el error crítico de métodos indefinidos (`_set_const`) en el proceso de activación e instalación.

---

## [v3.5] - 25-Dic-2023

### 🐛 Bugs

- **Resolución:** Corrección en la persistencia de logs de error en el sistema de archivos.
- **Resolución:** Resolución de incidencias técnicas en el proceso de registro de nuevos clientes.

---

## [v3.4] - 10-Jun-2023

### 🎉 Nuevas Funcionalidades

- **Gestión de Logs:** Implementación de descarga de registros de eventos desde el panel de configuración.
- **Métodos de Pago:** Integración del catálogo oficial de formas de pago durante la activación del plugin.
- **Complementos de Pago:** Soporte para la generación y descarga de comprobantes REP.

### 🐛 Bugs

- **Resolución:** Añadido parámetro de configuración para definir el "Lugar de Expedición".
- **Resolución:** Sincronización de la fecha de factura basada en el valor nativo del objeto Factura.
- **Resolución:** Optimización de descargas históricas condicionada a la validación de UUID.
- **Resolución:** Reducción de tráfico API actualizando terceros solo ante cambios detectados.

---

## [v3.3] - 01-May-2023

### 🎉 Nuevas Funcionalidades

- **Trazabilidad:** Implementación de seguimiento de transacciones detallado mediante archivos de registro (.log).

---

## [v3.2] - 27-May-2023

### 🎉 Nuevas Funcionalidades

- **Gestión de Clientes:** Nueva interfaz para la creación y alta de terceros en la plataforma.
- **Actualización de Clientes:** Funcionalidad para la edición de datos maestros de terceros sincronizada.

### 🐛 Bugs

- **Resolución:** Corrección de la persistencia de datos del cliente al ejecutar el proceso de timbrado.

---

## [v3.1] - 21-May-2023

### 🎉 Nuevas Funcionalidades

- **Gestión de Catálogo:** Funcionalidad para agregar y actualizar productos en la plataforma de facturación.
- **Sección Fiscal:** Incorporación de campos fiscales dedicados en la ficha de Terceros de Dolibarr.

---

## [v3.0] - 08-May-2023

### 🎉 Nuevas Funcionalidades

- **Compatibilidad:** Migración técnica para soporte oficial con Dolibarr v17.
- **Modo Diagnóstico:** Implementación de `debugmode` para análisis de errores en tiempo de ejecución.

---

## [v2.6] - 20-Jun-2022

### 🎉 Nuevas Funcionalidades

- **Ajuste Regulatorio:** Deshabilitado el servicio de validación de RFC por disposición oficial del SAT.
- **Herramientas Dev:** Integración de opciones de depuración avanzada para desarrolladores.

---

## [v2.2 a v2.5] - 2022 (Versiones de Desarrollo)

### 🎉 Nuevas Funcionalidades

- **Histórico:** Implementación de búsqueda y descarga de CFDI de ejercicios anteriores.
- **Logs de Timbrado:** Habilitación de registros específicos para el flujo de certificación fiscal.
- **Corrección v2.3:** Resolución de errores de timbrado detectados en ramas anteriores.

---

## [v2.1] - 10-Abr-2022

### 🎉 Nuevas Funcionalidades

- **Lógica de Negocio:** Control de flujo para definir naturaleza del documento (Remisión vs. Factura).
- **Categorización:** Selector de tipo de ítem para distinguir entre Productos y Servicios.

### 🐛 Bugs

- **Resolución:** Corrección en el mapeo de claves SAT asociadas a las líneas de detalle de la factura.

---

## [v1.0 a v1.1] - Ene/Feb-2022

### 🎉 Nuevas Funcionalidades

- **Lanzamiento:** Versión inicial del módulo con controles básicos de tipo de factura.

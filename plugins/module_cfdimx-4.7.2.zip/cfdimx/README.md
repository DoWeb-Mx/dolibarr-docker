# Módulo CFDI México por **DoWebMx** v4.7.2

### 🎯 Propósito

## Solución integral para la facturación electrónica en México, diseñada exclusivamente para **Dolibarr v23**. Este módulo transforma el flujo de trabajo estándar en una experiencia nativa de timbrado y gestión de documentos bajo el estándar **SAT v4.0**.

### 🚀 Características Principales

- ✅ **Timbrado y Descarga Nativa:** Generación automática de CFDI, con descarga directa de archivos PDF y XML oficiales.
- ✅ **Complemento de Pago 2.0:** Gestión completa de Recibos Electrónicos de Pago bajo la nueva arquitectura de plantillas.
- ✅ **Optimización AJAX de Alto Rendimiento:** Búsqueda inteligente en catálogos del SAT (Claves de Producto/Servicio y Unidades).
- ✅ **Rastreo Fiscal Avanzado:** Implementación de campos `UID` y `UUID` para trazabilidad técnica y contable.

---

### 🕐 Registro de Cambios Recientes

## [4.7.2] - 2026-05-12

### 🐛 Bugs Fixed

- **CFDI-71 (Precisión Decimal):** Se corrigió un error en el redondeo de los nodos de impuestos y conceptos. Anteriormente, el sistema generaba archivos inválidos en la primera descarga debido a discrepancias de decimales.

### 🚀 Nuevas Funcionalidades

- **Sistema de Rotación de Logs:** Implementación de una cola de hasta 10 archivos de respaldo (`cfdimx_events-1.log` a `-10.log`). Esto previene que un solo archivo de log crezca indefinidamente y agote el almacenamiento del servidor.
- **Descarga de Diagnóstico Masivo:** Nueva funcionalidad en la consola de administración que permite exportar todos los logs (principal + rotaciones) en un único archivo comprimido `.zip`.
- **Limpieza Integral:** Se añadió un proceso de purga que elimina tanto el log activo como sus históricos de forma segura desde la interfaz.

---

### 🛠️ Instalación Rápida

1. Inicie sesión en Dolibarr como **Superadministrador**.
2. Diríjase a **Configuración -> Módulos**.
3. Localice y habilite el módulo **CFDI México**.
4. El sistema ejecutará automáticamente las migraciones necesarias para actualizar a la última versión.

---

### ✉️ Soporte Técnico

📧 **ayuda@doweb.mx**

<?php
define('NOCSRFCHECK', 1);
define('NOTOKENRENEWAL', 1);
define('NOIPCHECK', 1);

$res = 0;
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Error: No se pudo localizar main.inc.php");

if (ob_get_level()) ob_clean();
header('Content-Type: application/json');

if ($user->id <= 0) {
	echo json_encode(array("error" => "No session"));
	exit;
}

$type   = GETPOST('type', 'alpha');
$search = $db->escape(GETPOST('q', 'alpha'));

$action = GETPOST('action', 'alpha');
$targetId = $db->escape(GETPOST('id', 'alpha'));

$table = MAIN_DB_PREFIX . "cfdimx_catalogue";

$filter = "";
switch ($type) {
	case 'prodserv':
		$filter = "catalogue='ClaveProductServ'";
		break;
	case 'unidad':
		$filter = "catalogue='ClaveUnidad'";
		break;

	default:
		echo json_encode(array("error" => "Invalid type request"));
		exit;
}

$sql = "SELECT id, name FROM " . $table;
$sql .= " WHERE " . $filter;

if ($action == 'fetch_single' && !empty($targetId)) {
	$sql .= " AND id = '" . $targetId . "'";
} elseif (!empty($search)) {
	$sql .= " AND (name LIKE '%" . $search . "%' OR id LIKE '%" . $search . "%')";
}

$sql .= " ORDER BY name ASC";
$sql .= " LIMIT 20";

$resql = $db->query($sql);
$out = array();

if ($resql) {
	while ($obj = $db->fetch_object($resql)) {
		$out[] = array(
			'id'   => $obj->id,
			'text' => $obj->name
		);
	}
	$db->free($resql);
} else {
	echo json_encode(array("error" => $db->lasterror(), "sql" => $sql));
	exit;
}

echo json_encode($out);
exit;

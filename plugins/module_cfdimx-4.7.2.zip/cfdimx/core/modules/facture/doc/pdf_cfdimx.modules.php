<?php
require_once DOL_DOCUMENT_ROOT . '/core/modules/facture/modules_facture.php';
require_once DOL_DOCUMENT_ROOT . '/core/lib/files.lib.php';

//class pdf_cfdimx extends ModelePDFFactures
class pdf_cfdimx extends ModelePDFFactures
{
	public $db;
	public $name = "cfdimx"; // Nombre que aparecerá en el combo de plantillas
	public $description = "Plantilla para PDF de CFDI";

	public function __construct($db)
	{
		$this->db = $db;
	}

	/**
	 * Esta función se dispara cuando el usuario da clic en "GENERAR"
	 */
	public function write_file($object, $outputlangs, $srceditetd = '', $hidedetails = 0, $hidedesc = 0, $hideref = 0)
	{
		require_once DOL_DOCUMENT_ROOT . '/custom/cfdimx/class/CustomPdfAdapter.class.php';
		dol_include_once('/cfdimx/lib/cfdimx.lib.php');
		dol_include_once('/cfdimx/lib/cfdimx.pdf.lib.php');

		cfdimx_log("write_file start", LOG_INFO);

		global $db, $conf;

		$int = 0;

		$adapter = new CustomPdfAdapter($this->db);
		$cfdiFactura = $adapter->getFormattedData($object);

		$customPDF = (isset($conf->global->CFDIMX_CUSTOMPDF)) ? true : false;
		$sPath = DOL_DATA_ROOT . "/facture/{$cfdiFactura->ref}/";
		$sFile = $cfdiFactura->ref;
		$isDownloaded = false;

		cfdimx_log("customPDF : " . ($customPDF) ? '1' : '0', LOG_DEBUG);

		cfdimx_log("Document Status : {$cfdiFactura->status}", LOG_DEBUG);
		// ==========================================
		// FASE 1: PROCESAR LA FACTURA PRINCIPAL
		// ==========================================

		if ($cfdiFactura->status > 0) {
			cfdimx_log('Downloading facture ' . $cfdiFactura->ref, LOG_INFO);

			if (cfdimxDownloadFile($cfdiFactura, 'xml', $sPath, $sFile)) {
				cfdimxSyncXmlData($object, $sPath . $sFile . ".xml");

				cfdimx_log("Download for " . $cfdiFactura->uuid . " XML is completed", LOG_INFO);
				$isDownloaded = true;
			} else {

				cfdimx_log("Download for " . $cfdiFactura->uuid . " XML has failed", LOG_ERR);
			}
		}

		if ($customPDF || $cfdiFactura->status == 0) {
			cfdimx_log('Creating PDF ' . $cfdiFactura->ref, LOG_INFO);
			cfdimxCustomPdf($cfdiFactura, $sPath, $sFile);
			$isDownloaded = true;
		} else {

			if (cfdimxDownloadFile($cfdiFactura, 'pdf', $sPath, $sFile)) {

				cfdimx_log("Download for " . $cfdiFactura->uuid . " PDF is completed", LOG_INFO);
				$isDownloaded = true;
			} else {

				cfdimx_log("Download for " . $cfdiFactura->uuid . " PDF has failed", LOG_ERR);
			}
		}

		// ==========================================
		// FASE 2: DESCARGAR ACUSES (Tu lógica actual)
		// ==========================================		
		cfdimx_log('Downloading Ack ' . $cfdiFactura->ref, LOG_INFO);
		if ($cfdiFactura->status == 3 && $cfdiFactura->tipoFactura == "FAC") {

			cfdimx_log("{$cfdiFactura->ref} - {$cfdiFactura->uuid}", LOG_DEBUG);

			cfdimxDownloadAck($cfdiFactura->ref, $cfdiFactura->uuid);
			$isDownloaded = true;
		} else {

			cfdimx_log('Ack not found for ' . $cfdiFactura->ref, LOG_INFO);
		}

		// ==========================================
		// FASE 3: PROCESAR PAGOS RELACIONADOS
		// ==========================================
		cfdimx_log("Checking payment for invoice", LOG_INFO);
		if ($object->status > 0) {

			cfdimx_log("Checking payment for invoice " . $object->ref, LOG_DEBUG);

			$sql  = ' SELECT df.rowid idInvoice, df.ref AS invoice, df.fk_soc, dp.ref AS payment, dpf.fk_paiement idPayment, dpe.cfdi_uuid ';
			$sql .= ' FROM ' . MAIN_DB_PREFIX . 'facture df';
			$sql .= ' LEFT JOIN ' . MAIN_DB_PREFIX . 'paiement_facture dpf ON dpf.fk_facture=df.rowid';
			$sql .= ' LEFT JOIN ' . MAIN_DB_PREFIX . 'paiement dp ON dp.rowid=dpf.fk_paiement';
			$sql .= ' LEFT JOIN ' . MAIN_DB_PREFIX . 'paiement_extrafields dpe ON dpe.fk_object = dpf.fk_paiement';
			$sql .= ' WHERE dpe.cfdi_uuid IS NOT NULL AND df.rowid =' . $object->id;
			$sql .= ' ORDER BY dpf.fk_paiement;';

			$result = $db->query($sql);

			cfdimx_log("checking payments for {$object->ref}", LOG_INFO);

			if ($result && $db->num_rows($result) > 0) {

				cfdimx_log("{$object->ref} have payments", LOG_INFO);

				$payments = array();
				while ($tmp = $db->fetch_object($result)) {
					$payments[] = $tmp;
				}

				foreach ($payments as $payment) {

					$pagoObj = new Paiement($db);
					$pagoObj->fetch($payment->idPayment);
					$pagoObj->fetch_optionals();
					$pagoObj->socid = $payment->fk_soc;

					$cfdiPago = $adapter->getFormattedData($pagoObj);

					$sFile = $cfdiPago->ref;

					if (cfdimxDownloadFile($cfdiPago, 'xml', $sPath, $sFile)) {
						cfdimx_log("Download for " . $cfdiPago->cfdi_uuid . " XML is completed", LOG_INFO);
						$isDownloaded = true;
					} else {
						cfdimx_log("Download for " . $cfdiPago->cfdi_uuid . " XML has failed", LOG_ERR);
					}

					if ($customPDF) {

						cfdimx_log("Generation PDF for payment [{$cfdiPago->uuid}][{$cfdiPago->ref}]");

						cfdimxCustomPdf($cfdiPago, $sPath, $sFile);
						$isDownloaded = true;

						cfdimx_log("Generation PDF for payment" . $cfdiPago->uuid . " is completed", LOG_INFO);
					} else {
						if (cfdimxDownloadFile($cfdiPago, 'pdf', $sPath, $sFile)) {
							cfdimx_log("Download for " . $cfdiPago->uuid . " PDF is completed", LOG_INFO);
							$isDownloaded = true;
						} else {
							cfdimx_log("Download for " . $cfdiPago->uuid . " PDF has failed", LOG_ERR);
						}
					}
				}

				$db->free($result);
			} else {
				cfdimx_log("No payments related", LOG_INFO);
			}
		}
		// ==========================================
		// FASE 4: COMPRIMIR EN ZIP (Lo que vimos hace rato)
		// ==========================================
		if ($isDownloaded && $cfdiFactura->status > 0) {
			cfdimx_log('compressing files', LOG_INFO);

			sleep(1);

			$zip = new ZipArchive();

			$zipName = dol_sanitizeFileName($cfdiFactura->ref) . '.zip';
			$zipFullPath = $sPath . $zipName;
			cfdimx_log('zipName: ' . $zipFullPath, LOG_DEBUG);

			if ($zip->open($zipFullPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {

				// Buscamos archivos que terminen en .xml o .pdf usando llaves de expansión
				// Nota: GLOB_BRACE permite usar {a,b} para múltiples extensiones
				$files = glob($sPath . '/*.{xml,PDF,pdf,XML}', GLOB_BRACE);

				foreach ($files as $file) {

					// Verificamos que sea un archivo real y no un directorio
					if (is_file($file)) {

						// Obtenemos solo el nombre del archivo para que no cree carpetas dentro del ZIP
						$relativeName = basename($file);

						// Agregamos el archivo al ZIP
						cfdimx_log('adding file to zip', LOG_INFO);
						cfdimx_log('adding file to zip: ' . $relativeName, LOG_DEBUG);
						$zip->addFile($file, $relativeName);
					}
				}

				$zip->close();
				// Aquí podrías agregar un log o mensaje de éxito
			} else {
				// Manejo de error si no se pudo crear el archivo
				cfdimx_log("Error: No se pudo crear el archivo ZIP en " . $zipFullPath, LOG_ERR);
			}
			$int = 1;
			cfdimx_log('compressing files completed', LOG_INFO);
		}

		cfdimx_log("write_file completed", LOG_INFO);

		return $int;
	}
}

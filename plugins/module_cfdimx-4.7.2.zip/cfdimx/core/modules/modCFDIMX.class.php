<?php
/* Copyright (C) 2004-2018	Laurent Destailleur			<eldy@users.sourceforge.net>
 * Copyright (C) 2018-2019	Nicolas ZABOURI				<info@inovea-conseil.com>
 * Copyright (C) 2019-2024	Frédéric France				<frederic.france@free.fr>
 * Copyright (C) 2026		Rubén Trujillo 				<ruben@doweb.mx>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * 	\defgroup   cfdimx     Module CFDIMX
 *  \brief      CFDIMX module descriptor.
 *
 *  \file       htdocs/cfdimx/core/modules/modCFDIMX.class.php
 *  \ingroup    cfdimx
 *  \brief      Description and activation file for module CFDIMX
 */
include_once DOL_DOCUMENT_ROOT . '/core/modules/DolibarrModules.class.php';
dol_include_once('/cfdimx/lib/cfdimx.lib.php');


/**
 *  Description and activation class for module CFDIMX
 */
class modCFDIMX extends DolibarrModules
{
	/**
	 * Constructor. Define names, constants, directories, boxes, permissions
	 *
	 * @param DoliDB $db Database handler
	 */
	public function __construct($db)
	{
		global $conf, $langs;

		$this->db = $db;

		// Id for module (must be unique).
		// Use here a free id (See in Home -> System information -> Dolibarr for list of used modules id).
		$this->numero = 831221; // TODO Go on page https://wiki.dolibarr.org/index.php/List_of_modules_id to reserve an id number for your module

		// Key text used to identify module (for permissions, menus, etc...)
		$this->rights_class = 'cfdimx';

		// Family can be 'base' (core modules),'crm','financial','hr','projects','products','ecm','technic' (transverse modules),'interface' (link with external tools),'other','...'
		// It is used to group modules by family in module setup page
		$this->family = "financial";

		// Module position in the family on 2 digits ('01', '10', '20', ...)
		$this->module_position = '01';

		// Gives the possibility for the module, to provide his own family info and position of this family (Overwrite $this->family and $this->module_position. Avoid this)
		//$this->familyinfo = array('myownfamily' => array('position' => '01', 'label' => $langs->trans("MyOwnFamily")));
		// Module label (no space allowed), used if translation string 'ModuleCFDIMXName' not found (CFDIMX is name of module).
		$this->name = preg_replace('/^mod/i', '', get_class($this));

		// DESCRIPTION_FLAG
		// Module description, used if translation string 'ModuleCFDIMXDesc' not found (CFDIMX is name of module).
		$this->description = "CFDIMXDescription";
		// Used only if file README.md and README-LL.md not found.
		$this->descriptionlong = "CFDIMXDescription";

		// Author
		$this->editor_name = 'DoWebMx';
		$this->editor_url = 'https://www.doweb.mx';
		$this->editor_squarred_logo = '';					// Must be image filename into the module/img directory followed with @modulename. Example: 'myimage.png@cfdimx'

		// Possible values for version are: 'development', 'experimental', 'dolibarr', 'dolibarr_deprecated', 'experimental_deprecated' or a version string like 'x.y.z'
		$this->version = '4.7.2';
		// Url to the file with your last numberversion of this module
		//$this->url_last_version = 'http://www.example.com/versionmodule.txt';

		// Key used in llx_const table to save module status enabled/disabled (where CFDIMX is value of property name of module in uppercase)
		$this->const_name = 'MAIN_MODULE_' . strtoupper($this->name);

		// Name of image file used for this module.
		// If file is in theme/yourtheme/img directory under name object_pictovalue.png, use this->picto='pictovalue'
		// If file is in module/img directory under name object_pictovalue.png, use this->picto='pictovalue@module'
		// To use a supported fa-xxx css style of font awesome, use this->picto='xxx'
		$this->picto = 'invoice';

		// Define some features supported by module (triggers, login, substitutions, menus, css, etc...)
		$this->module_parts = array(
			// Set this to 1 if module has its own trigger directory (core/triggers)
			'triggers' => 1,
			// Set this to 1 if module has its own login method file (core/login)
			'login' => 0,
			// Set this to 1 if module has its own substitution function file (core/substitutions)
			'substitutions' => 0,
			// Set this to 1 if module has its own menus handler directory (core/menus)
			'menus' => 0,
			// Set this to 1 if module overwrite template dir (core/tpl)
			'tpl' => 0,
			// Set this to 1 if module has its own barcode directory (core/modules/barcode)
			'barcode' => 0,
			// Set this to 1 if module has its own models directory (core/modules/xxx)
			'models' => 1,
			// Set this to 1 if module has its own printing directory (core/modules/printing)
			'printing' => 0,
			// Set this to 1 if module has its own theme directory (theme)
			'theme' => 0,
			// Set this to relative path of css file if module has its own css file
			'css' => array(
				//    '/cfdimx/css/cfdimx.css.php',
			),
			// Set this to relative path of js file if module must load a js on all pages
			'js' => array(
				//'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/i18n/es.js',
				'/cfdimx/js/cfdimx.js.php',				//Global
				'/cfdimx/js/cfdimx_facture.js.php',		//Fcature
				'/cfdimx/js/cfdimx_societe.js.php',		//Thirdparty
				'/cfdimx/js/cfdimx_customer.js.php',	//Customer
				'/cfdimx/js/cfdimx_bank.js.php',		//Bank
			),
			// Set here all hooks context managed by module. To find available hook context, make a "grep -r '>initHooks(' *" on source code. You can also set hook context to 'all'
			/* BEGIN MODULEBUILDER HOOKSCONTEXTS */
			//'hooks' => array('invoicecard', 'formconfirm','addHtmlHeader'),
			/* END MODULEBUILDER HOOKSCONTEXTS */
			// Set this to 1 if features of module are opened to external users
			'moduleforexternal' => 0,
			// Set this to 1 if the module provides a website template into doctemplates/websites/website_template-mytemplate
			'websitetemplates' => 0,
			// Set this to 1 if the module provides a captcha driver
			'captcha' => 0
		);

		// Data directories to create when module is enabled.
		// Example: this->dirs = array("/cfdimx/temp","/cfdimx/subdir");
		$this->dirs = array("/cfdimx/temp");

		// Config pages. Put here list of php page, stored into cfdimx/admin directory, to use to setup module.
		$this->config_page_url = array("setup.php@cfdimx");

		// Dependencies
		// A condition to hide module
		$this->hidden = getDolGlobalInt('MODULE_CFDIMX_DISABLED'); // A condition to disable module;
		// List of module class names that must be enabled if this module is enabled. Example: array('always'=>array('modModuleToEnable1','modModuleToEnable2'), 'FR'=>array('modModuleToEnableFR')...)
		$this->depends = array();
		// List of module class names to disable if this one is disabled. Example: array('modModuleToDisable1', ...)
		$this->requiredby = array();
		// List of module class names this module is in conflict with. Example: array('modModuleToDisable1', ...)
		$this->conflictwith = array();

		// The language file dedicated to your module
		$this->langfiles = array("cfdimx@cfdimx");

		// Prerequisites
		$this->phpmin = array(7, 2); // Minimum version of PHP required by module
		// $this->phpmax = array(8, 0); // Maximum version of PHP required by module
		$this->need_dolibarr_version = array(19, -3); // Minimum version of Dolibarr required by module
		// $this->max_dolibarr_version = array(19, -3); // Maximum version of Dolibarr required by module
		$this->need_javascript_ajax = 0;

		// Messages at activation
		$this->warnings_activation = array(); 		// Warning to show when we activate a module. Example: array('always'='text') or array('FR'='textfr','MX'='textmx'...)
		$this->warnings_activation_ext = array(); 	// Warning to show when we activate a module if another module is on. Example: array('modOtherModule' => array('always'=>'text')) or array('always' => array('FR'=>'textfr','MX'=>'textmx'...))
		//$this->automatic_activation = array('FR'=>'CFDIMXWasAutomaticallyActivatedBecauseOfYourCountryChoice');
		//$this->always_enabled = false;			// If true, can't be disabled. Value true is reserved for core modules. Not allowed for external modules.

		// Constants
		// List of particular constants to add when module is enabled (key, 'chaine', value, desc, visible, 'current' or 'allentities', deleteonunactive)
		// Example: $this->const=array(1 => array('CFDIMX_MYNEWCONST1', 'chaine', 'myvalue', 'This is a constant to add', 1),
		//                             2 => array('CFDIMX_MYNEWCONST2', 'chaine', 'myvalue', 'This is another constant to add', 0, 'current', 1)
		// );
		$this->const = array();

		// Some keys to add into the overwriting translation tables
		/*$this->overwrite_translation = array(
			'en_US:ParentCompany'=>'Parent company or reseller',
			'fr_FR:ParentCompany'=>'Maison mère ou revendeur'
		)*/

		if (!isModEnabled("cfdimx")) {
			$conf->cfdimx = new stdClass();
			$conf->cfdimx->enabled = 0;
		}

		// Array to add new pages in new tabs
		/* BEGIN MODULEBUILDER TABS */
		// Don't forget to deactivate/reactivate your module to test your changes
		$this->tabs = array();
		/* END MODULEBUILDER TABS */
		// Example:
		// To add a new tab identified by code tabname1
		// $this->tabs[] = array('data' => 'objecttype:+tabname1:Title1:mylangfile@cfdimx:$user->hasRight('cfdimx', 'cfdimx_catalogue', 'read'):/cfdimx/mynewtab1.php?id=__ID__');
		// To add another new tab identified by code tabname2. Label will be result of calling all substitution functions on 'Title2' key.
		// $this->tabs[] = array('data' => 'objecttype:+tabname2:SUBSTITUTION_Title2:mylangfile@cfdimx:$user->hasRight('othermodule', 'otherobject', 'read'):/cfdimx/mynewtab2.php?id=__ID__',
		// To remove an existing tab identified by code tabname
		// $this->tabs[] = array('data' => 'objecttype:-tabname:NU:conditiontoremove');
		//
		// Where objecttype can be
		// 'categories_x'	  to add a tab in category view (replace 'x' by type of category (0=product, 1=supplier, 2=customer, 3=member)
		// 'contact'          to add a tab in contact view
		// 'contract'         to add a tab in contract view
		// 'delivery'         to add a tab in delivery view
		// 'group'            to add a tab in group view
		// 'intervention'     to add a tab in intervention view
		// 'invoice'          to add a tab in customer invoice view
		// 'supplier_invoice' to add a tab in supplier invoice view
		// 'member'           to add a tab in foundation member view
		// 'opensurveypoll'	  to add a tab in opensurvey poll view
		// 'order'            to add a tab in sale order view
		// 'supplier_order'   to add a tab in supplier order view
		// 'payment'		  to add a tab in payment view
		// 'supplier_payment' to add a tab in supplier payment view
		// 'product'          to add a tab in product view
		// 'propal'           to add a tab in propal view
		// 'project'          to add a tab in project view
		// 'stock'            to add a tab in stock view
		// 'thirdparty'       to add a tab in third party view
		// 'user'             to add a tab in user view


		// Dictionaries
		/* Example:
		 $this->dictionaries=array(
		 'langs' => 'cfdimx@cfdimx',
		 // List of tables we want to see into dictionary editor
		 'tabname' => array("table1", "table2", "table3"),
		 // Label of tables
		 'tablib' => array("Table1", "Table2", "Table3"),
		 // Request to select fields
		 'tabsql' => array('SELECT f.rowid as rowid, f.code, f.label, f.active FROM '.$this->db->prefix().'table1 as f', 'SELECT f.rowid as rowid, f.code, f.label, f.active FROM '.$this->db->prefix().'table2 as f', 'SELECT f.rowid as rowid, f.code, f.label, f.active FROM '.$this->db->prefix().'table3 as f'),
		 // Sort order
		 'tabsqlsort' => array("label ASC", "label ASC", "label ASC"),
		 // List of fields (result of select to show dictionary)
		 'tabfield' => array("code,label", "code,label", "code,label"),
		 // List of fields (list of fields to edit a record)
		 'tabfieldvalue' => array("code,label", "code,label", "code,label"),
		 // List of fields (list of fields for insert)
		 'tabfieldinsert' => array("code,label", "code,label", "code,label"),
		 // Name of columns with primary key (try to always name it 'rowid')
		 'tabrowid' => array("rowid", "rowid", "rowid"),
		 // Condition to show each dictionary
		 'tabcond' => array(isModEnabled('cfdimx'), isModEnabled('cfdimx'), isModEnabled('cfdimx')),
		 // Tooltip for every fields of dictionaries: DO NOT PUT AN EMPTY ARRAY
		 'tabhelp' => array(array('code' => $langs->trans('CodeTooltipHelp'), 'field2' => 'field2tooltip'), array('code' => $langs->trans('CodeTooltipHelp'), 'field2' => 'field2tooltip'), ...),
		 );
		 */
		/* BEGIN MODULEBUILDER DICTIONARIES */
		$this->dictionaries = array();
		/* END MODULEBUILDER DICTIONARIES */

		// Boxes/Widgets
		// Add here list of php file(s) stored in cfdimx/core/boxes that contains a class to show a widget.
		/* BEGIN MODULEBUILDER WIDGETS */
		$this->boxes = array(
			//  0 => array(
			//      'file' => 'cfdimxwidget1.php@cfdimx',
			//      'note' => 'Widget provided by CFDIMX',
			//      'enabledbydefaulton' => 'Home',
			//  ),
			//  ...
		);
		/* END MODULEBUILDER WIDGETS */

		// Cronjobs (List of cron jobs entries to add when module is enabled)
		// unit_frequency must be 60 for minute, 3600 for hour, 86400 for day, 604800 for week
		/* BEGIN MODULEBUILDER CRON */
		$this->cronjobs = array(
			//  0 => array(
			//      'label' => 'MyJob label',
			//      'jobtype' => 'method',
			//      'class' => '/cfdimx/class/cfdimx_catalogue.class.php',
			//      'objectname' => 'Cfdimx_catalogue',
			//      'method' => 'doScheduledJob',
			//      'parameters' => '',
			//      'comment' => 'Comment',
			//      'frequency' => 2,
			//      'unitfrequency' => 3600,
			//      'status' => 0,
			//      'test' => 'isModEnabled("cfdimx")',
			//      'priority' => 50,
			//  ),
		);
		/* END MODULEBUILDER CRON */
		// Example: $this->cronjobs=array(
		//    0=>array('label'=>'My label', 'jobtype'=>'method', 'class'=>'/dir/class/file.class.php', 'objectname'=>'MyClass', 'method'=>'myMethod', 'parameters'=>'param1, param2', 'comment'=>'Comment', 'frequency'=>2, 'unitfrequency'=>3600, 'status'=>0, 'test'=>'isModEnabled("cfdimx")', 'priority'=>50),
		//    1=>array('label'=>'My label', 'jobtype'=>'command', 'command'=>'', 'parameters'=>'param1, param2', 'comment'=>'Comment', 'frequency'=>1, 'unitfrequency'=>3600*24, 'status'=>0, 'test'=>'isModEnabled("cfdimx")', 'priority'=>50)
		// );

		// Permissions provided by this module
		$this->rights = array();
		$r = 0;
		// Add here entries to declare new permissions
		/* BEGIN MODULEBUILDER PERMISSIONS */

		/* END MODULEBUILDER PERMISSIONS */


		// Main menu entries to add
		$this->menu = array();
		$r = 0;
		// Add here entries to declare new menus
		/* BEGIN MODULEBUILDER TOPMENU */
		/* END MODULEBUILDER TOPMENU */





				/* BEGIN MODULEBUILDER LEFTMENU CATALOGUE */
		$this->menu[$r++] = array(
			'fk_menu' => 'fk_mainmenu=cfdimx',
			'type' => 'left',
			'titre' => 'Catalogue',
			'mainmenu' => 'cfdimx',
			'leftmenu' => 'catalogue',
			'url' => '/cfdimx/catalogue_list.php',
			'langs' => 'cfdimx@cfdimx',
			'position' => 1000,
			'enabled' => 'isModEnabled(\'cfdimx\')',
			'perms' => '1',
			'target' => '',
			'user' => 2,
			'object' => 'Catalogue',
		);
		/* END MODULEBUILDER LEFTMENU CATALOGUE */

		/* BEGIN MODULEBUILDER LEFTMENU MYOBJECT */
		/* END MODULEBUILDER LEFTMENU MYOBJECT */

		// Exports profiles provided by this module
		$r = 0;
		/* BEGIN MODULEBUILDER EXPORT MYOBJECT */
		/* END MODULEBUILDER EXPORT MYOBJECT */

		// Imports profiles provided by this module
		$r = 0;
		/* BEGIN MODULEBUILDER IMPORT MYOBJECT */
		/* END MODULEBUILDER IMPORT MYOBJECT */
	}

	/**
	 *  Function called when module is enabled.
	 *  The init function add constants, boxes, permissions and menus (defined in constructor) into Dolibarr database.
	 *  It also creates data directories
	 *
	 *  @param      string  $options    Options when enabling module ('', 'noboxes')
	 *  @return     int<-1,1>          	1 if OK, <=0 if KO
	 */
	public function init($options = '')
	{
		global $conf, $langs;
		cfdimx_log("Start plugin activation.", LOG_INFO);

		// Create tables of module at module activation
		//$result = $this->_load_tables('/install/mysql/', 'cfdimx');
		$result = $this->_load_tables('/cfdimx/sql/');
		if ($result < 0) {
			return -1; // Do not activate module if error 'not allowed' returned when loading module SQL queries (the _load_table run sql with run_sql with the error allowed parameter set to 'default')
		}

		$int = 1;
		$errors = 0;

		//PREPARE THIRDPARTY
		cfdimx_log("Adding additional fields for third-party.", LOG_INFO);
		$result = cfdimxAddExtraFields('societe');
		if ($result < 0) {
			$errors++;
			$this->errors[] = "Error creating extra third-party fields " . $this->db->lasterror();
		}

		// PREPARE PRODUCTS/SERVICES
		cfdimx_log("Adding additional fields for product & service.", LOG_INFO);
		$result = cfdimxAddExtraFields('product');
		if ($result < 0) {
			$errors++;
			$this->errors[] = "Error creating extra product & services fields " . $this->db->lasterror();
		}

		// PREPARE INVOICES
		cfdimx_log("Adding additional fields for invoice.", LOG_INFO);
		$result = cfdimxAddExtraFields('facture');
		if ($result < 0) {
			$errors++;
			$this->errors[] = "Error creating extra invoice field " . $this->db->lasterror();
		}

		// facture_rec
		cfdimx_log("Adding additional fields for invoice rec.", LOG_INFO);
		$result = cfdimxAddExtraFields('facture_rec');
		if ($result < 0) {
			$errors++;
			$this->errors[] = "Error creating extra invoice rec field " . $this->db->lasterror();
		}


		// PREPARE INVOICES
		cfdimx_log("Adding additional fields for paiement.", LOG_INFO);
		$result = cfdimxAddExtraFields('paiement');
		if ($result < 0) {
			$errors++;
			$this->errors[] = "Error creating extra paiement field " . $this->db->lasterror();
		}

		//BANK ACCOUNTS
		cfdimx_log("Adding additional fields for bank accounts.", LOG_INFO);
		$result = cfdimxAddExtraFields('bank_account');
		if ($result < 0) {
			$errors++;
			$this->errors[] = "Error creating extra bank accounts field " . $this->db->lasterror();
		}

		//TEMPLATE
		cfdimx_log("Adding template for invoice.", LOG_INFO);
		$conf->global->FACTURE_ADDON_PDF = 'cfdimx';
		$res = dolibarr_set_const($this->db, "FACTURE_ADDON_PDF", "cfdimx", 'chaine', 0, '', $conf->entity);

		if ($res < 0) {
			$errors++;
			cfdimx_log("Error al insertar constante FACTURE_ADDON_PDF: " . $this->db->lasterror(), LOG_ERR);
		}

		// // Permissions
		$this->remove($options);
		$sql = array();
		//return $this->_init($sql, $options);
		$result_init = $this->_init($sql, $options);

		if ($result_init >= 0) {
			cfdimx_log("Scripts SQL executed successfully.", LOG_INFO);
		} else {
			cfdimx_log("Error executing SQL scripts: " . $this->error, LOG_ERR);
		}

		if ($errors > 0) {
			$int = -1;
			cfdimx_log("Activation failed. Errors found: " . $errors, LOG_ERR);
		} else {
			$int = 1; // Éxito			
			//dolibarr_set_const($this->db, "CFDIMX_LAST_ACTIVATION", date('Y-m-d H:i:s'), 'chaine', 0, "v" . $this->version, $conf->entity);
			// Guarda la fecha y la versión en el valor para que sea fácil de leer
			$value_to_save = date('Y-m-d H:i:s') . " (v" . $this->version . ")";
			//dolibarr_set_const($this->db, "CFDIMX_LAST_ACTIVATION", $value_to_save, 'chaine', 0, '', $conf->entity);
			cfdimx_log("Plugin activation is complete. (" . $this->version . ")", LOG_INFO);
		}

		// if ($errors == 0) {
		// 	// Forzamos una constante que necesitemos, sin borrar la versión
		// 	dolibarr_set_const($this->db, "CFDIMX_LAST_ACTIVATION", date('Y-m-d H:i:s'), 'chaine', 0, '', $conf->entity);
		// }		

		return $int;
	}

	/**
	 *	Function called when module is disabled.
	 *	Remove from database constants, boxes and permissions from Dolibarr database.
	 *	Data directories are not deleted
	 *
	 *	@param	string		$options	Options when enabling module ('', 'noboxes')
	 *	@return	int<-1,1>				1 if OK, <=0 if KO
	 */
	public function remove($options = '')
	{
		$sql = array();
		return $this->_remove($sql, $options);

		// global $conf;
		// // SOLO borramos la constante que activa el módulo
		// // NO llamamos a $this->_remove() porque eso limpia la versión
		// $sql = array();
		// $sql[] = "DELETE FROM " . MAIN_DB_PREFIX . "const WHERE name = 'MAIN_MODULE_CFDIMX' AND entity = " . $conf->entity;

		// foreach ($sql as $query) {
		// 	$this->db->query($query);
		// }
		// return 1;
	}

	/**
	 * Function to return the long description of the module.
	 * This will render the content of the descriptionlong property.
	 *
	 * @return string      Long description
	 */
	public function getDescLong()
	{
		global $langs;
		$langs->load("cfdimx@cfdimx");

		// Si la variable tiene contenido (inyectado desde changelog.php o about.php), úsalo
		// Si está vacía o tiene el valor por defecto, intenta cargar el README.md
		if (!empty($this->descriptionlong) && $this->descriptionlong != "CFDIMXDescription") {
			$content = $this->descriptionlong;
		} else {
			$file_readme = dol_buildpath('/cfdimx/README.md', 0);
			if (file_exists($file_readme)) {
				$content = file_get_contents($file_readme);
			} else {
				$content = $langs->trans("CFDIMXDescription");
			}
		}

		// --- MINI PARSER NATIVO PARA RENDERIZAR MARKDOWN ---
		// Títulos
		$content = preg_replace('/^# (.*)$/m', '<h1>$1</h1>', $content);
		$content = preg_replace('/^## (.*)$/m', '<h2 style="border-bottom: 1px solid #ccc; padding-top:15px;">$1</h2>', $content);
		$content = preg_replace('/^### (.*)$/m', '<h3 style="margin-top:10px; color:#333;">$1</h3>', $content);
		// Listas
		$content = preg_replace('/^- (.*)$/m', '<li>$1</li>', $content);
		$content = preg_replace('/^\* (.*)$/m', '<li>$1</li>', $content);
		// Formato
		$content = preg_replace('/\*\*(.*?)\*\*/', '<strong>$1</strong>', $content);
		$content = preg_replace('/`(.*?)`/', '<code style="background:#eee; padding:2px 4px;">$1</code>', $content);
		// Notas (Blockquotes)
		$content = preg_replace('/^> (.*)$/m', '<div class="info" style="margin: 10px 0; padding: 10px; background: #f4f4f4; border-left: 5px solid #007bff;">$1</div>', $content);

		$content = str_replace('---', '<hr>', $content);

		return nl2br($content);
	}


}

<?php
/* Copyright (C) 2023		Laurent Destailleur			<eldy@users.sourceforge.net>
 * Copyright (C) 2026		Rubén Trujillo 				<ruben@doweb.mx>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    core/triggers/interface_99_modCFDIMX_CFDIMXTriggers.class.php
 * \ingroup cfdimx
 * \brief   Example of trigger file.
 *
 * You can create other triggered files by copying this one.
 * - File name should be either:
 *      - interface_99_modCFDIMX_MyTrigger.class.php
 *      - interface_99_all_MyTrigger.class.php
 * - The file must stay in core/triggers
 * - The class name must be InterfaceMyTrigger
 */

require_once DOL_DOCUMENT_ROOT . '/core/triggers/dolibarrtriggers.class.php';
dol_include_once('/cfdimx/lib/cfdimx.lib.php');

/**
 *  Class of triggers for CFDIMX module
 */
class InterfaceCFDIMXTriggers extends DolibarrTriggers
{
	/**
	 * Constructor
	 *
	 * @param DoliDB $db Database handler
	 */
	public function __construct($db)
	{
		parent::__construct($db);
		$this->family = "demo";
		$this->description = "CFDIMX triggers.";
		$this->picto = 'cfdimx@cfdimx';
		// $this->version = self::VERSIONS['dev'];		
		dol_include_once('/cfdimx/core/modules/modCFDIMX.class.php');
		
		if (class_exists('modCFDIMX')) {
			$module = new modCFDIMX($this->db);
			$this->version = $module->version;
		} else {
			$this->version = '1.0.0'; // Fallback por seguridad
		}
	}

	/**
	 * Function called when a Dolibarr business event is done.
	 * All functions "runTrigger" are triggered if the file is inside the directory core/triggers
	 *
	 * @param string 		$action 	Event action code
	 * @param CommonObject 	$object 	Object
	 * @param User 			$user 		Object user
	 * @param Translate 	$langs 		Object langs
	 * @param Conf 			$conf 		Object conf
	 * @return int              		Return integer <0 if KO, 0 if no triggered ran, >0 if OK
	 */
	public function runTrigger($action, $object, User $user, Translate $langs, Conf $conf)
	{
		if (!isModEnabled('cfdimx')) {
			return 0; // If module is not enabled, we do nothing
		}

		$errors = 0;

		// Put here code you want to execute when a Dolibarr business events occurs.
		// Data and type of action are stored into $object and $action

		// You can isolate code for each action in a separate method: this method should be named like the trigger in camelCase.
		// For example : COMPANY_CREATE => public function companyCreate($action, $object, User $user, Translate $langs, Conf $conf)
		$methodName = lcfirst(str_replace(' ', '', ucwords(str_replace('_', ' ', strtolower($action)))));
		$callback = array($this, $methodName);
		if (is_callable($callback)) {
			cfdimx_log("Trigger '" . $this->name . "' for action '$action' launched by " . __FILE__ . ". id=" . $object->id);
			return call_user_func($callback, $action, $object, $user, $langs, $conf);
		}
		
		cfdimx_log("Module version: " . $this->version, LOG_INFO);
		
		/**
		 * STATUS DE FACTURAS
		 */
		// [0] => Draft
		// [1] => Validated
		// [2] => Paid
		// [3] => Abandonned

		// Or you can execute some code here				
		switch ($action) {
			// Companies
			case 'COMPANY_CREATE':
			case 'COMPANY_MODIFY':
				cfdimx_log("Starting [$action][{$object->id}][{$object->ref}]", LOG_INFO);

				if ($object->fournisseur == 0) {

					$response = cfdimxPreservSpecialChars($object);

					if ($object->context['createfromclone'] == 'createfromclone') {
						cfdimx_log("cleaning uid from cloned object.");
						$object->array_options['options_cfdi_uid'] = '';
						$update = $object->updateExtraField('cfdi_uid', '');
						if ($update < 0) {
							cfdimx_log("Error cleaning customer field cfdi_uid : " . $object->error, LOG_ERR);
							$errors++;
						} else {
							cfdimx_log("Clean customer field cfdi_uid is successful", LOG_INFO);
						}
					} else {
						$response = cfdimxCompanyCreateUpdate($object);
					}
					if ($response < 0) {
						$errors++;
					}
				}
				cfdimx_log("Completed [$action][{$object->id}][{$object->ref}]", LOG_INFO);
				break;

			// Products
			case 'PRODUCT_CREATE':
			case 'PRODUCT_MODIFY':
				cfdimx_log("Starting [$action][{$object->id}][{$object->ref}]", LOG_INFO);
				$response = cfdimxProductCreateUpdate($object);
				if ($response < 0) {
					$errors++;
				}
				cfdimx_log("Completed [$action][{$object->id}][{$object->ref}]", LOG_INFO);
				break;

			//BILL_CREATE
			case 'BILL_CREATE':
				cfdimx_log("Starting [$action][{$object->id}][{$object->ref}]", LOG_INFO);
				if ($object->type == 1 || $object->type == 2) {

					$tipoRelacion = '';

					if ($object->type == 2) {
						$tipoRelacion = '01';
					} elseif ($object->type == 1 && !empty($object->fk_facture_source)) {
						$tipoRelacion = '04';
					}

					cfdimx_log("Cleaning aditionall fields on object creation", LOG_INFO);
					$object->array_options['options_cfdi_uuid'] = '';
					$object->array_options['options_cfdi_no_certificado_cfdi'] = '';
					$object->array_options['options_cfdi_cadena_original'] = '';
					$object->array_options['options_cfdi_sello_cfdi'] = '';
					$object->array_options['options_cfdi_sello_sat'] = '';
					$object->array_options['options_cfdi_no_certificado_sat'] = '';
					$object->array_options['options_cfdi_tipo_relacion'] = $tipoRelacion;

					cfdimx_log("Cleaning aditionall fields on database creation", LOG_INFO);
					$object->updateExtraField('cfdi_uuid', '');
					$object->updateExtraField('cfdi_tipo_relacion', $tipoRelacion);
					$object->updateExtraField('cfdi_no_certificado_cfdi', '');
					$object->updateExtraField('cfdi_cadena_original', '');
					$object->updateExtraField('cfdi_sello_cfdi', '');
					$object->updateExtraField('cfdi_sello_sat', '');
					$object->updateExtraField('cfdi_no_certificado_sat', '');
					$object->updateExtraField('cfdi_tipo_relacion', '');
				}
				cfdimx_log("Completed [$action][{$object->id}][{$object->ref}]", LOG_INFO);
				break;
			//Bill
			case 'BILL_VALIDATE':
				cfdimx_log("Starting [$action][{$object->id}][{$object->ref}]", LOG_INFO);

				if ($object->array_options['options_cfdi_tipofactura'] == "FAC") {
					$response = cfdimxCreateCFDI($object);

					if ($response < 0) {

						if ($result < 0) {
							$this->cfdimx_log("Error al re-invocar el trigger de cancelación: " . $interface->error, LOG_ERR);
						}
						$errors++;
					} else {

						$idOrigin = $object->fk_facture_source;

						$fSource = new Facture($this->db);
						$resFetch = $fSource->fetch($idOrigin);

						if ($resFetch > 0) {
							$fSource->isForced = true;
							$fSource->fk_statut = 3;
							cfdimx_log("Re-invocando trigger para factura ID: " . $fSource->id);

							$result = $this->runTrigger('BILL_CANCEL', $fSource, $user, $langs, $conf);
						} else {
							cfdimx_log("Document doesn't have source id", LOG_INFO);
						}
					}
				}
				cfdimx_log("End process for {$action}", LOG_INFO);
				break;

			//BILL_CANCEL
			case 'BILL_CANCEL':
				cfdimx_log("Starting [$action][{$object->id}][{$object->ref}]", LOG_INFO);

				$close_code = GETPOST('close_code', 'alpha') ?? ''; //badcustomer - abandon
				$confirm = GETPOST('confirm', 'alpha') ?? 'no';

				// Verificamos si es la llamada forzada desde BILL_VALIDATE
				$isForced = !empty($object->isForced) ?? false;

				$sourceType = (cfdimxGetValueFrom('facture', $object->id, 'type', 'fk_facture_source') == '') ? 0 : cfdimxGetValueFrom('facture', $object->id, 'type', 'fk_facture_source');

				if ($object->array_options['options_cfdi_tipofactura'] == "FAC" && in_array($sourceType, [0, 1])) {

					if (($close_code != '' && $confirm == 'yes') || $isForced) {

						cfdimx_log("Direct cancelation FAC", LOG_INFO);
						cfdimx_log("Executing SAT Cancellation Process... (Forced: " . ($isForced ? 'YES' : 'NO') . ")", LOG_INFO);
						$object->statut = 3;
						$object->status = 3;
						$response = cfdimxCancelCFDI($object);
						if ($response < 0) {
							$errors++;
						}
					} else {
						cfdimx_log("Replace cancelation", LOG_INFO);
						cfdimx_log("Invoice will be canceled after create the new invoice", LOG_INFO);
					}
				} else if ($object->array_options['options_cfdi_tipofactura'] == "REM") {
					cfdimx_log("Direct cancelation REM", LOG_INFO);
					cfdimx_log("Executing Cancellation Process... (Forced: " . ($isForced ? 'YES' : 'NO') . ")", LOG_INFO);
					$object->statut = 3;
					//cfdimxEcmFilesCreateUpdate($object);
					/**
					 * NUEVA FUNCION PARA DESCARGA DE CFDI Y/O PDF PERSONALIZADO
					 */
					cfdimx_log("Startind CFDI's download...", LOG_INFO);

					// 1. Cargamos la librería de facturas necesaria para que Dolibarr reconozca los modelos
					require_once DOL_DOCUMENT_ROOT . '/core/modules/facture/modules_facture.php';

					// 2. Definimos el nombre del modelo que queremos usar
					$modelName = 'cfdimx';

					// 3. Incluimos el archivo del modelo específicamente desde tu carpeta custom
					// Dolibarr usa dol_include_once para manejar rutas custom de forma segura
					$result = dol_include_once('/cfdimx/core/modules/facture/doc/pdf_cfdimx.modules.php');

					if ($result) {
						// 4. Instanciamos la clase del modelo
						$classname = "pdf_" . $modelName;
						$objModel = new $classname($db);

						// 5. Llamamos al método write_file
						// Este método es el que ya ajustamos para que use el Adaptador y genere todo el "All-in-one"
						// $outputlangs es opcional, si no lo tienes usa la global $langs
						$result_write = $objModel->write_file($object, $langs);

						if ($result_write > 0) {
							cfdimx_log("Documento generado exitosamente con el nuevo modelo cfdimx", LOG_INFO);
						} else {
							cfdimx_log("Error al generar el documento con el nuevo modelo: " . $objModel->error, LOG_ERR);
						}
					} else {
						cfdimx_log("No se pudo encontrar el archivo del modelo pdf_cfdimx", LOG_ERR);
					}
					cfdimx_log('Files download for ' . $sUUID);
				}

				cfdimx_log("Completed [$action][{$object->id}][{$object->ref}]", LOG_INFO);
				break;

			//PAYMENTS FROM IMFOICE SCREEN
			case 'PAYMENT_CUSTOMER_CREATE':
				cfdimx_log("Starting [$action][{$object->id}][{$object->ref}]", LOG_INFO);

				$allPayments = array(
					'ref' => $object->ref,
					'payments' => $object->amounts
				);

				if (null != $allPayments['payments']) {

					$response = cfdimxCreatePayment($allPayments);
					if ($response < 0) {
						$errors++;
					}
				} else {
					cfdimx_log('This document doesn\'t apply to complements', LOG_WARNING);
				}

				cfdimx_log("Completed [$action][{$object->id}][{$object->ref}]", LOG_INFO);
				break;

			//CANCEL OF PAYMENT WHEN IS DELETED IN DOLIBARR
			case 'PAYMENT_CUSTOMER_DELETE':
				cfdimx_log("Starting [$action][{$object->id}][{$object->ref}]", LOG_INFO);

				cfdimx_log("options_cfdi_uuid: [{$object->array_options['options_cfdi_uuid']}]", LOG_DEBUG);

				if ($object->array_options['options_cfdi_uuid'] != '') {

					$response = cfdimxCancelPayment($object);

					if ($response < 0) {
						$errors++;
					}
				}
				cfdimx_log("Completed [$action][{$object->id}][{$object->ref}]", LOG_INFO);
				break;

			//DEFAULT
			default:
				//cfdimx_log("No process identified for this trigger [{$this->name}] - [{$action}]", LOG_WARNING);
				cfdimx_log("Completed [$action][{$object->id}][{$object->ref}]", LOG_WARNING);
				break;
		}

		return ($errors > 0) ? -1 : 1;
	}
}

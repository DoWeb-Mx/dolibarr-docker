<?php
/* Copyright (C) 2026 Rubén Trujillo <ruben@doweb.mx>
 * (Tus encabezados de licencia estándar...)
 */

class CustomPdfAdapter
{
	private $db;

	public function __construct($db)
	{
		$this->db = $db;
	}

	/**
	 * Extrae y estandariza los datos de Facturas y Pagos
	 */
	public function getFormattedData($object)
	{
		global $db;

		$objCfdi = new stdClass();
		$objCfdi->element = $object->element; // 'facture' o 'paiement'

		$objCfdi->id = $object->id; // ID técnico
		$objCfdi->status = $object->status; // Status
		$objCfdi->socid = $object->fk_soc ?? $object->socid;
		$objCfdi->facture_source = $object->fk_facture_source;

		// Datos del Documento (Comunes)		
		// $objCfdi->ref = ($object->status == 0) ? $object->newref : $object->ref;
		$objCfdi->ref = $object->ref;

		// Obtenemos folio y serie limpiando caracteres
		$objCfdi->serie = preg_replace('/[^a-zA-Z]/', '', $object->ref);
		$objCfdi->folio = preg_replace('/[^0-9]/', '', $object->ref);
		$objCfdi->date_validation = '';
		$objCfdi->note_public = $object->note_public;
		$objCfdi->cond_reglement_doc = $object->cond_reglement_doc;

		// Extracción de UUID de Extrafields
		$object->fetch_optionals();
		$objCfdi->tipoFactura = isset($object->array_options['options_cfdi_tipofactura']) ? $object->array_options['options_cfdi_tipofactura'] : '';
		$objCfdi->uuid = isset($object->array_options['options_cfdi_uuid']) ? $object->array_options['options_cfdi_uuid'] : '';
		$objCfdi->formaPago = isset($object->mode_reglement_id) ? cfdimxGetValueFrom('c_paiement', $object->mode_reglement_id, 'libelle', 'id') : '';
		$objCfdi->metodoPago = isset($object->array_options['options_cfdi_metodopago']) ? cfdimxGetDescription('cfdimx_catalogue', $object->array_options['options_cfdi_metodopago']) : '';

		// RELACION		
		$objCfdi->tipoRelacion = isset($object->array_options['options_cfdi_tipo_relacion']) ? $object->array_options['options_cfdi_tipo_relacion'] : '';

		// Sellos
		$objCfdi->certificadoCfdi = isset($object->array_options['options_cfdi_no_certificado_cfdi']) ? $object->array_options['options_cfdi_no_certificado_cfdi'] : '';
		$objCfdi->cadenaOriginal = isset($object->array_options['options_cfdi_cadena_original']) ? $object->array_options['options_cfdi_cadena_original'] : '';
		$objCfdi->selloCfdi = isset($object->array_options['options_cfdi_sello_cfdi']) ? $object->array_options['options_cfdi_sello_cfdi'] : '';
		$objCfdi->selloSat = isset($object->array_options['options_cfdi_sello_sat']) ? $object->array_options['options_cfdi_sello_sat'] : '';
		$objCfdi->certificadoSat = isset($object->array_options['options_cfdi_no_certificado_sat']) ? $object->array_options['options_cfdi_no_certificado_sat'] : '';

		// Datos del Tercero (Receptor)
		// if (!is_object($object->thirdparty) && $object->socid > 0) {
		if ($object->socid > 0) {
			require_once DOL_DOCUMENT_ROOT . '/societe/class/societe.class.php';
			$object->thirdparty = new Societe($db);
			$object->thirdparty->fetch($objCfdi->socid);
			$object->thirdparty->fetch_optionals();
		}

		$objCfdi->receptor_nombre = $object->thirdparty->name ?? $object->thirdparty->no;
		$objCfdi->receptor_rfc = $object->thirdparty->idprof1; // Asumiendo que el RFC está en idprof1 (Dolibarr estándar MX)
		$objCfdi->receptor_regimen = cfdimxGetDescription('cfdimx_catalogue', $object->thirdparty->array_options['options_cfdi_regimenfiscal']) ?? '';
		$objCfdi->receptor_address = $object->thirdparty->address;
		$objCfdi->receptor_numext = $object->thirdparty->array_options['options_cfdi_numext'];
		$objCfdi->receptor_numint = $object->thirdparty->array_options['options_cfdi_numint'];
		$objCfdi->receptor_colonia = $object->thirdparty->array_options['options_cfdi_colonia'];
		$objCfdi->receptor_zip = $object->thirdparty->zip;
		$objCfdi->receptor_town = $object->thirdparty->town;
		$objCfdi->receptor_state = $object->thirdparty->state;
		$objCfdi->receptor_country = $object->thirdparty->country;

		// 4. Lógica Específica por Tipo de Documento
		switch ($objCfdi->element) {
			case 'facture':
				$this->_mapInvoice($objCfdi, $object);
				break;
			case 'payment':
				$this->_mapPayment($objCfdi, $object);
				break;
		}

		return $objCfdi;
	}

	private function _mapInvoice(&$objCfdi, $object)
	{
		$esNotaCredito = ($object->type == 2);

		$objCfdi->tipoComprobante = $esNotaCredito ? "E - Egreso" : "I - Ingreso";
		$objCfdi->titleDoc = $esNotaCredito ? "Nota de Crédito" : (($object->array_options['options_cfdi_tipofactura'] == 'FAC') ? 'Factura' : 'Remisión');
		$objCfdi->base = $object->total_ht;
		$objCfdi->tva = $object->total_tva;
		$objCfdi->total = $object->total_ttc;
		$objCfdi->receptor_uso = cfdimxGetDescription('cfdimx_catalogue', $object->array_options['options_cfdi_usocfdi']) ?? '';

		$objCfdi->lineas = $object->lines;
	}

	private function _mapPayment(&$objCfdi, $object)
	{
		$objCfdi->tipoComprobante = "P - Pago";
		$objCfdi->titleDoc = "Complemento de Pago";
		$objCfdi->total = $object->amount; // El total del pago
		$objCfdi->receptor_uso = 'CP01'; // Fijo por regla del SAT para pagos
		$objCfdi->metodoPago = 'PPD';
		// Las líneas en pagos son las facturas afectadas:
		$objCfdi->lineas = $this->_getPaymentLines();
	}

	private function _getPaymentLines()
	{
		// En Dolibarr, los pagos se vinculan a facturas mediante la tabla llx_paiement_facture.
		// Aquí puedes usar los métodos nativos de Paiement para extraer qué facturas se están pagando.
		$lineas = [
			'qty' => 1,
		];
		// Lógica para obtener el detalle de las facturas pagadas...
		return $lineas;
	}
}

<?php
/* Copyright (C) 2026 Rubén Trujillo <ruben@doweb.mx> */

$res = 0;
if (!$res && file_exists("../../main.inc.php")) $res = @include "../../main.inc.php";
if (!$res && file_exists("../../../main.inc.php")) $res = @include "../../../main.inc.php";
if (!$res) die("Include of main fails");

require_once DOL_DOCUMENT_ROOT . '/core/lib/admin.lib.php';
require_once '../lib/cfdimx.lib.php';

$langs->loadLangs(array("admin", "cfdimx@cfdimx"));
if (!$user->admin) accessforbidden();

// Parameters
$action = GETPOST('action', 'aZ09');
$backtopage = GETPOST('backtopage', 'alpha');


// Definir ruta del log
$log_dir = $conf->cfdimx->dir_output . '/temp/';
$log_file = $log_dir . 'cfdimx_events.log';

if (empty($conf->cfdimx->dir_output)) {
	$log_file = DOL_DATA_ROOT . '/cfdimx/temp/cfdimx_events.log';
}

// --- ACCIÓN: DESCARGAR LOG (EN ZIP) ---
if (GETPOST('action') == 'download' && file_exists($log_file)) {
    $zipname = 'logs_cfdimx_' . date('Ymd_His') . '.zip';
    $zippath = tempnam(sys_get_temp_dir(), 'zip'); // Archivo temporal en el SO

    $zip = new ZipArchive();
    if ($zip->open($zippath, ZipArchive::CREATE) === TRUE) {
        
        $zip->addFile($log_file, basename($log_file));
        
        for ($i = 1; $i <= 10; $i++) {
            $rotatedFile = $log_dir . 'cfdimx_events-' . $i . '.log';
            if (file_exists($rotatedFile)) {
                $zip->addFile($rotatedFile, basename($rotatedFile));
            }
        }
        $zip->close();

        header('Content-Type: application/zip');
        header('Content-disposition: attachment; filename="' . $zipname . '"');
        header('Content-Length: ' . filesize($zippath));
        header('Pragma: no-cache');
        header('Expires: 0');
        
        readfile($zippath);

        unlink($zippath);
        exit;
    } else {
        setEventMessages("No se pudo crear el archivo comprimido.", null, 'errors');
        header("Location: " . $_SERVER["PHP_SELF"]);
        exit;
    }
}

// --- ACCIÓN: LIMPIAR LOG ---
if (GETPOST('action') == 'clear' && file_exists($log_file)) {

	if (file_exists($log_file)) {
		file_put_contents($log_file, '');
	}
	
	for ($i = 1; $i <= 10; $i++) {
		$rotatedFile = $log_dir .  'cfdimx_events' . '-' . $i . '.log';
		if (file_exists($rotatedFile)) {
			@unlink($rotatedFile); 
		}
	}

	setEventMessages("Archivo de log vaciado correctamente.", null, 'mesgs');
	header("Location: " . $_SERVER["PHP_SELF"]);
	exit;
}

$title = "Logs";
llxHeader('', $title);

$linkback = '<a href="' . ($backtopage ? $backtopage : DOL_URL_ROOT . '/admin/modules.php?restore_lastsearch_values=1') . '">' . img_picto($langs->trans("BackToModuleList"), 'back', 'class="pictofixedwidth"') . '<span class="hideonsmartphone">' . $langs->trans("BackToModuleList") . '</span></a>';

print load_fiche_titre($langs->trans($title), $linkback, 'technic');

$head = cfdimxAdminPrepareHead();
print dol_get_fiche_head($head, 'logs', "Registros del Sistema", 0, 'cfdimx@cfdimx');

print '<div class="fichecenter">';

// ... (Todo el código previo de rutas, acciones de descarga y borrado se mantiene igual) ...

if (file_exists($log_file) && is_readable($log_file)) {
	$content = file_get_contents($log_file);

	// 1. Procesar contenido (SIN REORDENAR, tal cual viene el archivo)
	$content = htmlspecialchars(trim($content));

	// Aplicamos los colores intensos
	$content = str_replace('[ERROR]', '<span style="color: #FF0000; font-weight: 900; text-shadow: 0 0 8px rgba(255,0,0,0.4);">[ERROR]</span>', $content);
	$content = str_replace('[INFO ]', '<span style="color: #1e8ae2; font-weight: bold;">[INFO ]</span>', $content);
	// $content = str_replace('[INFO]',  '<span style="color: #39FF14; font-weight: bold;">[INFO]</span>', $content);
	$content = str_replace('[DEBUG]', '<span style="color: #b849b7; font-weight: bold;">[DEBUG]</span>', $content);

	// 2. Botones de acción
	print '<div style="margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center;">';
	//print '<span>Historial de eventos (Orden cronológico):</span>';
	print '<div>';
	print '<a class="butAction" href="' . $_SERVER["PHP_SELF"] . '?action=download">' . img_picto('', 'download') . ' Descargar</a>';
	print '<a class="butActionDelete" href="' . $_SERVER["PHP_SELF"] . '?action=clear" onclick="return confirm(\'¿Borrar registros?\');">' . img_picto('', 'delete') . ' Limpiar</a>';
	print '</div>';
	print '</div>';

	// // 3. Contenedor de Terminal con ID para el script de scroll
	// print '<div style="background: #000; color: #eee; border-radius: 4px; border: 1px solid #333; overflow: hidden; width: 100%; box-sizing: border-box;">';

	// // Header
	// print '<div style="background: #222; padding: 8px 15px; font-size: 10px; color: #888; text-transform: uppercase;">Terminal CFDIMX</div>';

	// // PRE con ID "log-container"
	// print '<pre id="log-container" style="max-height: 600px; overflow-y: auto; white-space: pre-wrap; word-wrap: break-word; margin: 0; padding: 15px; font-family: monospace; font-size: 11px; line-height: 1.5; scrollbar-width: thin;">';
	// print $content; 
	// print '</pre>';
	// print '</div>';

	// // 4. SCRIPT PARA AUTO-SCROLL AL FINAL
	// print '<script type="text/javascript">
	//     window.onload = function() {
	//         var container = document.getElementById("log-container");
	//         if (container) {
	//             container.scrollTop = container.scrollHeight;
	//         }
	//     };
	// </script>';

	// print '<div style="margin-top: 10px; font-size: 0.8em; color: #777;">';
	// print 'Tamaño: ' . dol_print_size(filesize($log_file)) . ' | ' . $log_file;
	// print '</div>';

} else {
	print '<div class="warning">No hay registros disponibles.</div>';
}

print '</div>';

print dol_get_fiche_end();
llxFooter();
$db->close();

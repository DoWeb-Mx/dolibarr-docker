<?php
/* Copyright (C) 2004-2017 Laurent Destailleur  <eldy@users.sourceforge.net> 
 * Copyright (C) 2024       Frédéric France         <frederic.france@free.fr>
 * Copyright (C) 2026		Rubén Trujillo 			<ruben@doweb.mx>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    cfdimx/admin/changelog.php
 * \ingroup cfdimx
 * \brief   changelog page of module CFDIMX.
 */

// Load Dolibarr environment
$res = 0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (!$res && !empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) {
	$res = @include str_replace("..", "", $_SERVER["CONTEXT_DOCUMENT_ROOT"])."/main.inc.php";
}
// Try main.inc.php into web root detected using web root calculated from SCRIPT_FILENAME
$tmp = empty($_SERVER['SCRIPT_FILENAME']) ? '' : $_SERVER['SCRIPT_FILENAME'];
$tmp2 = realpath(__FILE__);
$i = strlen($tmp) - 1;
$j = strlen($tmp2) - 1;
while ($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i] == $tmp2[$j]) {
	$i--;
	$j--;
}
if (!$res && $i > 0 && file_exists(substr($tmp, 0, ($i + 1))."/main.inc.php")) {
	$res = @include substr($tmp, 0, ($i + 1))."/main.inc.php";
}
if (!$res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php")) {
	$res = @include dirname(substr($tmp, 0, ($i + 1)))."/main.inc.php";
}
// Try main.inc.php using relative path
if (!$res && file_exists("../../main.inc.php")) {
	$res = @include "../../main.inc.php";
}
if (!$res && file_exists("../../../main.inc.php")) {
	$res = @include "../../../main.inc.php";
}
if (!$res) {
	die("Include of main fails");
}

// Libraries
require_once DOL_DOCUMENT_ROOT.'/core/lib/admin.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/functions2.lib.php';
require_once '../lib/cfdimx.lib.php';

/**
 * @var Conf $conf
 * @var DoliDB $db
 * @var HookManager $hookmanager
 * @var Translate $langs
 * @var User $user
 */

// Translations
$langs->loadLangs(array("errors", "admin", "cfdimx@cfdimx"));

// Access control
if (!$user->admin) {
	accessforbidden();
}

// Parameters
$action = GETPOST('action', 'aZ09');
$backtopage = GETPOST('backtopage', 'alpha');


/*
 * Actions
 */

// None


/*
 * View
 */

$form = new Form($db);

$help_url = 'https://www.doweb.mx';
$title = "CFDIMXChangeLog";

llxHeader('', $langs->trans($title), $help_url, '', 0, 0, '', '', '', 'mod-cfdimx page-admin_changelog');

// Subheader
$linkback = '<a href="'.($backtopage ? $backtopage : DOL_URL_ROOT.'/admin/modules.php?restore_lastsearch_values=1').'">'.img_picto($langs->trans("BackToModuleList"), 'back', 'class="pictofixedwidth"').'<span class="hideonsmartphone">'.$langs->trans("BackToModuleList").'</span></a>';

print load_fiche_titre($langs->trans($title), $linkback, 'history');

// Configuration header
$head = cfdimxAdminPrepareHead();
print dol_get_fiche_head($head, 'changelog', $langs->trans($title), 0, 'cfdimx@cfdimx');

// dol_include_once('/cfdimx/core/modules/modCFDIMX.class.php');
// $tmpmodule = new modCFDIMX($db);
// print $tmpmodule->getDescLong();

// $file_markdown = dol_buildpath('/cfdimx/ChangeLog.md', 0);
// if (file_exists($file_markdown)) {
//     // 2. Obtener el contenido del archivo
//     $changelog_content = file_get_contents($file_markdown);

//     // 3. Aplicar el parser de Markdown a la variable local
//     $changelog_content = htmlspecialchars($changelog_content);
//     $changelog_content = preg_replace('/^# (.*)$/m', '<h1>$1</h1>', $changelog_content);
//     $changelog_content = preg_replace('/^## (.*)$/m', '<h2 style="border-bottom: 1px solid #ccc; padding-top:15px;">$1</h2>', $changelog_content);
//     $changelog_content = preg_replace('/^### (.*)$/m', '<h3 style="color: #333; margin-top:10px;">$1</h3>', $changelog_content);
//     $changelog_content = preg_replace('/^> (.*)$/m', '<div class="info" style="margin: 10px 0; padding: 10px; background: #f9f9f9; border-left: 5px solid #007bff;">$1</div>', $changelog_content);
//     $changelog_content = preg_replace('/^- (.*)$/m', '<li>$1</li>', $changelog_content);
//     $changelog_content = preg_replace('/\*\*(.*?)\*\*/', '<strong>$1</strong>', $changelog_content);
//     $changelog_content = str_replace('---', '<hr>', $changelog_content);

//     // 4. Imprimir el contenido renderizado
//     print '<div class="fichecenter" style="padding: 0 15px;">';
//     print nl2br($changelog_content);
//     print '</div>';
// } else {
//     print '<div class="error">No se encontró el archivo CHANGELOG.md en la ruta: '.$file_path.'</div>';
// }

// --- CÓDIGO NATIVO ---
dol_include_once('/cfdimx/core/modules/modCFDIMX.class.php');
$tmpmodule = new modCFDIMX($db);

// Forzamos al objeto a que lea el CHANGELOG.md en lugar del README.md
$file_changelog = dol_buildpath('/cfdimx/ChangeLog.md', 0);

if (file_exists($file_changelog)) {
    // Asignamos el contenido del archivo a la propiedad que getDescLong() renderiza
    $tmpmodule->descriptionlong = file_get_contents($file_changelog);
    
    // Llamamos al método nativo que ya sabe poner negritas, listas y saltos de línea
    print '<div class="fichecenter" style="padding: 0 15px;">';
    print $tmpmodule->getDescLong(); 
    print '</div>';
} else {
    print '<div class="error">No se encontró el archivo ChangeLog.md</div>';
}

// Page end
print dol_get_fiche_end();
llxFooter();
$db->close();

-- INFO: When is cloned, UUID is empty on clone
UPDATE llx_const SET value=CONCAT('(v4.5.1) -', DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%s') )  WHERE name='CFDIMX_LAST_ACTIVATION';


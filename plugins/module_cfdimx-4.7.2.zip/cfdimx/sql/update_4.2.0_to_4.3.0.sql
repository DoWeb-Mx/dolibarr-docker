-- INFO: When is cloned, UUID is empty on clone
UPDATE llx_extrafields SET emptyonclone = 1, list = 5 WHERE elementtype = 'facture' AND name = 'cfdi_uuid';

UPDATE llx_extrafields SET emptyonclone = 1, list = 5 WHERE elementtype = 'paiement' AND name = 'cfdi_uuid';

UPDATE llx_extrafields SET emptyonclone = 1, list = 5 WHERE elementtype = 'societe' AND name = 'cfdi_uid';

-- INFO: Forzamos el refresco de la constante de versión para confirmar la migración
UPDATE llx_const SET value=CONCAT('(v4.3.0) -', DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%s') )  WHERE name='CFDIMX_LAST_ACTIVATION';


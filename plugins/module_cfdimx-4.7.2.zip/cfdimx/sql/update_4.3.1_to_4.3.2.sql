-- INFO: When is cloned, UUID is empty on clone
-- 1. Aseguramos que la columna en la tabla de datos del producto sea varchar
ALTER TABLE llx_product_extrafields MODIFY COLUMN cfdi_claveunidad varchar(10);

-- 2. Actualizamos la definición en la tabla de configuración de campos de Dolibarr
UPDATE llx_extrafields SET 
	type = 'varchar', 
    size = '10', 
    param = NULL 
WHERE elementtype = 'product' AND name = 'cfdi_claveunidad';

UPDATE llx_extrafields SET 
	type = 'varchar', 
    size = '10', 
    param = NULL 
WHERE elementtype = 'product' AND name = 'cfdi_claveprodserv';

UPDATE llx_const SET value=CONCAT('(v4.3.2) -', DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%s') )  WHERE name='CFDIMX_LAST_ACTIVATION';


UPDATE llx_societe_extrafields AS SE 
JOIN llx_societe AS S ON SE.fk_object = S.rowid 
JOIN llx_c_forme_juridique AS CFJ ON S.fk_forme_juridique = CFJ.code SET SE.cfdi_regimenfiscal = CFJ.cfdimx_ext_code
WHERE (SE.cfdi_regimenfiscal IS NULL OR SE.cfdi_regimenfiscal = '' OR SE.cfdi_regimenfiscal = '0')
  AND S.fk_forme_juridique IS NOT NULL 
  AND CFJ.cfdimx_ext_code IS NOT NULL;

UPDATE llx_extrafields SET fielddefault=null, alwayseditable=1 WHERE elementtype='societe' and name='cfdi_regimenfiscal' and entity = '1';

ALTER TABLE llx_societe_extrafields MODIFY COLUMN cfdi_regimenfiscal varchar(100) NULL;

ALTER TABLE llx_societe_extrafields MODIFY COLUMN cfdi_usocfdi varchar(100) NULL;

ALTER TABLE llx_facture_extrafields MODIFY COLUMN cfdi_tipofactura varchar(100) NULL;

ALTER TABLE llx_facture_extrafields MODIFY COLUMN cfdi_usocfdi varchar(100) NULL;

ALTER TABLE llx_facture_extrafields MODIFY COLUMN cfdi_metodopago varchar(100) NULL;

ALTER TABLE llx_facture_extrafields MODIFY COLUMN cfdi_uuid varchar(100) NULL;

ALTER TABLE llx_facture_extrafields MODIFY COLUMN cfdi_contractreference varchar(100) NULL;

ALTER TABLE llx_facture_extrafields MODIFY COLUMN cfdi_tipo_relacion varchar(100) NULL;

/*
UPDATE VERSION ON DATABASE
*/
UPDATE llx_const SET value=CONCAT('(v4.7.2) -', DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%s') )  WHERE name='CFDIMX_LAST_ACTIVATION';

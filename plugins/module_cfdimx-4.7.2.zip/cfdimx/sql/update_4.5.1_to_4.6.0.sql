UPDATE llx_extrafields SET emptyonclone = 1, list = 1, alwayseditable=1 WHERE name = 'cfdi_contractreference';

UPDATE llx_extrafields SET emptyonclone = 1 WHERE name = 'cfdi_uuid';

UPDATE llx_extrafields SET emptyonclone = 1 WHERE name = 'cfdi_contractreference';

UPDATE llx_extrafields SET emptyonclone = 1 WHERE name = 'cfdi_uuid';

UPDATE llx_extrafields SET emptyonclone = 1 WHERE name = 'cfdi_cadena_original';

UPDATE llx_extrafields SET emptyonclone = 1 WHERE name = 'cfdi_sello_cfdi';

UPDATE llx_extrafields SET emptyonclone = 1 WHERE name = 'cfdi_sello_sat';

UPDATE llx_extrafields SET emptyonclone = 1 WHERE name = 'cfdi_no_certificado_sat';

UPDATE llx_extrafields SET emptyonclone = 1 WHERE name = 'cfdi_folio_relacion';

/**
STATUS 
1 -> NO PAGADA / PAGO INICIADO
2 -> PAGADA PARCIALMENTE / PAGADO
3 -> ABANDONADA
*/

-- CREATE OR REPLACE VIEW llx_cfdimx_facture_v AS
-- SELECT 
--     fe.cfdi_uuid,
--     f_destino.entity as entity,
-- 	f_destino.fk_statut,   
--     CONCAT(f_destino.ref, ' | ', fe.cfdi_uuid) as label,
--     f_origen.rowid as factura_actual_id
-- FROM llx_facture f_destino
-- JOIN llx_facture f_origen ON f_destino.fk_soc = f_origen.fk_soc
-- LEFT JOIN llx_facture_extrafields fe ON f_destino.rowid = fe.fk_object
-- WHERE
--     (fe.cfdi_uuid IS NOT NULL AND fe.cfdi_uuid != '')
--     AND (f_destino.fk_statut = 1 OR f_destino.fk_statut = 2)
--     AND YEAR(f_destino.datef) = YEAR(CURDATE());

UPDATE llx_const SET value=CONCAT('(v4.6.0) -', DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%s') )  WHERE name='CFDIMX_LAST_ACTIVATION';
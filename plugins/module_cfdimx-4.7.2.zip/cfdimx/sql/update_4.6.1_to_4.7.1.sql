UPDATE llx_extrafields SET list = '0'  WHERE elementtype = 'facture' AND name = 'cfdi_cadena_original' and entity=1;

UPDATE llx_extrafields SET list = '0'  WHERE elementtype = 'facture' AND name = 'cfdi_sello_cfdi' and entity=1;

UPDATE llx_extrafields SET list = '0'  WHERE elementtype = 'facture' AND name = 'cfdi_sello_sat' and entity=1;

UPDATE llx_extrafields SET list = '0'  WHERE elementtype = 'facture' AND name = 'cfdi_no_certificado_sat' and entity=1;

UPDATE llx_extrafields SET list = '1'  WHERE elementtype = 'facture' AND name = 'cfdi_tipofactura' and entity=1;

UPDATE llx_extrafields SET list = '1'  WHERE elementtype = 'facture_rec' AND name = 'cfdi_tipofactura' and entity=1;

UPDATE llx_extrafields SET list = '1'  WHERE elementtype = 'facture' AND name = 'cfdi_metodopago' and entity=1;

UPDATE llx_extrafields SET list = '1'  WHERE elementtype = 'facture_rec' AND name = 'cfdi_metodopago' and entity=1;

UPDATE llx_extrafields SET list = '1'  WHERE elementtype = 'facture' AND name = 'cfdi_usocfdi' and entity=1;

UPDATE llx_extrafields SET list = '1'  WHERE elementtype = 'facture_rec' AND name = 'cfdi_usocfdi' and entity=1;

UPDATE llx_extrafields SET list = '3', alwayseditable='1', fieldrequired='0' WHERE elementtype = 'societe' AND name = 'cfdi_email1' and entity=1;

UPDATE llx_extrafields SET list = '3', alwayseditable='1' WHERE elementtype = 'societe' AND name = 'cfdi_usocfdi' and entity=1;

UPDATE llx_extrafields SET list = '5', fielddefault=null, emptyonclone='1'  WHERE elementtype = 'facture' AND name = 'cfdi_tipo_relacion' and entity=1;

UPDATE llx_extrafields SET list = '5'  WHERE elementtype = 'facture' emptyonclone='1' AND name = 'cfdi_uuid' and entity=1;

UPDATE llx_extrafields SET list = '5'  WHERE elementtype = 'societe' emptyonclone='1' AND name = 'cfdi_uid' and entity=1;

ALTER TABLE llx_societe_extrafields MODIFY COLUMN cfdi_email1 varchar(100) NULL;

ALTER TABLE llx_facture_extrafields MODIFY COLUMN cfdi_tipo_relacion varchar(255) NULL;

/*
UPDATE VERSION ON DATABASE
*/

UPDATE llx_const SET value=CONCAT('(v4.7.1) -', DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%s') )  WHERE name='CFDIMX_LAST_ACTIVATION';

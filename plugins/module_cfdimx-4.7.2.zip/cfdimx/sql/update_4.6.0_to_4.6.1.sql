UPDATE llx_extrafields SET emptyonclone = 1, list = '5' WHERE elementtype = 'facture' AND name = 'cfdi_contractreference';

UPDATE llx_extrafields SET emptyonclone = 1, list = '0' WHERE elementtype = 'facture' AND name = 'cfdi_no_certificado_cfdi';

UPDATE llx_extrafields SET emptyonclone = 1, list = '0' WHERE elementtype = 'facture' AND name = 'cfdi_no_certificado_sat';

INSERT IGNORE INTO llx_overwrite_trans (entity, lang, transkey, transvalue) VALUES( 1, 'es_MX', 'ClassifyCanceled', 'Clasificar como "Cancelada"');

INSERT IGNORE INTO llx_overwrite_trans (entity, lang, transkey, transvalue) VALUES( 1, 'es_MX', 'BillStatusCanceled', 'Cancelada');

INSERT IGNORE INTO llx_overwrite_trans (entity, lang, transkey, transvalue) VALUES( 1, 'es_MX', 'Abandoned', 'Cancelada');

INSERT IGNORE INTO llx_overwrite_trans (entity, lang, transkey, transvalue) VALUES( 1, 'es_MX', 'BillShortStatusCanceled', 'Cancelada');

INSERT IGNORE INTO llx_overwrite_trans (entity, lang, transkey, transvalue) VALUES( 1, 'es_MX', 'ConfirmCancelBillQuestion', '¿Por qué quiere marcar esta factura como ''cancelada''?');

INSERT IGNORE INTO llx_overwrite_trans (entity, lang, transkey, transvalue) VALUES( 1, 'es_MX', 'InvoiceReplacementDesc', 'La <b>factura rectificativa</b> sirve para cancelar y sustituir una factura existente sobre la que aún no hay pagos recibidos.<br><br>Nota: Sólo pueden rectificarse las facturas sin pagos registrados. Si esta última no está cerrada, pasará automáticamente al estado ''cancelada''.');

UPDATE llx_const SET value=CONCAT('(v4.6.1) -', DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%s') )  WHERE name='CFDIMX_LAST_ACTIVATION';
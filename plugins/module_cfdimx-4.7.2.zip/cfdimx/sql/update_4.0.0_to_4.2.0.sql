-- INFO: Agregar nuevos campos que no existían en la v3.0
-- INSERT IGNORE INTO llx_extrafields (name, label, type, size, elementtype, entity) 
-- VALUES ('cfdi_colonia', 'Colonia Fiscal', 'varchar', '255', 'societe', 1);


-- INFO: Ajuste de longitud para campos existentes de versiones anteriores
UPDATE llx_extrafields SET list = '1', enabled = '1' WHERE elementtype = 'societe' AND name = 'cfdi_uid';

UPDATE llx_extrafields SET list = '1', enabled = '1' WHERE elementtype = 'product' AND name = 'cfdi_claveprodserv';

UPDATE llx_extrafields SET list = '1', enabled = '1' WHERE elementtype = 'product' AND name = 'cfdi_claveunidad';

UPDATE llx_extrafields SET list = '1', enabled = '1' WHERE elementtype = 'facture' AND name = 'cfdi_uuid';

UPDATE llx_extrafields SET list = '1', enabled = '1' WHERE elementtype = 'facture' AND name = 'cfdi_usocfdi';

UPDATE llx_extrafields SET list = '1', enabled = '1' WHERE elementtype = 'facture' AND name = 'cfdi_metodopago';

-- INFO: Forzamos el refresco de la constante de versión para confirmar la migración
INSERT IGNORE INTO llx_const (rowid, name, entity, value, `type`, visible, note, tms) VALUES(NULL, 'CFDIMX_LAST_ACTIVATION', 1, '', 'chaine', 0, '', '');
UPDATE llx_const SET value=CONCAT('(v4.2.0) -', DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%s') )  WHERE name='CFDIMX_LAST_ACTIVATION';
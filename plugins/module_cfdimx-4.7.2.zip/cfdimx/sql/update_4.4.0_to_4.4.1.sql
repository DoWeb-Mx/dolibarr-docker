UPDATE llx_extrafields SET emptyonclone = 1 WHERE name = 'cfdi_uuid';

UPDATE llx_extrafields SET emptyonclone = 1 WHERE name = 'cfdi_contractreference';

UPDATE llx_extrafields SET emptyonclone = 1, list = 0 WHERE name = 'cfdi_no_certificado_cfdi';

UPDATE llx_extrafields SET emptyonclone = 1 WHERE name = 'cfdi_cadena_original';

UPDATE llx_extrafields SET emptyonclone = 1 WHERE name = 'cfdi_sello_cfdi';

UPDATE llx_extrafields SET emptyonclone = 1 WHERE name = 'cfdi_sello_sat';

UPDATE llx_extrafields SET emptyonclone = 1, list = 0 WHERE name = 'cfdi_no_certificado_sat';

UPDATE llx_extrafields SET list = 1 WHERE name = 'cfdi_tipofactura';

UPDATE llx_const SET VALUE = CONCAT ('(v4.4.1) -', DATE_FORMAT (NOW (), '%Y-%m-%d %H:%i:%s')) WHERE name = 'CFDIMX_LAST_ACTIVATION';
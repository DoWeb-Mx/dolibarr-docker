<?php
/* Copyright (C) 2026		Rubén Trujillo 			<ruben@doweb.mx>
 * Copyright (C) 2025       Frédéric France         <frederic.france@free.fr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    cfdimx/lib/cfdimx.lib.php
 * \ingroup cfdimx
 * \brief   Library files with common functions for CFDIMX
 */

/**
 * Prepare admin pages header
 *
 * @return array<array{string,string,string}>
 */
function cfdimxAdminPrepareHead()
{
	global $langs, $conf;

	// global $db;
	// $extrafields = new ExtraFields($db);
	// $extrafields->fetch_name_optionals_label('myobject');

	$langs->load("cfdimx@cfdimx");

	$h = 0;
	$head = array();

	$head[$h][0] = dolBuildUrl(dol_buildpath("/cfdimx/admin/setup.php", 1));
	$head[$h][1] = $langs->trans("Settings");
	$head[$h][2] = 'settings';
	$h++;

	/*
	$head[$h][0] = dolBuildUrl(dol_buildpath("/cfdimx/admin/myobject_extrafields.php", 1));
	$head[$h][1] = $langs->trans("ExtraFields");
	$nbExtrafields = (isset($extrafields->attributes['myobject']['label']) && is_countable($extrafields->attributes['myobject']['label'])) ? count($extrafields->attributes['myobject']['label']) : 0;
	if ($nbExtrafields > 0) {
		$head[$h][1] .= '<span class="badge marginleftonlyshort">' . $nbExtrafields . '</span>';
	}
	$head[$h][2] = 'myobject_extrafields';
	$h++;

	$head[$h][0] = dolBuildUrl(dol_buildpath("/cfdimx/admin/myobjectline_extrafields.php", 1));
	$head[$h][1] = $langs->trans("ExtraFieldsLines");
	$nbExtrafields = (isset($extrafields->attributes['myobjectline']['label']) && is_countable($extrafields->attributes['myobjectline']['label'])) ? count($extrafields->attributes['myobject']['label']) : 0;
	if ($nbExtrafields > 0) {
		$head[$h][1] .= '<span class="badge marginleftonlyshort">' . $nbExtrafields . '</span>';
	}
	$head[$h][2] = 'myobject_extrafieldsline';
	$h++;
	*/

	$head[$h][0] = dolBuildUrl(dol_buildpath("/cfdimx/admin/about.php", 1));
	$head[$h][1] = $langs->trans("About");
	$head[$h][2] = 'about';
	$h++;

	$head[$h][0] = dolBuildUrl(dol_buildpath("/cfdimx/admin/changelog.php", 1));
	$head[$h][1] = $langs->trans("Change Log");
	$head[$h][2] = 'changelog';
	$h++;

	$head[$h][0] = dolBuildUrl(dol_buildpath("/cfdimx/admin/logs.php", 1));
	$head[$h][1] = $langs->trans("Logs");
	$head[$h][2] = 'logs';
	$h++;


	// Show more tabs from modules
	// Entries must be declared in modules descriptor with line
	//$this->tabs = array(
	//	'entity:+tabname:Title:@cfdimx:/cfdimx/mypage.php?id=__ID__'
	//); // to add new tab
	//$this->tabs = array(
	//	'entity:-tabname:Title:@cfdimx:/cfdimx/mypage.php?id=__ID__'
	//); // to remove a tab
	complete_head_from_modules($conf, $langs, null, $head, $h, 'cfdimx@cfdimx');

	complete_head_from_modules($conf, $langs, null, $head, $h, 'cfdimx@cfdimx', 'remove');

	return $head;
}

/**
 * Dual logging: Writes to the native Dolibarr system and to a local module file.
 * * @param string $message  Message to register
 * @param int    $level    Priority level (LOG_DEBUG, LOG_INFO, LOG_WARNING, LOG_ERR)
 * @return void
 */
function cfdimx_log($message, $level = LOG_DEBUG)
{
	global $conf;

	// --- NUEVA LÓGICA PARA IDENTIFICAR EL ORIGEN ---
	$backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2);
	$caller = $backtrace[1];

	$function_name = $caller['function'] ?? 'main';
	$class_name = isset($caller['class']) ? $caller['class'] . '::' : '';
	$origin = $class_name . $function_name;
	// ----------------------------------------------

	dol_syslog("CFDIMX: [" . $origin . "] " . $message, $level);

	// Exclusive Module Log (Will appear in documents/cfdimx/temp/cfdimx_events.log)
	$dest_dir = DOL_DATA_ROOT . '/cfdimx/temp';

	if (!is_dir($dest_dir)) {
		dol_mkdir($dest_dir);
	}

	$path = $dest_dir;
	$file_base = '/cfdimx_events';
	$fullPath = $path . $file_base . '.log';

	// [%t] - Process ID
	$t = getmypid();

	// [%-5p] - Aligned log level
	$level_names = [
		LOG_ERR     => 'ERROR',
		LOG_WARNING => 'WARN ',
		LOG_INFO    => 'INFO ',
		LOG_DEBUG   => 'DEBUG'
	];

	$p = $level_names[$level] ?? 'INFO ';

	$d = date('d M Y H:i:s');

	$c = 'modCFDIMX';

	$log_line = sprintf("[%s][%s] [%s] %s.%s [] - %s\n", $t, $p, $d, $c, $origin, $message);

	if (file_exists($fullPath) && filesize($fullPath) > 10 * 1024 * 1024) {
		$max_files = 10;

		if (file_exists($path . $file_base . '-' . $max_files . '.log')) {
			@unlink($path . $file_base . '-' . $max_files . '.log');
		}

		for ($i = $max_files - 1; $i >= 1; $i--) {
			$oldFile = $path . $file_base . '-' . $i . '.log';
			$newFile = $path . $file_base . '-' . ($i + 1) . '.log';
			if (file_exists($oldFile)) {
				rename($oldFile, $newFile);
			}
		}

		rename($fullPath, $path . $file_base . '-1.log');
	}

	// We write to our own file (FILE_APPEND prevents the previous file from being deleted)
	@file_put_contents($fullPath, $log_line, FILE_APPEND);
}

/**
 * Adding extrafield by element type
 * @param 	elementtype			string (product,societe,facture)
 * @return	int					<0 if KO, >0 if OK
 */
function cfdimxAddExtraFields($elementtype = '')
{
	cfdimx_log("Starting [{$elementtype}]", LOG_INFO);
	//cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	include_once DOL_DOCUMENT_ROOT . '/core/class/extrafields.class.php';

	global $db;
	$extrafields = new ExtraFields($db);
	$errors = 0;
	$consec = 0;

	switch ($elementtype) {
		case 'societe':
			$newFields = array(
				'cfdi_uid' => array(
					'label' => "UID",
					'type' => 'varchar',
					'size' => '100',
					'default' => '',
					'options' => '',
					'visibility' => 5,
					'attr' => array('css' => 'minwidth400')
				),
				'cfdi_numint' => array(
					'label' => "Número interior",
					'type' => 'varchar',
					'size' => '100',
					'default' => '',
					'options' => '',
					'visibility' => 3,
					'attr' => array('css' => 'minwidth400')
				),
				'cfdi_numext' => array(
					'label' => "Número exterior",
					'type' => 'varchar',
					'size' => '100',
					'default' => '',
					'options' => '',
					'visibility' => 3,
					'attr' => array('css' => 'minwidth400')
				),
				'cfdi_colonia' => array(
					'label' => "Colonia",
					'type' => 'varchar',
					'size' => '100',
					'default' => '',
					'options' => '',
					'visibility' => 3,
					'attr' => array('css' => 'minwidth400')
				),
				'cfdi_usocfdi' => array(
					'label' => "Uso de CFDI",
					'type' => 'sellist',
					'size' => 3,
					'default' => 'G03',
					'options' => array('options' => array("cfdimx_catalogue:name:id::(catalogue:=:'UsoCfdi')" => NULL)),
					'visibility' => 3,
					'attr' => array('css' => ''),
				),
				'cfdi_email1' => array(
					'label' => "Email facturas 1",
					'type' => 'varchar',
					'size' => '100',
					'mandatory' => 1,
					'visibility' => 3,
					'attr' => array('css' => 'minwidth500')
				),
				'cfdi_email2' => array(
					'label' => "Email facturas 2",
					'type' => 'varchar',
					'size' => '100',
					'visibility' => 3,
					'attr' => array('css' => 'minwidth500')
				),
				'cfdi_email3' => array(
					'label' => "Email facturas 3",
					'type' => 'varchar',
					'size' => '100',
					'visibility' => 3,
					'attr' => array('css' => 'minwidth500')
				),
				'cfdi_regimenfiscal' => array(
					'label' => "Régimen fiscal",
					'type' => 'sellist',
					'size' => '10',
					'default' => 'S01',
					'options' => array('options' => array("cfdimx_catalogue:name:id::(catalogue:=:'RegimenFiscal')" => NULL)),
					'visibility' => 1,
					'mandatory' => 0,
					'attr' => array('css' => 'minwidth400')
				),
			);
			break;

		case 'product':
			$newFields = array(
				'cfdi_claveprodserv' => array(
					'label' => "Clave SAT",
					'type' => 'sellist',
					'size' => '10',
					'default' => '01010101',
					'options' => array('options' => array("cfdimx_catalogue:name:id::(catalogue:=:'ClaveProductServ')" => NULL)),
					'visibility' => 1,
					'mandatory' => 1,
					'attr' => array('css' => 'minwidth400')
				),
				'cfdi_claveunidad' => array(
					'label' => "Clave unidad",
					'type' => 'sellist',
					'size' => '3',
					'default' => 'E48',
					'options' => array('options' => array("cfdimx_catalogue:name:id::(catalogue:=:'ClaveUnidad')" => NULL)),
					'visibility' => 1,
					'mandatory' => 1,
					'attr' => array('css' => 'minwidth400')
				)
			);
			break;


		case 'facture':
			$newFields = array(
				'cfdi_tipofactura' => array(
					'label' => "Tipo de factura",
					'type' => 'select',
					'size' => '3',
					'default' => 'FAC',
					'options' => array('options' => array('REM' => 'Remisión', 'FAC' => 'Factura')),
					'visibility' => 3,
					'attr' => array('css' => '')
				),
				'cfdi_usocfdi' => array(
					'label' => "Uso de CFDI",
					'type' => 'sellist',
					'size' => '3',
					'default' => 'G03',
					'options' => array('options' => array("cfdimx_catalogue:name:id::(catalogue:=:'UsoCfdi')" => NULL)),
					'visibility' => 1,
					'attr' => array('css' => '')
				),
				'cfdi_metodopago' => array(
					'label' => "Método de pago",
					'type' => 'sellist',
					'size' => '3',
					'default' => 'PUE',
					'options' => array('options' => array("cfdimx_catalogue:name:id::(catalogue:=:'MetodoPago')" => NULL)),
					'visibility' => 1,
					'attr' => array('css' => '')
				),
				'cfdi_uuid' => array(
					'label' => "UUID",
					'type' => 'varchar',
					'size' => '255',
					'default' => '',
					'options' => '',
					'visibility' => '5',
					'attr' => array('css' => '')
				),
				'cfdi_contractreference' => array(
					'label' => "Referencia de Contrato",
					'type' => 'varchar',
					'size' => '255',
					'default' => '',
					'options' => '',
					'visibility' => '1',
					'attr' => array('css' => '')
				),
				'cfdi_no_certificado_cfdi' => array(
					'label' => "No. Certificado CFDI",
					'type' => 'varchar',
					'size' => '20',
					'default' => '',
					'options' => '',
					'visibility' => '5',
					'attr' => array('css' => '')
				),
				'cfdi_cadena_original' => array(
					'label' => "Cadena Original",
					'type' => 'text',
					'default' => '',
					'options' => '',
					'visibility' => '0',
					'emptyonclone' => 1,
					'attr' => array('css' => '')
				),
				'cfdi_sello_cfdi' => array(
					'label' => "Sello digital CFDI",
					'type' => 'text',
					'default' => '',
					'options' => '',
					'visibility' => '0',
					'attr' => array('css' => '')
				),
				'cfdi_sello_sat' => array(
					'label' => "Sello digital SAT",
					'type' => 'text',
					'default' => '',
					'options' => '',
					'visibility' => '0',
					'attr' => array('css' => '')
				),
				'cfdi_no_certificado_sat' => array(
					'label' => "No. Certificado SAT",
					'type' => 'varchar',
					'size' => '20',
					'default' => '',
					'options' => '',
					'visibility' => '5',
					'attr' => array('css' => '')
				),
				'cfdi_tipo_relacion' => array(
					'label' => "Tipo de relación",
					'type' => 'sellist',
					'size' => '3',
					'default' => '04',
					'editable' => '0',
					'emptyclone' => '1',
					'options' => array('options' => array("cfdimx_catalogue:name:id::(catalogue:=:'Relacion')" => NULL)),
					'visibility' => 4,
					'attr' => array('css' => '')
				),
				// 'cfdi_separator1' => array(
				// 	'label' => "Cancelación CFDI",
				// 	'type' => 'separate',
				// 	'options' => array('options' => array(1 => 1)),
				// 	'visibility' => 4,
				// ),
				// 'cfdi_motivo_cancel' => array(
				// 	'label' => "Motivo de cancelación",
				// 	'type' => 'sellist',
				// 	'size' => '3',
				// 	'default' => '',
				// 	'editable' => '1',
				// 	'emptyclone' => '1',
				// 	'options' => array('options' => array("cfdimx_catalogue:name:id::(catalogue:=:'MotivoCancel')" => NULL)),
				// 	'visibility' => 4,
				// 	'attr' => array('css' => '')
				// ),
				// 'cfdi_folio_sustituto' => array(
				// 	'label' => "Folio sustituto",
				// 	'type' => 'sellist',
				// 	'size' => '3',
				// 	'default' => '',
				// 	'editable' => '1',
				// 	'emptyclone' => '1',
				// 	'options' => array('options' => array("cfdimx_facture_v:label:cfdi_uuid::(factura_actual_id:=:$ID$)" => NULL)),
				// 	'visibility' => 4,
				// 	'attr' => array('css' => '')
				// ),
				// 'cfdi_separator2' => array(
				// 	'label' => "CFDIs relacionados",
				// 	'type' => 'separate',
				// 	'options' => array('options' => array(1 => 1)),
				// 	'visibility' => 4,
				// ),

			);
			break;

		case 'facture_rec':
			$newFields = array(
				'cfdi_tipofactura' => array(
					'label' => "Tipo de factura",
					'type' => 'select',
					'size' => '3',
					'default' => 'FAC',
					'editable' => 1,
					'options' => array('options' => array('REM' => 'Remisión', 'FAC' => 'Factura')),
					'visibility' => 3,
					'attr' => array('css' => '')
				),
				'cfdi_usocfdi' => array(
					'label' => "Uso de CFDI",
					'type' => 'sellist',
					'size' => '3',
					'default' => 'G03',
					'editable' => 1,
					'options' => array('options' => array("cfdimx_catalogue:name:id::(catalogue:=:'UsoCfdi')" => NULL)),
					'visibility' => 1,
					'attr' => array('css' => '')
				),
				'cfdi_metodopago' => array(
					'label' => "Método de pago",
					'type' => 'sellist',
					'size' => '3',
					'default' => 'PUE',
					'editable' => 1,
					'options' => array('options' => array("cfdimx_catalogue:name:id::(catalogue:=:'MetodoPago')" => NULL)),
					'visibility' => 1,
					'attr' => array('css' => '')
				),
				'cfdi_contractreference' => array(
					'label' => "Referencia de Contrato",
					'type' => 'varchar',
					'size' => '255',
					'default' => '',
					'options' => '',
					'visibility' => '1',
					'attr' => array('css' => '')
				)
			);
			break;

		case 'paiement':
			$newFields = array(
				'cfdi_uuid' => array(
					'label' => "UUID",
					'type' => 'varchar',
					'size' => '255',
					'default' => '',
					'options' => '',
					'visibility' => '5',
					'attr' => array('css' => '')
				),
				'cfdi_no_certificado_cfdi' => array(
					'label' => "No. Certificado CFDI",
					'type' => 'varchar',
					'size' => '20',
					'default' => '',
					'options' => '',
					'visibility' => '5',
					'attr' => array('css' => '')
				),
				'cfdi_cadena_original' => array(
					'label' => "Cadena Original",
					'type' => 'text',
					'default' => '',
					'options' => '',
					'visibility' => '0',
					'emptyonclone' => 1,
					'attr' => array('css' => '')
				),
				'cfdi_sello_cfdi' => array(
					'label' => "Sello digital CFDI",
					'type' => 'text',
					'default' => '',
					'options' => '',
					'visibility' => '0',
					'attr' => array('css' => '')
				),
				'cfdi_sello_sat' => array(
					'label' => "Sello digital SAT",
					'type' => 'text',
					'default' => '',
					'options' => '',
					'visibility' => '0',
					'attr' => array('css' => '')
				),
				'cfdi_no_certificado_sat' => array(
					'label' => "No. Certificado SAT",
					'type' => 'varchar',
					'size' => '20',
					'default' => '',
					'options' => '',
					'visibility' => '5',
					'attr' => array('css' => '')
				),
			);
			break;

		case 'bank_account':
			$newFields = array(
				'cfdi_ctaclabe' => array(
					'label' => "Cuenta CLABE",
					'type' => 'varchar',
					'size' => '25',
					'default' => '',
					'options' => '',
					'visibility' => '1',
					'attr' => array('css' => '')
				)
			);
			break;

		default:
			$newFields = array();
			break;
	}

	$extrafields->fetch_name_optionals_label($elementtype);

	foreach ($newFields as $field => $attribute) {

		$consec += 100;

		cfdimx_log("Verifying field $field", LOG_INFO);

		if (isset($extrafields->attributes[$elementtype]['label'][$field])) continue;

		$res = $extrafields->addExtraField(
			$field,
			$attribute['label'],
			$attribute['type'],
			$consec,
			$attribute['size'],
			$elementtype,
			0,
			$attribute['mandatory'] ?? 0,
			$attribute['default'] ?? '',
			$attribute['options'] ?? '',
			$attribute['editable'] ?? 0,
			'',
			$attribute['visibility'] ?? 1,
			0,
			'',
			'',
			'cfdimx@cfdimx',
			1, //enabled
			0, //totalizable
			0, //printable
			$attribute['attr'], //moreparams
			'', //aiprompt
			$attribute['emptyonclone'] ?? 0,
		);

		if ($res <= 0) {
			cfdimx_log("Error in field $name: " . $extrafields->error, LOG_ERR);
			$errors++;
		} else {
			cfdimx_log("Adding field $field", LOG_INFO);
		}
	}

	//cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$elementtype}]", LOG_INFO);

	return ($errors > 0) ? -1 : 1;
}

/**
 * Sync SAT Catalogues
 * @return	int					<0 if KO, >0 if OK
 */
function cfdimxSyncCatalogues()
{
	global $db;

	cfdimx_log("Starting []", LOG_INFO);
	//cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	$errors = 0;

	$sql = "TRUNCATE TABLE " . MAIN_DB_PREFIX . 'cfdimx_catalogue';
	$res = $db->query($sql);

	if (!$res) {
		cfdimx_log("Error on truncate cfdimx_catalogue: " . $db->lasterror(), LOG_ERR);
		$errors++;
	} else {
		cfdimx_log("Table cfdimx_catalogue truncated successfully.", LOG_INFO);
	}

	//UPDATE ClaveProductServ
	cfdimx_log("Downloading ClaveProductServ.", LOG_INFO);
	$result = cfdimxfillCatalogue('ClaveProductServ');
	if ($result < 0) {
		$errors++;
		cfdimx_log("Error downloading ClaveProductServ.",  LOG_ERR);
	}

	//UPDATE ClaveUnidad
	cfdimx_log("Downloading ClaveUnidad.", LOG_INFO);
	$result = cfdimxfillCatalogue('ClaveUnidad');
	if ($result < 0) {
		$errors++;
		cfdimx_log("Error downloading ClaveUnidad.",  LOG_ERR);
	}

	//UPDATE Pais
	cfdimx_log("Downloading Pais.", LOG_INFO);
	$result = cfdimxfillCatalogue('Pais');
	if ($result < 0) {
		$errors++;
		cfdimx_log("Error downloading Pais.",  LOG_ERR);
	}

	//UPDATE UsoCfdi
	cfdimx_log("Downloading UsoCfdi.", LOG_INFO);
	$result = cfdimxfillCatalogue('UsoCfdi');
	if ($result < 0) {
		$errors++;
		cfdimx_log("Error downloading UsoCfdi.",  LOG_ERR);
	}

	//UPDATE MetodoPago
	cfdimx_log("Downloading MetodoPago.", LOG_INFO);
	$result = cfdimxfillCatalogue('MetodoPago');
	if ($result < 0) {
		$errors++;
		cfdimx_log("Error downloading MetodoPago.",  LOG_ERR);
	}

	/** UPDATE CORE TABLES **/
	//UPDATE RegimenFiscal
	cfdimx_log("Downloading RegimenFiscal.", LOG_INFO);
	$result = cfdimxfillCatalogue('RegimenFiscal');
	if ($result < 0) {
		$errors++;
		cfdimx_log("Error downloading RegimenFiscal.",  LOG_ERR);
	}

	//UPDATE FormaPago
	cfdimx_log("Downloading FormaPago.", LOG_INFO);
	$result = cfdimxfillCatalogue('FormaPago');
	if ($result < 0) {
		$errors++;
		cfdimx_log("Error downloading FormaPago.",  LOG_ERR);
	}

	//UPDATE RELACION
	cfdimx_log("Downloading Relacion.", LOG_INFO);
	$result = cfdimxfillCatalogue('Relacion');
	if ($result < 0) {
		$errors++;
		cfdimx_log("Error downloading Relacion.",  LOG_ERR);
	}

	if ($errors > 0) {
		cfdimx_log("Download failed. Errors found: " . $errors, LOG_ERR);
	}

	// cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed []", LOG_INFO);

	return ($errors > 0) ? -1 : 1;
}

/**
 * Fill Catalogue
 * @param 	catalogue			string (RegimenFiscal,FormaPago)
 * @return	int					<0 if KO, >0 if OK
 */
function cfdimxFillCatalogue($catalogue = "")
{
	cfdimx_log("Starting [{$catalogue}]", LOG_INFO);
	//cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	$errors = 0;

	$optionsTmp = cfdimxcatalog_array($catalogue);

	if (count($optionsTmp) == 0) {
		$errors++;
	}

	switch ($catalogue) {
		// case 'RegimenFiscal':
		// 	$tablename = MAIN_DB_PREFIX . 'c_forme_juridique';
		// 	$column = 'cfdimx_ext_code';
		// 	$res = cfdimxCheckColSat($tablename, $column);
		// 	if (!($res > 0)) {
		// 		$error++;
		// 	}

		// 	$res = cfdimxSyncFormeJuridique($tablename, $column, $optionsTmp);
		// 	if (!($res > 0)) {
		// 		$error++;
		// 	}
		// 	break;

		case 'FormaPago':
			$tablename = MAIN_DB_PREFIX . 'c_paiement';
			$column = 'cfdimx_ext_code';
			$res = cfdimxCheckColSat($tablename, $column);
			if (!($res > 0)) {
				$error++;
			}

			$res = cfdimxSyncPaiement($tablename, $column, $optionsTmp);
			if (!($res > 0)) {
				$error++;
			}
			break;

		default:
			$tablename = MAIN_DB_PREFIX . 'cfdimx_catalogue';
			$res = cfdimxSyncCatalogue($tablename, $optionsTmp, $catalogue);
			if (!($res > 0)) {
				$error++;
			}
			break;
	}

	//cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$catalogue}]", LOG_INFO);

	return ($errors > 0) ? -1 : 1;
}

/**
 * @param 	catalog			string (name endpoint)
 * @param 	type				0 for single array, 1 for array select
 * @return 	array				Array of tabs
 */
function cfdimxcatalog_array($catalog = null, $type = 0)
{
	cfdimx_log("Starting [{$catalog}]", LOG_INFO);
	//cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	$a = null;
	$b = null;
	$i = 0;
	$optionsTmp = array();

	if ($catalog != '') {

		//Calling REST Service
		$response = cfdimxApiCallMethod($catalog, $oObject = null);

		$isValid = (str_contains($response, "<!DOCTYPE html>")) ? false : true;

		if ($isValid) {
			if (json_decode($response)->data) {
				$data = json_decode($response)->data;
				foreach ($data as $key => $value) {
					$a[] = $value->key;
					$b[] = $value->key . " - " . str_replace("'", "", str_replace('"', '', $value->name));
					$i++;
				}
				$optionsTmp = array_combine($a, $b);
			}
		}
	}

	$options = array(
		'options' => $optionsTmp
	);

	//cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$catalog}]", LOG_INFO);

	if ($type == 0) {
		return $optionsTmp;
	} else {
		return $options;
	}
}

/**
 * @param basePath 			string
 * @param oObject 			object (for POST services)
 * @param parameters 		string (query for GET services)
 * CALLING API SERVICES
 */
function cfdimxApiCallMethod($basePathOrg, $oObject = null, $parameters = '')
{
	global $headers, $object, $conf;

	cfdimx_log("Starting [{$object->id}]", LOG_INFO);
	cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	date_default_timezone_set('America/Mexico_City');

	$method = 'GET';
	if (is_object($oObject) || is_array($oObject)) {
		$method = 'POST';
	}

	$headers = (object)[
		'method' 	=> $method,
		'fplugin' 	=> $conf->global->CFDIMX_FPLUGIN,
		'apikey' 	=> $conf->global->CFDIMX_FAPIKEY,
		'secret' 	=> $conf->global->CFDIMX_FSECRET,
	];

	$successMsg = "La operación se realizó con éxito.";
	switch (strtolower($basePathOrg)) {

		case 'downloadcfdi':
			$basePath = '/v4/cfdi40/' . $parameters;
			break;

		case 'products/list':
			$basePath = '/v3/products/list';
			break;

		case 'products/create':
			$basePath = '/v3/products/create';
			$successMsg = 'Registro creado correctamente.';
			break;

		case 'products/update':
			$basePath = '/v3/products/update/' . $parameters;
			$successMsg = 'Los cambios se guardaron con éxito.';
			break;

		case 'pais':
			$basePath = '/v3/catalogo/Pais';
			break;

		case 'regimenfiscal':
			$basePath = '/v3/catalogo/RegimenFiscal';
			break;

		case 'usocfdi':
			$basePath = '/v3/catalogo/UsoCfdi';
			break;

		case 'metodopago':
			$basePath = '/v3/catalogo/MetodoPago';
			break;

		case 'formapago':
			$basePath = '/v3/catalogo/FormaPago';
			break;

		case 'relacion':
			$basePath = '/v3/catalogo/Relacion';
			break;

		case 'claveunidad':
			$basePath = '/v3/catalogo/ClaveUnidad';
			break;

		case 'claveproductserv':
			$basePath = '/v3/catalogo/ClaveProductServ';
			break;

		case 'clients':
			$basePath = '/v1/clients/' . $oObject;
			break;

		case 'clients/create':
			$basePath = '/v1/clients/create';
			$successMsg = 'Registro creado correctamente.';
			break;

		case 'clients/update':
			$basePath = '/v1/clients/' . $parameters . '/update';
			$successMsg = 'Los cambios se guardaron con éxito.';
			break;

		case 'searchbynumorder':
			$basePath = '/v4/cfdi40/list?num_order=' . $parameters;
			break;

		case 'searchbyuuid':
			$basePath = '/v4/cfdi40/list?uuid=' . $parameters;
			break;

		case 'createinvoice':
		case 'createpayment':
			$basePath = '/v4/cfdi40/create';
			$successMsg = 'Documento certificado correctamente ante el SAT.';
			break;

		case 'mycompany':
			$basePath = '/v1/current/account';
			break;

		case 'cancelcfdi':
			$basePath = '/v4/cfdi40/' . $parameters . '/cancel';
			$successMsg = 'La solicitud de cancelación fue procesada exitosamente.';
			break;

		case 'acuse':
			$basePath = '/v4/cfdi40/' . $parameters . '/acuse';
			break;

		default:
			$basePath = '';
			break;
	}

	$sURL = $conf->global->CFDIMX_HOST . $basePath;

	$curl = curl_init();

	$options = array(
		CURLOPT_URL => $sURL,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => '',
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 0,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => $method,
		CURLOPT_HTTPHEADER => array(
			'Content-Type: application/json',
			'F-PLUGIN: ' . $headers->fplugin,
			'F-Api-Key: ' . $headers->apikey,
			'F-Secret-Key: ' . $headers->secret
		),
		CURLOPT_POSTFIELDS => json_encode($oObject)
	);

	curl_setopt_array($curl, $options);

	//Logging request
	if ($method == 'POST') {
		cfdimx_log("Consuming api {$basePath}[{$method}] - " . json_encode($oObject), LOG_INFO);
	} else {
		cfdimx_log("Consuming api {$basePath}[{$method}]", LOG_INFO);
	}

	$response = curl_exec($curl);

	//Logging response
	if ($basePathOrg != 'downloadcfdi' && $basePathOrg != 'acuse') {

		$resp = json_decode($response);

		if (isset($resp->response)) {
			if ($resp->response == 'error') {
				cfdimx_log("Response error 1: {$response}", LOG_ERR);
				if (is_object($resp->message)) {
					cfdimx_log("Response error 1 type 1 : {$resp->message->message}", LOG_ERR);
					setEventMessages($resp->message->message . "<br>" . $resp->message->messageDetail, null, 'errors');
				} else {
					cfdimx_log("Response error 1 type 2 : {$resp->message}", LOG_ERR);
					setEventMessages($resp->message . " " . $resp->message, null, 'errors');
				}
			} else {
				cfdimx_log("Response success 1: {$successMsg} {$resp->response}", LOG_INFO);
				cfdimx_log("Response success 1: {$successMsg} {$response}", LOG_DEBUG);
				if ($method == 'POST') {
					setEventMessages($successMsg, null);
				}
			}
		}

		if (isset($resp->status)) {
			if ($resp->status == 'error') {
				cfdimx_log("Response error 2: {$response}", LOG_ERR);
				if (is_object($resp->message)) {
					setEventMessages($resp->message->message . "<br>" . $resp->message->messageDetail, null, 'errors');
				} else {
					setEventMessages($resp->message . " " . $resp->message, null, 'errors');
				}
			} else {
				cfdimx_log("Response success 2: {$successMsg} {$resp->status}", LOG_INFO);
				cfdimx_log("Response success 2: {$successMsg} {$response}", LOG_DEBUG);
				if ($method == 'POST') {
					setEventMessages($successMsg, null);
				}
			}
		}

		if (!isset($resp->response) && !isset($resp->status)) {
			$response = '{"response":"error","message":"Error del servidor, por favor contacte a soporte"}';
			//cfdimx_log("Response with unexpected error(500/400)", LOG_ERR);
			cfdimx_log("Response error 3: {$response}", LOG_DEBUG);
			setEventMessages("Error del servidor, por favor contacte a soporte", null, 'errors');
		}
	} else {
		$resp = json_decode($response);

		if (isset($resp->response)) {
			if ($resp->response == 'error') {
				cfdimx_log("Response error 4: {$response}", LOG_ERR);
				if (is_object($resp->message)) {
					setEventMessages($resp->message->message . "<br>" . $resp->message->messageDetail, null, 'errors');
				} else {
					setEventMessages($resp->message . " " . $resp->message, null, 'errors');
				}
			} else {
				cfdimx_log("Response success 4: {$successMsg} {$resp->response}", LOG_INFO);
				cfdimx_log("Response success 4: {$successMsg} {$response}", LOG_DEBUG);
				if ($method == 'POST') {
					setEventMessages($successMsg, null);
				}
			}
		}

		if (isset($resp->status)) {
			if ($resp->status == 'error') {
				cfdimx_log("Response error 5: {$response}", LOG_ERR);
				if (is_object($resp->message)) {
					setEventMessages($resp->message->message . "<br>" . $resp->message->messageDetail, null, 'errors');
				} else {
					setEventMessages($resp->message . " " . $resp->message, null, 'errors');
				}
			} else {
				cfdimx_log("Response success 5: {$successMsg} {$resp->status}", LOG_INFO);
				cfdimx_log("Response success 5: {$successMsg} {$response}", LOG_DEBUG);
				if ($method == 'POST') {
					setEventMessages($successMsg, null);
				}
			}
		}
	}

	curl_close($curl);

	cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$object->id}]", LOG_INFO);

	return $response;
}

/**
 * Validate column for SAT Code in core tables
 * @param 	tablename			string (RegimenFiscal,FormaPago)
 * @param 	column				string (RegimenFiscal,FormaPago)
 * @return	int					<0 if KO, >0 if OK
 */
function cfdimxCheckColSat($tablename, $column)
{
	cfdimx_log("Starting [{$tablename}]", LOG_INFO);
	cfdimx_log("Starting [{$tablename}][{$column}]", LOG_DEBUG);

	global $db;

	// 1. Consultar si la columna ya existe en la base de datos
	$sql_check = "SHOW COLUMNS FROM " . $tablename . " LIKE '" . $column . "'";
	$res_check = $db->query($sql_check);

	if ($res_check) {
		$num = $db->num_rows($res_check);

		if ($num == 0) {
			cfdimx_log("Column " . $column . " not found " . $tablename . ". creating...", LOG_INFO);

			$sql_add = "ALTER TABLE " . $tablename . " ADD COLUMN " . $column . " varchar(10) DEFAULT NULL";
			$res_add = $db->query($sql_add);

			if ($res_add) {
				cfdimx_log("alter table {$tablename} adding column {$column} success", LOG_INFO);
				return 1;
			} else {
				cfdimx_log("Error on alter table {$tablename} adding column {$column}: " . $db->lasterror(), LOG_ERR);
				return -1;
			}
		} else {
			cfdimx_log("Column " . $column . " already exist in " . $tablename . ". ", LOG_INFO);
			return 1;
		}
	}

	cfdimx_log("Completed [{$tablename}][{$column}]", LOG_DEBUG);
	cfdimx_log("Completed [{$tablename}]", LOG_INFO);

	return -1;
}

/**
 * Sincroniza los códigos del SAT con el diccionario de formas jurídicas de Dolibarr.
 * @param 	tablename				string
 * @param 	column					string
 * @param 	optionsTmp				object
 * @return	int						<0 if KO, >0 if OK
 */
function cfdimxSyncFormeJuridique($tablename, $column, $optionsTmp)
{
	cfdimx_log("Starting [{$tablename}]", LOG_INFO);
	cfdimx_log("Starting [{$tablename}][{$column}]", LOG_DEBUG);

	global $db;

	$errors = 0;

	//GET MEXICO CODE FROM CORE TABLE
	$sql = "SELECT rowid FROM " . MAIN_DB_PREFIX . "c_country";
	$sql .= " WHERE code_iso = 'MEX'";
	$res = $db->query($sql);
	$country = 154;
	if (!$res) {
		cfdimx_log("Error obtaining the ISO code for Mexico: " . $db->lasterror(), LOG_ERR);
		$errors++;
	} else {
		$obj = $db->fetch_object($res);
		$country = $obj->rowid;
	}

	foreach ($optionsTmp as $codeSat => $labelSat) {
		// We clean the label for the search (avoid strange characters)
		$searchText = $db->escape($labelSat);

		// We check if a legal entity with that name already exists.
		$sql = "SELECT rowid, code FROM " . $tablename;
		$sql .= " WHERE libelle LIKE '%" . $searchText . "%' OR libelle = '" . $searchText . "'";

		$resQuery = $db->query($sql);

		if ($resQuery && $db->num_rows($resQuery) > 0) {

			$obj = $db->fetch_object($resQuery);

			$sqlUpdate = "UPDATE " . $tablename;
			$sqlUpdate .= " SET " . $column . " = '" . $db->escape($codeSat) . "'";
			$sqlUpdate .= " WHERE rowid = " . $obj->rowid;

			$res = $db->query($sqlUpdate);

			if (!$res) {
				cfdimx_log("Error updating {$tablename} with value {$db->escape($codeSat)}: " . $db->lasterror(), LOG_ERR);
				$errors++;
			} else {
				cfdimx_log("Updating {$tablename} with value {$db->escape($codeSat)} for {$obj->rowid}", LOG_DEBUG);
			}
		} else {
			// DOES NOT EXIST: We created a new record
			$newCode = $country . $codeSat;

			// Verificamos que el código interno no esté duplicado
			$sqlInsert = "INSERT INTO " . $tablename . " (code, fk_pays, libelle, {$column}, active)";
			$sqlInsert .= " VALUES ('" . $newCode . "', 154, '" . $searchText . "', '" . $codeSat . "', 1)";

			// 154 es el ID de México en la tabla c_country de Dolibarr
			$res = $db->query($sqlInsert);

			if (!$res) {
				cfdimx_log("Error inserting into {$tablename} with values [{$newCode}]-[{$searchText}] - [{$codeSat}]: " . $db->lasterror(), LOG_ERR);
				$errors++;
			} else {
				cfdimx_log("Inserted record into {$tablename} with values [{$newCode}]-[{$searchText}] - [{$codeSat}] ", LOG_DEBUG);
			}
		}
	}

	if ($errors > 0) {
		cfdimx_log("cfdimxSyncFormeJuridique failed. Errors found: " . $errors, LOG_ERR);
	}

	cfdimx_log("Completed [{$tablename}][{$column}]", LOG_DEBUG);
	cfdimx_log("Completed [{$tablename}]", LOG_INFO);

	return ($errors > 0) ? -1 : 1;
}

/**
 * Sincroniza los códigos del SAT con el diccionario de formas jurídicas de Dolibarr.
 * @param 	tablename				string
 * @param 	column					string
 * @param 	optionsTmp				object
 * @return	int						<0 if KO, >0 if OK
 */
function cfdimxSyncPaiement($tablename, $column, $optionsTmp)
{
	cfdimx_log("Starting [{$tablename}]", LOG_INFO);
	cfdimx_log("Starting [{$tablename}][{$column}]", LOG_DEBUG);

	global $db;

	$errors = 0;

	foreach ($optionsTmp as $codeSat => $labelSat) {
		// We clean the label for the search (avoid strange characters)
		$searchText = $db->escape($labelSat);

		// We check if payment with that name already exists.
		$sql = "SELECT id, code FROM " . $tablename;
		$sql .= " WHERE libelle LIKE '%" . $searchText . "%' OR libelle = '" . $searchText . "'";

		$resQuery = $db->query($sql);

		if ($resQuery && $db->num_rows($resQuery) > 0) {

			$obj = $db->fetch_object($resQuery);

			$sqlUpdate = "UPDATE " . $tablename;
			$sqlUpdate .= " SET " . $column . " = '" . $db->escape($codeSat) . "'";
			$sqlUpdate .= " WHERE id = " . $obj->id;

			$res = $db->query($sqlUpdate);

			if (!$res) {
				cfdimx_log("Error updating {$tablename} with value {$db->escape($codeSat)}: " . $db->lasterror(), LOG_ERR);
				$errors++;
			} else {
				cfdimx_log("Updating {$tablename} with value {$db->escape($codeSat)} for {$obj->id}", LOG_DEBUG);
			}
		} else {
			// DOES NOT EXIST: We created a new record
			$newCode = 'SAT_' . $codeSat;

			// Verificamos que el código interno no esté duplicado
			$sqlInsert = "INSERT INTO " . $tablename . " (entity, code, libelle, type, active, {$column})";
			$sqlInsert .= " VALUES (1,'" . $newCode . "', '" . $searchText . "', 2, 1, '" . $codeSat . "')";

			$res = $db->query($sqlInsert);

			if (!$res) {
				cfdimx_log("Error inserting into {$tablename} with values [{$newCode}]-[{$searchText}] - [{$codeSat}]: " . $db->lasterror(), LOG_ERR);
				$errors++;
			} else {
				cfdimx_log("Inserted record into {$tablename} with values [{$newCode}]-[{$searchText}] - [{$codeSat}] ", LOG_DEBUG);
			}
		}
	}

	if ($errors > 0) {
		cfdimx_log("cfdimxSyncPaiement failed. Errors found: " . $errors, LOG_ERR);
	}

	cfdimx_log("Completed [{$tablename}][{$column}]", LOG_DEBUG);
	cfdimx_log("Completed [{$tablename}]", LOG_INFO);

	return ($errors > 0) ? -1 : 1;
}

/**
 * Sincroniza los códigos del SAT con el diccionario de formas jurídicas de Dolibarr.
 * @param 	tablename				string
 * @param 	optionsTmp				object
 * @param 	catalogue				string
 * @return	int						<0 if KO, >0 if OK
 */
function cfdimxSyncCatalogue($tablename, $optionsTmp, $catalogue)
{
	cfdimx_log("Starting [{$tablename}]", LOG_INFO);
	cfdimx_log("Starting [{$tablename}][{$catalogue}]", LOG_DEBUG);

	global $db;

	$errors = 0;

	$values_to_insert = [];

	foreach ($optionsTmp as $id => $name) {
		//$fk_user_creat = (isset($user) && $user->id) ? $user->id : 0; // Usuario que ejecuta
		$values_to_insert[] = "('" . $id . "','" . $name . "','" . $catalogue . "')";
	}

	if (!empty($values_to_insert)) {
		$sql = "INSERT INTO " . $tablename . " (id, name, catalogue) VALUES " . implode(", ", $values_to_insert);

		$res = $db->query($sql);

		if (!$res) {
			cfdimx_log("Error inserting into {$tablename} with values [" . implode(", ", $values_to_insert) . "] : " . $db->lasterror(), LOG_ERR);
			$errors++;
		} else {
			cfdimx_log("Inserted records into {$tablename} ", LOG_INFO);
		}
	} else {
		$errors++;
		cfdimx_log("No records for be inserted into {$tablename} for {$catalogue} ", LOG_INFO);
	}

	if ($errors > 0) {
		cfdimx_log("cfdimxSyncCatalogue failed. Errors found: " . $errors, LOG_ERR);
	}

	cfdimx_log("Completed [{$tablename}][{$catalogue}]", LOG_DEBUG);
	cfdimx_log("Completed [{$tablename}]", LOG_INFO);

	return ($errors > 0) ? -1 : 1;
}

/**
 * COMPANY CREATE/MODIFY
 */
function cfdimxCompanyCreateUpdate(&$object)
{
	// global $user;
	//global $object;
	cfdimx_log("Starting [{$object->id}]", LOG_INFO);
	cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	$errors = 0;

	$country = cfdimxGetDescription('c_country', $object->country_id);
	// $rfc = $object->idprof1;
	// $regimen = cfdimxGetDescription('c_forme_juridique', $object->forme_juridique_code);
	// $usocfdi = $object->array_options['options_cfdi_usocfdi'];

	// if ($country != 'MEX') {
	// 	$rfc = 'XEXX010101000';
	// 	$object->idprof1 = $rfc;

	// 	$regimen = '616';
	// 	$object->forme_juridique_code = $regimen;

	// 	$usocfdi = 'S01';
	// 	$object->array_options['options_cfdi_usocfdi'] = $usocfdi;
	// 	$object->updateExtraField('cfdi_usocfdi', $usocfdi);
	// }

	if (empty($object->nom)) {
		setEventMessages("Nombre o razón social es un campo requerido.", null, 'errors');
		$errors++;
	}

	if (empty($object->zip)) {
		setEventMessages("Código postal es un campo requerido.", null, 'errors');
		$errors++;
	}

	if (empty($object->idprof1) && $country == 'MEX') {
		setEventMessages("RFC es un campo requerido.", null, 'errors');
		$errors++;
	}

	// if (empty($object->forme_juridique_code) && $country == 'MEX') {
	// 	setEventMessages("Régimen fiscal es un campo requerido.", null, 'errors');
	// 	$errors++;
	// }

	if (empty($object->array_options['options_cfdi_regimenfiscal'])) {
		setEventMessages("Régimen fiscal es un campo requerido.", null, 'errors');
		$errors++;
	}

	if (empty($object->country_id)) {
		setEventMessages("País es un campo requerido.", null, 'errors');
		$errors++;
	}

	if (empty($object->array_options['options_cfdi_email1'])) {
		setEventMessages("Email facturas 1 es un campo requerido.", null, 'errors');
		$errors++;
	}

	if ($errors == 0) {

		$oCustomer = (object)[
			"rfc"				=> $object->idprof1,
			"razons"			=> $object->nom,
			"codpos"			=> $object->zip,
			"email"				=> $object->array_options['options_cfdi_email1'],
			"usocfdi"			=> $object->array_options['options_cfdi_usocfdi'],
			"regimen"			=> $object->array_options['options_cfdi_regimenfiscal'],
			"calle"				=> $object->address,
			"numero_exterior"	=> $object->array_options['options_cfdi_numext'],
			"numero_interior"	=> $object->array_options['options_cfdi_numint'],
			"colonia"			=> $object->array_options['options_cfdi_colonia'],
			"ciudad"			=> $object->town,
			//delegacion
			//localidad
			"estado"			=> cfdimxGetDescription('c_departements', $object->state_id),
			"pais"				=> $country,
			//"numregidtrib"		=> $object->array_options['options_dowebmxcfdiv40_numregidtrib'],
			//nombre
			//apellidos
			"telefono"			=> $object->phone,
			"email2"			=> $object->array_options['options_cfdi_email2'],
			"email3"			=> $object->array_options['options_cfdi_email3'],
		];

		//Search customer
		if ($object->array_options['options_cfdi_uid'] == '' || $object->array_options['options_cfdi_uid'] == null) {
			$response = cfdimxApiCallMethod('clients', $oCustomer->rfc);
		} else {
			$response = cfdimxApiCallMethod('clients', $object->array_options['options_cfdi_uid']);
		}

		$isValid = (str_contains($response, "<!DOCTYPE html>")) ? false : true;

		if ($isValid) {

			//Convert json to object
			$response = json_decode($response);

			//If error doesn't exist
			if ($response->status != 'error') {

				//Update customer is have changes
				$uid = $response->Data->UID;

				//Set Old Customer
				$oCustomerOld = (object)[
					"email"				=> $response->Data->Contacto->Email,
					"email2"			=> $response->Data->Contacto->Email2,
					"email3"			=> $response->Data->Contacto->Email3,
					"telefono"			=> $response->Data->Contacto->Telefono,
					"razons"			=> $response->Data->RazonSocial,
					"rfc"				=> $response->Data->RFC,
					"calle"				=> $response->Data->Calle,
					"numero_exterior"	=> $response->Data->Numero,
					"numero_interior"	=> $response->Data->Interior,
					"codpos"			=> $response->Data->CodigoPostal,
					"colonia"			=> $response->Data->Colonia,
					"estado"			=> $response->Data->Estado,
					"ciudad"			=> $response->Data->Ciudad,
					"pais"				=> $response->Data->Pais,
					"regimen"			=> $response->Data->RegimenId,
					"numregidtrib"		=> $response->Data->NumRegIdTrib,
					"usocfdi"			=> $response->Data->UsoCFDI
				];

				//Compare customers
				$compare = array_diff((array)$oCustomer, (array)$oCustomerOld);
				$compare = (count($compare) == 0) ? array_diff((array)$oCustomerOld, (array)$oCustomer) : array_diff((array)$oCustomer, (array)$oCustomerOld);

				//if diff exist
				if (count($compare) > 0) {

					//Update customer data
					$response = cfdimxApiCallMethod('clients/update', $oCustomer, $uid);

					$isValid = (str_contains($response, "<!DOCTYPE html>")) ? false : true;

					if ($isValid) {

						$response = json_decode($response);

						if ($response->status != 'error') {
							cfdimx_log("Customer updated in billing system", LOG_INFO);
						} else {
							cfdimx_log("Error updating customer in billing system : " . json_decode($response), LOG_ERR);
							$errors++;
						}
					} else {
						cfdimx_log("Error updating customer in billing system", LOG_ERR);
						$errors++;
					}
				} else {
					cfdimx_log("Customer doesn't have change to be  updated in billing system", LOG_WARNING);
				}
			} else {
				//Add new customer
				$response = cfdimxApiCallMethod('clients/create', $oCustomer);

				$isValid = (str_contains($response, "<!DOCTYPE html>")) ? false : true;

				if ($isValid) {

					$response = json_decode($response);

					if ($response->status != 'error') {
						//Update customer is have changes
						$uid = $response->Data->UID;
						cfdimx_log("customer created", LOG_INFO);
					} else {
						cfdimx_log("Error creating customer : " . $object->error, LOG_ERR);
						$errors++;
					}
				}
			}

			//Persiste UUID en base de datos		
			$object->array_options['options_cfdi_uid'] = $uid;

			$update = $object->updateExtraField('cfdi_uid', $uid);
			if ($update < 0) {
				cfdimx_log("Error updating customer field cfdi_uid : " . $object->error, LOG_ERR);
				$errors++;
			} else {
				cfdimx_log("Update customer field cfdi_uid is successful", LOG_INFO);
			}
		} else {
			cfdimx_log("Search by customer " . $oCustomer->rfc . " has failed ", LOG_ERR);
			$errors++;
		}
	}

	cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$object->id}]", LOG_INFO);

	return ($errors > 0) ? -1 : 1;
}

/**
 * PRODUCT CREATE/MODIFY
 */
function cfdimxProductCreateUpdate(&$object)
{
	//global $object;
	cfdimx_log("Starting [{$object->id}]", LOG_INFO);
	cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	$errors = 0;

	$unity = cfdimxGetDescription('ClaveUnidad', $object->array_options['options_cfdi_claveunidad']);
	$unity = trim(str_replace($object->array_options['options_cfdi_claveunidad'], '', $unity));
	$unity = trim(substr($unity, 1));

	$oProduct = (object)[
		"code"				=> $object->ref,
		"name"				=> $object->label,
		"price"				=> $object->price,
		"clavePS"			=> $object->array_options['options_cfdi_claveprodserv'],
		"unity"				=> $unity,
		"claveUnity"		=> $object->array_options['options_cfdi_claveunidad']
	];

	//Search customer
	$response = cfdimxApiCallMethod('products/list');

	$isValid = (str_contains($response, "<!DOCTYPE html>")) ? false : true;

	if ($isValid) {

		//Convert json to object
		$response = json_decode($response);

		$bexist = false;
		$uid = '';

		if ($response->status != 'error') {

			foreach ($response->data as $key => $value) {
				if ($value->sku == $oProduct->code) {
					$bexist = true;
					$uid = $value->uid;
				}
			}

			if (!$bexist) {
				//Add new product
				$response = cfdimxApiCallMethod('products/create', $oProduct);

				$isValid = (str_contains($response, "<!DOCTYPE html>")) ? false : true;

				if ($isValid) {
					$response = json_decode($response);

					if ($response->response == "error") {
						foreach ($response->message as $key => $value) {
							cfdimx_log("Product creation has failed for {$object->ref} : {$value[0]}", LOG_ERR);
							$errors++;
						}
					} else {
						cfdimx_log("Product created in billing system {$object->ref}", LOG_INFO);
						$int = 1;
					}
				}
			} else {
				$response = cfdimxApiCallMethod('products/update', $oProduct, $uid);

				$isValid = (str_contains($response, "<!DOCTYPE html>")) ? false : true;

				if ($isValid) {

					$response = json_decode($response);

					if ($response->response == "error") {
						foreach ($response->message as $key => $value) {
							cfdimx_log("Product update has failed for {$object->ref} : {$value[0]}", LOG_ERR);
							$errors++;
						}
					} else {
						cfdimx_log("Product updated in billing system {$object->ref} ", LOG_INFO);
						$int = 1;
					}
				} else {
					cfdimx_log("Product update has failed {$object->ref} : {$value[0]}", LOG_ERR);
					$int = 1;
				}
			}
		}
	} else {
		cfdimx_log("Get product list has failed ", LOG_ERR);
		$errors++;
	}

	cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$object->id}]", LOG_INFO);

	return ($errors > 0) ? -1 : 1;
}

/**
 * Return label for Country
 * 
 * @param Integer $country_id / $state_id
 * @param String 'country' or 'state'
 */
function cfdimxGetDescription($tablename, $id)
{
	cfdimx_log("Starting [{$tablename}]", LOG_INFO);
	cfdimx_log("Starting [{$tablename}][{$id}]", LOG_DEBUG);

	global $db;

	$desc = '';
	$sql = '';

	switch ($tablename) {
		case 'c_country':
			$sql = "SELECT code_iso as description FROM " . MAIN_DB_PREFIX . "c_country WHERE rowid ='" . $id . "'";
			break;

		case 'c_departements':
			$sql = "SELECT nom as description FROM " . MAIN_DB_PREFIX . "c_departements WHERE rowid =" . $id;
			break;

		case 'c_forme_juridique':
			$sql = "SELECT cfdimx_ext_code as description FROM " . MAIN_DB_PREFIX . "c_forme_juridique WHERE code =" . $id;
			break;

		default:
			$sql = "SELECT name as description FROM " . MAIN_DB_PREFIX . "cfdimx_catalogue WHERE id ='{$id}'";
			break;
	}

	if ($sql != '') {

		$result = $db->query($sql);
		$result = $db->fetch_object($result);
		$desc = $result->description;
	}

	cfdimx_log("Completed [{$tablename}][{$id}]", LOG_DEBUG);
	cfdimx_log("Completed [{$tablename}]", LOG_INFO);


	return $desc;
}

/**
 *	Getter generic. Load value from a specific field
 *
 *	@param	string	$table		Table of element or element line
 *	@param	int		$id			Element id
 *	@param	string	$field		Field selected
 *  @param string 	$filter		Field used in condition (where)
 *	@return	int					<0 if KO, >0 if OK
 */
function cfdimxGetValueFrom($table, $id, $field, $filter = 'rowid')
{
	cfdimx_log("Starting [{$table}]", LOG_INFO);
	cfdimx_log("Starting [{$table}][{$id}]", LOG_DEBUG);

	global $db;

	$result = false;
	if (!empty($id) && !empty($field) && !empty($table)) {
		$sql = "SELECT " . $field . " FROM " . $db->prefix() . $table;
		//$sql .= " WHERE " . $filter . " = " . ((int) $id);
		$sql .= " WHERE " . $filter . " = '{$id}'";

		cfdimx_log($sql, LOG_DEBUG);

		//cfdimx_log(get_class($this) . '::getValueFrom', LOG_DEBUG);
		$resql = $db->query($sql);
		if ($resql) {
			$row = $db->fetch_row($resql);
			$result = ($row) ? ($row[0] ?? '') : '';
			cfdimx_log("result : " . $result, LOG_DEBUG);
		}
	}

	cfdimx_log("Completed [{$table}][{$id}]", LOG_DEBUG);
	cfdimx_log("Completed [{$table}]", LOG_INFO);

	return $result;
}

/**
 * DOWNLOAD CANCELLATION ACKNOWLEDGMENT (ACK)
 */
function cfdimxDownloadAck($ref, $sUUID)
{
	cfdimx_log("Starting [{$ref}]", LOG_INFO);
	cfdimx_log("Starting [{$ref}][{$sUUID}]", LOG_DEBUG);

	$parameter = $sUUID;

	cfdimx_log("Preparing parameter : " . $parameter, LOG_DEBUG);

	$response = cfdimxApiCallMethod('acuse', null, $parameter);

	$sPathFile = DOL_DATA_ROOT . '/facture/' . $ref;

	$sFileName = dol_sanitizeFileName("ACUSE_" . $ref . '.xml');

	dol_mkdir($sPathFile);

	$oFile = fopen($sPathFile . '/' . $sFileName, 'w');

	cfdimx_log("Preparing file " . $sPathFile . "/" . $sFileName, LOG_DEBUG);

	fwrite($oFile, $response);
	fclose($oFile);

	if (file_exists($sPathFile . '/' . $sFileName)) {
		$boolean = true;
	} else {
		cfdimx_log("file already exist", LOG_INFO);
		$boolean = false;
	}

	cfdimx_log("Completed [{$ref}][{$sUUID}]", LOG_DEBUG);
	cfdimx_log("Completed [{$ref}]", LOG_INFO);

	return $boolean;
}

/**
 * DOWNLOAD FILES CFDI
 */
function cfdimxDownloadFile(&$objCfdi, $sType, $sPathFile, $sFileName)
{
	cfdimx_log("Starting [{$objCfdi->id}]", LOG_INFO);
	cfdimx_log("Starting [{$objCfdi->id}][{$objCfdi->ref}]", LOG_DEBUG);

	$parameter = $objCfdi->uuid . "/" . $sType;
	cfdimx_log("Preparing paramter : " . $parameter, LOG_DEBUG);

	$response = cfdimxApiCallMethod('downloadcfdi', null, $parameter);

	$sFileName = dol_sanitizeFileName($sFileName . '.' . $sType);

	dol_mkdir($sPathFile);

	$fullPathFile = trim($sPathFile . '/' . $sFileName);
	$fullPathFile = trim(str_replace('//', '/', $fullPathFile));

	clearstatcache(true, $fullPathFile);

	// cfdimx_log("Checking existence of: " . $fullPathFile, LOG_DEBUG);

	// if (file_exists($fullPathFile)) {

	// 	cfdimx_log("File already exists, skipping download/generation", LOG_INFO);
	// 	$boolean = true;
	// } else {

	// 	cfdimx_log("File not found, proceeding...", LOG_INFO);
	// 	$oFile = fopen($sPathFile . $sFileName, 'w');
	// 	fwrite($oFile, $response);
	// 	fclose($oFile);
	// 	cfdimx_log("File saved", LOG_INFO);
	// 	$boolean = true;
	// }

	cfdimx_log("Downloading file...", LOG_INFO);
	$oFile = fopen($sPathFile . $sFileName, 'w');
	fwrite($oFile, $response);
	fclose($oFile);
	cfdimx_log("File saved", LOG_INFO);
	$boolean = true;

	cfdimx_log("Completed [{$objCfdi->id}][{$objCfdi->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$objCfdi->id}]", LOG_INFO);

	return $boolean;
}

/**
 * BILL VALIDATE / PAYMENT_CUSTOMER_CREATE / BILL_PAYED
 */
function cfdimxCreateCFDI(&$object)
{
	cfdimx_log("Starting [{$object->id}]", LOG_INFO);
	cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	global $conf, $int, $action;
	// @return int              		<0 if KO, 0 if no triggered ran, >0 if OK
	$errors = 0;

	//Get Folio
	$replaceInvoice = ($object->type == 1 || $object->type == 2) ? true : false;

	$sUUID 	= null;
	$sUID	= null;
	$nFolio = preg_replace('/[^0-9]/', '', $object->newref);

	//Get Customer UID
	cfdimx_log("Checking thirdparty...", LOG_INFO);
	if ($object->thirdparty->array_options['options_cfdi_uid'] == '' || $object->thirdparty->array_options['options_cfdi_uid'] == null) {

		$sUID  = cfdimxCompanyCreateUpdate($object->thirdparty);

		if ($sUID->status == 'error') {
			$int = -1;
			foreach ($sUID->message as $key => $value) {
				//setEventMessages($value, null, 'errors');
				$errors++;
				cfdimx_log($value, LOG_ERR);
			}
			return -1;
		} else {

			$sUID = $sUID->Data->UID;
			cfdimx_log("Thirdparty created : {$sUID}", LOG_INFO);
		}
	} else {
		$sUID  = $object->thirdparty->array_options['options_cfdi_uid'];
		cfdimx_log("Thirdparty already exist : {$sUID}", LOG_INFO);
	}

	cfdimx_log("Checking document...", LOG_INFO);
	if ($object->array_options['options_cfdi_uuid'] == '' || $object->array_options['options_cfdi_uuid'] == null) {
		// Search document by reference
		$sUUID = (trim($object->newref) != '') ? cfdimxSearchCfdi($object) : 'no data';
	} else {
		// Search document by UUID
		$sUUID = (trim($object->newref) != '') ? cfdimxSearchCfdi($object, 'uuid') : 'no data';
	}

	//Si no existe prepara la creación del CFDI
	if ($sUUID == 'no data') {

		//Object for conceptos
		$line = 0;
		foreach ($object->lines as $row) {

			$line++;

			$description = $row->product_desc;
			$description .= ($row->date_start > 0 && $row->date_end > 0) ? "\n(De " . date("d/m/Y", $row->date_start) . " a " . date("d/m/Y", $row->date_end) . ")" : "";
			$description .= "\n" . $row->description;

			$TasaOCuota = number_format($row->tva_tx / 100, 6, ".", "");
			$Impuesto 	= ($row->vat_src_code == "") ? "002" : $row->vat_src_code;

			if ($TasaOCuota == 0 && $Impuesto == "002") {
				$TipoFactor = "Exento";
			} else {
				$TipoFactor = "Tasa";
			}

			cfdimx_log("------------------------------------------------", LOG_DEBUG);
			cfdimx_log("row[" . $line . "].qty: " . $row->qty, LOG_DEBUG);
			cfdimx_log("row[" . $line . "].subprice: " . $row->subprice, LOG_DEBUG);
			cfdimx_log("row[" . $line . "].remise_percent: " . $row->remise_percent, LOG_DEBUG);

			$importe = number_format(abs($row->qty) * abs($row->subprice), 6, ".", "");
			$descuento = $importe * ($row->remise_percent / 100);
			$base = abs($importe - $descuento);

			cfdimx_log("base: " . abs($importe - $descuento), LOG_DEBUG);
			cfdimx_log("------------------------------------------------", LOG_DEBUG);

			$conceptos[] = array(
				"ClaveProdServ" => cfdimxGetValueFrom('product_extrafields', $row->fk_product, 'cfdi_claveprodserv', 'fk_object'),
				"Cantidad" => number_format($row->qty, 6, ".", ""),
				"ClaveUnidad" => cfdimxGetValueFrom('product_extrafields', $row->fk_product, 'cfdi_claveunidad', 'fk_object'),
				"Unidad" => ($row->product_type == 0) ? 'Pieza' : 'Servicio',
				"ValorUnitario" => number_format(abs($row->subprice), 6, ".", ""),
				"Descripcion" => $description,
				"ObjetoImp" => "02",
				"NoIdentificacion" => $row->product_ref,
				"Importe" => $importe,
				"Descuento" => $descuento,
				"Impuestos" => array(
					"Traslados" => [
						array(
							"Base" => number_format($base, 6, ".", ""),
							"Impuesto" => $Impuesto,
							"TipoFactor" => $TipoFactor,
							"TasaOCuota" => $TasaOCuota,
							"Importe" => number_format($base * $TasaOCuota, 6, ".", ""),
						)
					]
				)
			);
		}

		$sendCfdi = (isset($conf->global->CFDIMX_SENDMAIL)) ? true : false;
		$sendCfdi = boolval($sendCfdi);

		//Objeto CFDI
		$oCFDI = [
			"Receptor" => array(
				"UID" => $sUID,
			),
			"TipoDocumento" => ($object->type < 2) ? 'factura' : 'nota_credito',
			//"RegimenFiscal" => "601",
			//"BorradorSiFalla" => 1,
			"Conceptos" => $conceptos,
			"UsoCFDI" => $object->thirdparty->array_options['options_cfdi_usocfdi'],
			"Serie" => ($object->type < 2) ? $conf->global->CFDIMX_SERIEFAC : $conf->global->CFDIMX_SERIENOC,
			//"FolioFromApi" => $nFolio,
			"FolioCFDIFromApi" => $nFolio,
			"FormaPago" => cfdimxGetValueFrom('c_paiement', $object->mode_reglement_code, 'cfdimx_ext_code', 'code'),
			"MetodoPago" => $object->array_options['options_cfdi_metodopago'],
			"CondicionesDePago" => cfdimxGetValueFrom('c_payment_term', $object->cond_reglement_code, 'libelle_facture', 'code'),
			"Moneda" => $object->multicurrency_code,
			"TipoCambio" => $object->multicurrency_tx,
			"NumOrder" => $object->newref,
			"FechaFromAPI" => date("Y-m-d\TH:i:s", $object->date),
			"Comentarios" => (empty($object->note_public)) ? ' ' : $object->note_public,
			"EnviarCorreo" => $sendCfdi,
			"LugarExpedicion" => $conf->global->CFDIMX_MYCOMPANY_ZIP,
		];

		//CFDI RELACIONADO
		if ($replaceInvoice) {
			cfdimx_log("looking for previous uuid to be replaced", LOG_INFO);

			$idInvoiceReplaced = $object->fk_facture_source;
			$uuidInvoiceReplaced = cfdimxGetValueFrom('facture_extrafields', $idInvoiceReplaced, 'cfdi_uuid', 'fk_object');

			cfdimx_log("uuid to be replaced {$uuidInvoiceReplaced}", LOG_DEBUG);

			$relation = array(
				"TipoRelacion" => $object->array_options['options_cfdi_tipo_relacion'],
				"UUID" => array(
					$uuidInvoiceReplaced
				),
			);

			$oCFDI['CfdiRelacionados'] = $relation;
		}

		$response = cfdimxApiCallMethod('createinvoice', $oCFDI);

		$response = json_decode($response);
		$sUUID = (isset($response->UUID)) ? $response->UUID : 'no data';

		if ($response->response == "error") {
			$errors++;
		} else {

			$satData = $response->SAT;

			cfdimx_log('SAT data is ' . json_encode($satData));

			$object->array_options['options_cfdi_no_certificado_cfdi'] = '';
			$update = $object->updateExtraField('cfdi_no_certificado_cfdi', $object->array_options['options_cfdi_no_certificado_cfdi']);

			$object->array_options['options_cfdi_cadena_original'] = '';
			$update = $object->updateExtraField('cfdi_cadena_original', $object->array_options['options_cfdi_cadena_original']);

			$object->array_options['options_cfdi_sello_cfdi'] = $satData->SelloCFD ?? 'error 1';
			$update = $object->updateExtraField('cfdi_sello_cfdi', $object->array_options['options_cfdi_sello_cfdi']);

			$object->array_options['options_cfdi_sello_sat'] = $satData->SelloSAT ?? 'error 2';
			$update = $object->updateExtraField('cfdi_sello_sat', $object->array_options['options_cfdi_sello_sat']);

			$object->array_options['options_cfdi_no_certificado_sat'] = $satData->NoCertificadoSAT ?? 'error 3';
			$update = $object->updateExtraField('cfdi_no_certificado_sat', $object->array_options['options_cfdi_no_certificado_sat']);

			$object->array_options['options_cfdi_uuid'] = $sUUID;
			$update = $object->updateExtraField('cfdi_uuid', $sUUID);

			if ($update < 0) {
				cfdimx_log("Error updating extrafields for invoice", LOG_WARNING);
				$errors++;
			}

			/**
			 * NUEVA FUNCION PARA DESCARGA DE CFDI Y/O PDF PERSONALIZADO
			 */
			cfdimx_log("Startind CFDI's download...", LOG_INFO);


			// 1. Cargamos la librería de facturas necesaria para que Dolibarr reconozca los modelos
			require_once DOL_DOCUMENT_ROOT . '/core/modules/facture/modules_facture.php';

			// 2. Definimos el nombre del modelo que queremos usar
			$modelName = 'cfdimx';

			// 3. Incluimos el archivo del modelo específicamente desde tu carpeta custom
			// Dolibarr usa dol_include_once para manejar rutas custom de forma segura
			$result = dol_include_once('/cfdimx/core/modules/facture/doc/pdf_cfdimx.modules.php');

			if ($result) {
				// 4. Instanciamos la clase del modelo
				$classname = "pdf_" . $modelName;
				$objModel = new $classname($db);

				// 5. Llamamos al método write_file
				// Este método es el que ya ajustamos para que use el Adaptador y genere todo el "All-in-one"
				// $outputlangs es opcional, si no lo tienes usa la global $langs
				$result_write = $objModel->write_file($object, $langs);

				if ($result_write > 0) {
					cfdimx_log("Documento generado exitosamente con el nuevo modelo cfdimx", LOG_INFO);
				} else {
					cfdimx_log("Error al generar el documento con el nuevo modelo: " . $objModel->error, LOG_ERR);
				}
			} else {
				cfdimx_log("No se pudo encontrar el archivo del modelo pdf_cfdimx", LOG_ERR);
			}
			cfdimx_log('Files download for ' . $sUUID);

			//CANCELA FACTURA RELACIONADA ANTERIOR
			if ($replaceInvoice) {

				$request = array(
					'motivo' => "01",	//Comprobante emitido con errores con relación
					'folioSustituto' => $sUUID,
				);

				if (in_array($object->type, [0, 1])) {
					cfdimx_log("Canceling related document", LOG_INFO);
					cfdimxApiCallMethod('cancelcfdi', $request, $uuidInvoiceReplaced);
				}
			}
		}
	} else {

		if (null == $object->array_options['options_cfdi_uuid']) {
			$object->array_options['options_cfdi_uuid'] = $sUUID;
			$update = $object->updateExtraField('cfdi_uuid', $sUUID);
		}
	}

	cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$object->id}]", LOG_INFO);

	return ($errors > 0) ? -1 : 1;
}

/**
 * SEARCH ORDER BY NUMBER
 * @param sNewRed 	String (INVOICE NUMBER)
 */
function cfdimxSearchCfdi(&$object, $searchby = "numorder")
{
	cfdimx_log("Starting [{$object->id}]", LOG_INFO);
	cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	cfdimx_log('Searchby: ' . $searchby, LOG_INFO);

	if ($searchby == 'uuid') {
		cfdimx_log("Searching by uuid");
		$response = cfdimxApiCallMethod('searchbyuuid', null, $object->array_options['options_cfdi_uuid']);
	} else {
		cfdimx_log("Searching by numorder");
		$response = cfdimxApiCallMethod('searchbynumorder', null, $object->newref);
	}

	$response = json_decode($response);

	$sUUID = (count($response->data) > 0) ? $response->data[0]->UUID : 'no data';

	cfdimx_log("uuid: {$sUUID}", LOG_DEBUG);

	cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$object->id}]", LOG_INFO);

	return $sUUID;
}

/**
 * CREATE A PAYMENT FOR EACH INVOICE
 *	@param	array				Invoices lits with amount to be payed
 *	@return	int					<0 if KO, >0 if OK
 */
function cfdimxCreatePayment($allPayments = array())
{
	global $paiement, $conf, $db;

	cfdimx_log("Starting [{$object->id}]", LOG_INFO);
	cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);


	$errors = 0;

	$nFolio = preg_replace('/[^0-9]/', '', $allPayments['ref']);

	cfdimx_log("Preparing payment " . $nFolio, LOG_DEBUG);

	foreach ($allPayments['payments'] as $idPayment => $amount) {

		$metodoPago = cfdimxGetValueFrom("facture_extrafields", $idPayment, 'cfdi_metodopago', 'fk_object');
		$tipoFactura = cfdimxGetValueFrom("facture_extrafields", $idPayment, 'cfdi_tipofactura', 'fk_object');

		if ($metodoPago == "PPD" && $tipoFactura == "FAC") {

			cfdimx_log("Enrichment for invoice " . $idPayment, LOG_DEBUG);

			//GET CUSTOMER ID	
			cfdimx_log("Checking thirdparty", LOG_INFO);
			$socid = cfdimxGetValueFrom('facture', $idPayment, 'fk_soc', 'rowid');

			require_once DOL_DOCUMENT_ROOT . '/compta/facture/class/facture.class.php';
			$object = new Facture($db);
			$object->fetch($idPayment);
			$object->fetch_optionals();

			if ($object->thirdparty == null) {
				require_once DOL_DOCUMENT_ROOT . '/societe/class/societe.class.php';
				$object->thirdparty = new Societe($db);
				$object->thirdparty->fetch($socid);
				$object->thirdparty->fetch_optionals();
			}


			$balance = cfdimxGetBalanceByInvoice($idPayment);

			$folio = preg_replace('/[^0-9]/', '', $balance->invoiceRef);
			$serie = preg_replace('/[^a-zA-Z]/', '', $balance->invoiceRef);

			cfdimx_log("totalAmount :{$balance->totalAmount}", LOG_DEBUG);
			cfdimx_log("prevBalAmount :{$balance->prevBalAmount}", LOG_DEBUG);
			cfdimx_log("amount :{$amount}", LOG_DEBUG);

			/**
			 * Fix values because trigger is adding the curent payment when query is executed.
			 * So we most to rest the current values to historical values for get the real values.
			 */
			$balance->partiality = $balance->partiality - 1;
			$balance->prevBalAmount = $balance->totalAmount - $balance->prevBalAmount + $amount;
			$balance->amountPaid = $amount;
			$balance->unpaidBalAmount = $balance->prevBalAmount - $amount;

			$filteredPayments[] = array(
				'paymentRef' => $allPayments['ref'],
				'invoiceId' => $idPayment,
				'uuid' => cfdimxGetValueFrom("facture_extrafields", $idPayment, 'cfdi_uuid', 'fk_object'),
				'currency' => cfdimxGetValueFrom("facture", $idPayment, 'multicurrency_code', 'rowid'),
				'folio' => $folio,
				'serie' => $serie,
				'partiality' => $balance->partiality,
				'totalAmount' => $balance->totalAmount,
				'prevBalAmount' => $balance->prevBalAmount, //Importe Saldo Anterior
				'amountPaid' => $balance->amountPaid, //Importe Pagado
				'unpaidBalAmount' => $balance->unpaidBalAmount, //Importe Saldo Insoluto				
				'taxRate' => ($balance->taxRate / 100) ?? 0,
				'taxCode' => $balance->taxCode,
			);

			$allPayments['amountTotalPaid'] = $allPayments['amountTotalPaid'] + $amount;



			cfdimx_log("Searching customer uuid ", LOG_INFO);
			if ($object->thirdparty->array_options['options_cfdi_uid'] == '' || $object->thirdparty->array_options['options_cfdi_uid'] == null) {

				$response = cfdimxCompanyCreateUpdate($object->thirdparty);

				if ($response->status == 'error') {
					foreach ($response->message as $key => $value) {
						//setEventMessages($value, null, 'errors');
						cfdimx_log($value, LOG_ERR);
						$errors++;
					}
				} else {
					$sUID = $response->Data->UID;
					cfdimx_log("Customer uuid created " . $sUID, LOG_DEBUG);
				}
			} else {
				$sUID  = $object->thirdparty->array_options['options_cfdi_uid'];
				cfdimx_log("Customer uuid found " . $sUID, LOG_DEBUG);
			}

			//SEARCH PAYMENT FOR PREVENT DUPLICATED
			if ($object->array_options['options_cfdi_uuid'] == '' || $object->array_options['options_cfdi_uuid'] == null) {
				$sUUID = (trim($allPayments->ref) != '') ? cfdimxSearchCfdi($allPayments) : 'no data';
			} else {
				$sUUID = (trim($allPayments->ref) != '') ? cfdimxSearchCfdi($allPayments, 'uuid') : 'no data';
			}

			//PREPARA LA GENERACION DEL DOCUMENTO
			if ($sUUID == 'no data') {

				foreach ($filteredPayments as $key => $invoice) {

					$total =  $total + $invoice['amountPaid'];

					$base = number_format($invoice['amountPaid'] / (1 + $invoice['taxRate']), 6, ".", "");

					$doctoRelacionado[] = array(
						"IdDocumento" => $invoice['uuid'],
						"MonedaDR" => $invoice['currency'],
						"EquivalenciaDR" => $EquivalenciaDR ?? 1,
						"NumParcialidad" => $invoice['partiality'],
						"ImpSaldoAnt" => number_format($invoice['prevBalAmount'], 6, ".", ""),
						"ImpPagado" => number_format($invoice['amountPaid'], 6, ".", ""),
						"ImpSaldoInsoluto" => number_format($invoice['unpaidBalAmount'], 6, ".", ""),
						"Impuestos" => array(
							"Traslados" => [
								array(
									"Base" => $base,
									"Impuesto" => $invoice['taxCode'],
									"TipoFactor" => ($invoice['taxRate'] * 100 > 0) ? 'Tasa' : 'Exento',
									"TasaOCuota" => $invoice['taxRate'],
									"Importe" => number_format($base * ($invoice['taxRate']), 6, ".", "")
								)
							],
							//"Retenidos" => []
						),
						"Serie" => $invoice['serie'],
						"Folio" => $invoice['folio']
					);

					$pagos[] = (object)[
						"FechaPago" => date("Y-m-d\TH:i:s", $paiement->datepaye),
						"FormaDePagoP" => cfdimxGetValueFrom('c_paiement', $paiement->paiementid, 'cfdimx_ext_code', 'id'),
						"MonedaP" => "MXN", //TODO: OBTAIN CURRENCY DINAMYCLY
						"TipoCambioP" => "1", //TODO: INCLUDE IT
						"Monto" => number_format($total, 6, ".", ""),
						//NumOperacion
						//RfcEmisorCtaOrd
						//CtaOrdenante
						//NomBancoOrdExt
						//RfcEmisorCtaBen
						//CtaBeneficiario
						"DoctoRelacionado" => $doctoRelacionado,
						//"Impuestos" => null,
					];

					unset($doctoRelacionado);
				}

				$sendCfdi = (isset($conf->global->CFDIMX_SENDMAIL)) ? true : false;
				$sendCfdi = boolval($sendCfdi);

				//Objeto CFDI		
				$oCFDI = [
					"TipoCfdi" => "pago",
					//"FolioFromApi" => $nFolio,			
					"FolioCFDIFromApi" => $nFolio,
					//RegimenFiscal
					"Serie" => $conf->global->CFDIMX_SERIEPAG,
					"FechaFromAPI" => date("Y-m-d\TH:i:s", $paiement->date),
					"LugarExpedicion" => $conf->global->CFDIMX_MYCOMPANY_ZIP,
					"UsoCFDI" => "CP01",
					"Moneda" => "XXX",
					"EnviarCorreo" => $sendCfdi,
					//Draft
					"Receptor" => array(
						"UID" => $sUID,
					),
					"Conceptos" => array(
						array(
							"ClaveProdServ" => "84111506",
							"Cantidad" => "1",
							"ClaveUnidad" => "ACT",
							"Descripcion" => "Pago",
							"ValorUnitario" => "0",
							"Importe" => "0"
						)
					),
					"Pagos" => $pagos,
					"NumOrder" => $paiement->ref,
					//"Comentarios" => (empty($object->note_public)) ? ' ' : $object->note_public,															
				];

				if (count((array)$pagos) > 0) {
					$response = cfdimxApiCallMethod('createpayment', $oCFDI);
					$response = json_decode($response);

					if ($response->response == "error") {

						if (is_object($response->message)) {
							//setEventMessages($response->message->message . " " . $response->message->messageDetail, null, 'errors');
							cfdimx_log($response->message->message . " " . $response->message->messageDetail, LOG_ERR);
						} else {
							//setEventMessages($response->message . " " . $response->message, null, 'errors');
							cfdimx_log($response->message . " " . $response->message, LOG_ERR);
						}
						$errors++;
					}

					$sUUID = (isset($response->UUID)) ? $response->UUID : 'no data';
					cfdimx_log("UUID value is " . ($sUUID ?? ''));

					if ($sUUID != 'no data') {
						cfdimx_log("Saving UUID to payment on database", LOG_DEBUG);
						$paiement->fetch_optionals();
						$paiement->array_options['options_cfdi_uuid'] = $sUUID;
						$update = $paiement->updateExtraField('cfdi_uuid', $sUUID);
						if ($update < 0) {
							$errors++;
						}

						/**
						 * NUEVA FUNCION PARA DESCARGA DE CFDI Y/O PDF PERSONALIZADO
						 */
						cfdimx_log("Startind CFDI's download...", LOG_INFO);

						cfdimx_log("REF: {$object->ref}", LOG_DEBUG);
						cfdimx_log("UUID: {$object->uuid}", LOG_DEBUG);

						// 1. Cargamos la librería de facturas necesaria para que Dolibarr reconozca los modelos
						require_once DOL_DOCUMENT_ROOT . '/core/modules/facture/modules_facture.php';

						// 2. Definimos el nombre del modelo que queremos usar
						$modelName = 'cfdimx';

						// 3. Incluimos el archivo del modelo específicamente desde tu carpeta custom
						// Dolibarr usa dol_include_once para manejar rutas custom de forma segura
						$result = dol_include_once('/cfdimx/core/modules/facture/doc/pdf_cfdimx.modules.php');

						if ($result) {
							// 4. Instanciamos la clase del modelo
							$classname = "pdf_" . $modelName;
							$objModel = new $classname($db);

							// 5. Llamamos al método write_file
							// Este método es el que ya ajustamos para que use el Adaptador y genere todo el "All-in-one"
							// $outputlangs es opcional, si no lo tienes usa la global $langs
							$result_write = $objModel->write_file($object, $langs);

							if ($result_write > 0) {
								cfdimx_log("Documento generado exitosamente con el nuevo modelo cfdimx", LOG_INFO);
							} else {
								cfdimx_log("Error al generar el documento con el nuevo modelo: " . $objModel->error, LOG_ERR);
							}
						} else {
							cfdimx_log("No se pudo encontrar el archivo del modelo pdf_cfdimx", LOG_ERR);
						}
						cfdimx_log('Files download for ' . $sUUID);
					}
				}
			}
		} else {
			cfdimx_log("Discard CFDI for this payment, is not PPD " . $idPayment, LOG_DEBUG);
			unset($allPayments['payments'][$idPayment]);
		}
	}

	cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$object->id}]", LOG_INFO);

	return ($errors > 0) ? -1 : 1;
}

/**
 * GET BALANCE BY INVOICE
 */
function cfdimxGetBalanceByInvoice($invoiceRef = 0)
{
	cfdimx_log("Starting [{$invoiceRef}]", LOG_INFO);
	//cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	global $db;

	$sql =  " SELECT";
	$sql .= " f.rowid AS invoiceId, ";
	$sql .= " f.ref AS invoiceRef, ";
	$sql .= " f.total_ttc AS totalAmount,";
	$sql .= " (SELECT COUNT(amount)+1 FROM " . $db->prefix() . "paiement_facture dpf where fk_facture={$invoiceRef}) partiality,";
	$sql .= " (SELECT COALESCE(SUM(amount), 0.00) FROM " . $db->prefix() . "paiement_facture dpf where fk_facture={$invoiceRef}) prevBalAmount,";
	$sql .= " (SELECT tva_tx FROM " . $db->prefix() . "facturedet WHERE fk_facture = f.rowid LIMIT 1) AS taxRate,";
	$sql .= " (SELECT code FROM " . $db->prefix() . "c_tva ";
	$sql .= " WHERE taux = (SELECT tva_tx FROM " . $db->prefix() . "facturedet WHERE fk_facture = f.rowid LIMIT 1) ";
	$sql .= " AND fk_pays = (SELECT rowid FROM " . $db->prefix() . "c_country WHERE code='MX' LIMIT 1) ";
	$sql .= " LIMIT 1) AS taxCode";
	$sql .=  " FROM " . $db->prefix() . "facture f 	";
	$sql .=  " WHERE f.rowid = {$invoiceRef};";

	cfdimx_log("cfdimxGetBalanceByInvoice : " . $sql, LOG_DEBUG);

	$row = "{}";
	$result = $db->query($sql);
	if ($result) {
		$row = $db->fetch_object($result);
	}

	cfdimx_log("result : " . json_encode($row));

	//cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$invoiceRef}]", LOG_INFO);

	return $row;
}

/**
 * PRESERV SPECIAL CHARS ON CUSTOMER NAME
 */
function cfdimxPreservSpecialChars(&$object)
{
	global $db;

	cfdimx_log("Starting [{$object->id}]", LOG_INFO);
	cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	$originalName = GETPOST('name', 'none'); //"TEXTO"
	$originalName = stripslashes($originalName);
	$isSpecial = str_contains($originalName, '"'); //True

	if ($isSpecial) {

		$sql = "UPDATE " . MAIN_DB_PREFIX . "societe";
		$sql .= " SET nom = '" . $db->escape($originalName) . "'";
		$sql .= " WHERE rowid = " . (int) $object->id;

		$resql = $db->query($sql);

		if (!$resql) {
			cfdimx_log("Cutomer name cannot be updated", LOG_ERR);
		} else {
			$object->nom = $originalName;
			$object->name = $originalName;
			cfdimx_log("Cutomer name updated", LOG_INFO);
		}
	}

	cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$object->id}]", LOG_INFO);

	return 0;
}

/**
 * CANCEL CFDI
 */
function cfdimxCancelCFDI(&$object)
{
	cfdimx_log("Starting [{$object->id}]", LOG_INFO);
	cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	global $db;

	$errors = 0;

	// TODO: VALIDAR SI LA FECHA VALIDACION ES DE UN EJERCICIO ANTERIOR, EJEMPLO SI ES 2026, NO PUEDES CANCELAR FACTURAS DE 2025	
	//$validate = $object->date_valid;

	// TODO: VALIDAR SI ES DE UN MONTO MAYOR A 1000 Y YA PASARON MAS DE 3 DÍAS (SE SOLICITARA ACEPTACION DE USUARIO)

	$idInvCanceled = $object->id;
	$uuidInvCanceled = $object->array_options['options_cfdi_uuid'];

	$idInvNew = cfdimxGetValueFrom('facture', $idInvCanceled, 'rowid', 'fk_facture_source') ?? 0;
	$uuidInvNew = cfdimxGetValueFrom('facture_extrafields', $idInvNew, 'cfdi_uuid', 'fk_object') ?? '';

	$motivo = '02'; //Comprobante emitido con errores sin relación
	if ($idInvNew > 0 && $uuidInvNew != '') {
		$motivo = '01'; //Comprobante emitido con errores con relación
	}

	$request = array(
		"motivo" => $motivo,
	);

	if ($uuidInvNew != '') {
		$request['folioSustituto'] = $uuidInvNew;
	}

	$response = cfdimxApiCallMethod("cancelcfdi", $request, $uuidInvCanceled);
	$response = json_decode($response);

	if ($response->response == "error") {

		if (is_object($response->message)) {
			setEventMessages($response->message->message . " " . $response->message->messageDetail, null, 'errors');
			cfdimx_log("Error: " . $response->message->message . " " . $response->message->messageDetail, LOG_ERR);
		} else {
			setEventMessages($response->message . " " . $response->message, null, 'errors');
			cfdimx_log("Error: " . $response->message . " " . $response->message, LOG_ERR);
		}
		$errors++;
	} else {
		setEventMessages($response->message, null);
		cfdimx_log("Success result", LOG_INFO);
		cfdimx_log("Success: " . $response->message . " " . $response->message, LOG_DEBUG);
	}

	/**
	 * NUEVA FUNCION PARA DESCARGA DE CFDI Y/O PDF PERSONALIZADO
	 */
	cfdimx_log("Startind CFDI's download...", LOG_INFO);

	// 1. Cargamos la librería de facturas necesaria para que Dolibarr reconozca los modelos
	require_once DOL_DOCUMENT_ROOT . '/core/modules/facture/modules_facture.php';

	// 2. Definimos el nombre del modelo que queremos usar
	$modelName = 'cfdimx';

	// 3. Incluimos el archivo del modelo específicamente desde tu carpeta custom
	// Dolibarr usa dol_include_once para manejar rutas custom de forma segura
	$result = dol_include_once('/cfdimx/core/modules/facture/doc/pdf_cfdimx.modules.php');

	if ($result) {
		// 4. Instanciamos la clase del modelo
		$classname = "pdf_" . $modelName;
		$objModel = new $classname($db);

		// 5. Llamamos al método write_file
		// Este método es el que ya ajustamos para que use el Adaptador y genere todo el "All-in-one"
		// $outputlangs es opcional, si no lo tienes usa la global $langs
		$result_write = $objModel->write_file($object, $langs);

		if ($result_write > 0) {
			cfdimx_log("Documento generado exitosamente con el nuevo modelo cfdimx", LOG_INFO);
		} else {
			cfdimx_log("Error al generar el documento con el nuevo modelo: " . $objModel->error, LOG_ERR);
		}
	} else {
		cfdimx_log("No se pudo encontrar el archivo del modelo pdf_cfdimx", LOG_ERR);
	}
	cfdimx_log('Files download for ' . $sUUID);

	cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$object->id}]", LOG_INFO);

	return ($errors > 0) ? -1 : 1;
}

/**
 * CANCEL PAYMENT
 */
function cfdimxCancelPayment(&$object)
{
	cfdimx_log("Starting [{$object->id}]", LOG_INFO);
	cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	$errors = 0;

	// TODO: VALIDAR SI LA FECHA VALIDACION ES DE UN EJERCICIO ANTERIOR, EJEMPLO SI ES 2026, NO PUEDES CANCELAR FACTURAS DE 2025	

	// TODO: VALIDAR SI ES DE UN MONTO MAYOR A 1000 Y YA PASARON MAS DE 3 DÍAS (SE SOLICITARA ACEPTACION DE USUARIO)

	$uuidInvCanceled = $object->array_options['options_cfdi_uuid'];

	$motivo = '02'; //Comprobante emitido con errores sin relación	

	$request = array(
		"motivo" => $motivo,
	);

	$response = cfdimxApiCallMethod("cancelcfdi", $request, $uuidInvCanceled);
	$response = json_decode($response);

	if ($response->response == "error") {

		if (is_object($response->message)) {
			setEventMessages($response->message->message . " " . $response->message->messageDetail, null, 'errors');
			cfdimx_log("Error: " . $response->message->message . " " . $response->message->messageDetail, LOG_ERR);
		} else {
			setEventMessages($response->message . " " . $response->message, null, 'errors');
			cfdimx_log("Error: " . $response->message . " " . $response->message, LOG_ERR);
		}
		$errors++;
	} else {
		setEventMessages($response->message, null);
		cfdimx_log("Success result", LOG_INFO);
		cfdimx_log("Success: " . $response->message . " " . $response->message, LOG_DEBUG);
	}

	cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$object->id}]", LOG_INFO);

	return ($errors > 0) ? -1 : 1;
}

/**
 * SYNC SML DATA
 */
function cfdimxSyncXmlData(&$object, $xmlFile)
{
	cfdimx_log("Starting [{$object->id}]", LOG_INFO);
	cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	$boolean = false;

	cfdimx_log("checking {$xmlFile}", LOG_DEBUG);
	if (!file_exists($xmlFile)) return false;

	cfdimx_log("loading {$xmlFile}", LOG_DEBUG);
	$xml = simplexml_load_file($xmlFile);
	if ($xml === false) return false;

	cfdimx_log("file loaded",  LOG_DEBUG);
	// 1. Obtener NoCertificado del Emisor (Nodo Raíz)	
	$noCertificado = (string)$xml['NoCertificado'];

	// 2. Datos del Timbre
	//$namespaces = $xml->getNamespaces(true);
	$xml->registerXPathNamespace('cfdi', 'http://www.sat.gob.mx/cfd/4');
	$xml->registerXPathNamespace('tfd', 'http://www.sat.gob.mx/TimbreFiscalDigital');

	$tfd = $xml->xpath('//tfd:TimbreFiscalDigital');
	if (!empty($tfd)) {
		cfdimx_log("filling from xml data {$xmlFile}", LOG_DEBUG);
		$tfd = $tfd[0];
		$UUID = (string)$tfd['UUID'];
		$FechaTimbrado = (string)$tfd['FechaTimbrado'];
		$SelloCFD = (string)$tfd['SelloCFD'];
		$SelloSAT = (string)$tfd['SelloSAT'];
		$NoCertificadoSAT = (string)$tfd['NoCertificadoSAT'];
		$VersionTFD = (string)$tfd['Version'];
		$RFCProvCertif = (string)$tfd['RfcProvCertif'] ?: "LSO1306189R5"; // Default o dinámico

		// 3. Construir Cadena Original del Complemento de Certificación Digital del SAT
		// Estándar: |Version|UUID|FechaTimbrado|RfcProvCertif|SelloCFD|NoCertificadoSAT||
		$cadenaOriginal = "|{$VersionTFD}|{$UUID}|{$FechaTimbrado}|{$RFCProvCertif}|{$SelloCFD}|{$NoCertificadoSAT}||";

		// 4. Mapeo de actualización (Extrafields)
		// Usamos un array para iterar y no repetir código
		$map = [
			'cfdi_uuid'                => $UUID,
			'cfdi_no_certificado_cfdi' => $noCertificado,
			'cfdi_sello_cfdi'          => $SelloCFD,
			'cfdi_sello_sat'           => $SelloSAT,
			'cfdi_no_certificado_sat'  => $NoCertificadoSAT,
			'cfdi_cadena_original'     => $cadenaOriginal,
			'cfdi_fecha_timbrado'      => $FechaTimbrado
		];

		//af5e307c-c9fd-404c-9a61-d000e73afce4

		//$object->fetch_optionals();
		foreach ($map as $key => $value) {
			$object->array_options['options_' . $key] = $value;
			$object->updateExtraField($key, $value);
		}

		$boolean = true;
	}

	$boolean = false;

	cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$object->id}]", LOG_INFO);

	return $boolean;
}

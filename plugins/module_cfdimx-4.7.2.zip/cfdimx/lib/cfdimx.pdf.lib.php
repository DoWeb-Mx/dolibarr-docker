<?php
/* Copyright (C) 2026		Rubén Trujillo 			<ruben@doweb.mx>
 * Copyright (C) 2025       Frédéric France         <frederic.france@free.fr>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * \file    cfdimx/lib/cfdimx.lib.php
 * \ingroup cfdimx
 * \brief   Library files with common functions for CFDIMX
 */

/**
 * CONVERT HEXADECIMAL COLOR TO RGB
 */
function cfdimxHexToRgb($hex)
{
	cfdimx_log("Starting [{$hex}]", LOG_INFO);

	// Eliminamos el # si es que viene en el string
	$hex = str_replace("#", "", $hex);

	// Convertimos los pares de hex a decimal
	$r = hexdec(substr($hex, 0, 2));
	$g = hexdec(substr($hex, 2, 2));
	$b = hexdec(substr($hex, 4, 2));

	cfdimx_log("Completed [{$hex}]", LOG_INFO);

	return array($r, $g, $b);
}

/**
 * CONVERT AMOUNT TO LETTERS
 */
function cfdimxAmountInLetters($numero)
{
	cfdimx_log("Starting [{$numero}]", LOG_INFO);

	$formatter = new NumberFormatter("es", NumberFormatter::SPELLOUT);
	$entero = floor($numero);
	$decimales = round(($numero - $entero) * 100);

	$texto = $formatter->format($entero);
	$centavos = str_pad($decimales, 2, "0", STR_PAD_LEFT);

	cfdimx_log("Completed [{$numero}]", LOG_INFO);

	return strtoupper($texto) . " PESOS " . $centavos . "/100 M.N.";
}

/**
 * Agrega la marca de agua de borrador en todas las páginas del PDF. 
 * * @param TCPDF $pdf    Instancia del objeto PDF
 * @param object $object Objeto de la factura
 * @return void
 */
function cfdimxCustomDraftText()
{
	// Usamos global para acceder a los objetos de Dolibarr y TCPDF
	global $conf, $pdf, $object;

	cfdimx_log("Starting [{$object->id}]", LOG_INFO);
	cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	if (!is_object($object) || $object->statut != 0) {
		return;
	}

	$textoMarcaAgua = !empty($conf->global->MAIN_DRAFT_WATERMARK) ? $conf->global->MAIN_DRAFT_WATERMARK : 'BORRADOR';

	$currentPage = $pdf->getPage();
	$totalPages = $pdf->getNumPages();

	// Recorremos todas las páginas del documento
	for ($i = 1; $i <= $totalPages; $i++) {
		$pdf->setPage($i);

		// Guardamos el estado gráfico actual
		$pdf->StartTransform();

		// Configuración de estilo: Rojo claro y transparencia
		$pdf->SetFont('Helvetica', 'B', 80);
		$pdf->SetTextColor(255, 120, 120);
		$pdf->SetAlpha(0.2); // Un poco más tenue para que sea legible lo de abajo

		$cX = 108;
		$cY = 140;
		$angulo = 45;

		// 1. Rotamos el lienzo sobre el centro de la página
		$pdf->Rotate($angulo, $cX, $cY);

		// 2. Calculamos el ancho del texto para centrarlo perfectamente
		$textoWidth = $pdf->GetStringWidth($textoMarcaAgua);

		// 3. Posicionamos el cursor. 
		// X = Centro - (Mitad del ancho del texto)
		// Y = Centro - (Mitad de la altura estimada de la fuente)
		$pdf->SetXY($cX - ($textoWidth / 2), $cY - 15);

		// 4. Dibujamos el texto usando Cell para asegurar que el bloque esté contenido
		$pdf->Cell($textoWidth, 30, $textoMarcaAgua, 0, 0, 'C');

		// Restauramos el estado gráfico y quitamos transparencia
		$pdf->StopTransform();
		$pdf->SetAlpha(1);
	}

	cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$object->id}]", LOG_INFO);

	// Regresamos el puntero a la página donde estaba el flujo original
	$pdf->setPage($currentPage);
}

/**
 * PRINT HEADER SECTION
 */
function cfdimxCustomPdfHeader(&$object)
{
	cfdimx_log("Starting [{$object->id}]", LOG_INFO);
	cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	global $pdf, $conf;

	$object->custom_color1 = cfdimxHexToRgb($conf->global->CFDIMX_CUSTOMPDF_COLOR1);
	$object->custom_color2 = cfdimxHexToRgb($conf->global->CFDIMX_CUSTOMPDF_COLOR2);
	$object->custom_color3 = cfdimxHexToRgb($conf->global->CFDIMX_CUSTOMPDF_COLOR3);

	$posy = 10;
	$col1_x = 10;
	$col_width = 98;
	$separation = 2;
	$col2_x = $col1_x + $col_width + $separation;
	$radius = 3;

	$pdf->SetTextColor(0, 0, 0);

	// --- COLUMNA 1: LOGOTIPO Y DATOS DEL EMISOR ---
	$pdf->SetFillColor($object->custom_color2[0], $object->custom_color2[1], $object->custom_color2[2]);
	$pdf->RoundedRect($col1_x, $posy, $col_width, 44, $radius, '1111', 'F');

	if (!empty($conf->global->CFDIMX_MYCOMPANY_LOGO)) {
		$logo = $conf->global->CFDIMX_MYCOMPANY_LOGO;
	} else {
		$logo = $conf->mycompany->dir_output . '/logos/' . $conf->global->MAIN_INFO_SOCIETE_LOGO;
	}

	$pdf->Image($logo, $col1_x + 2, $posy + 2, 40);

	$name = $conf->global->CFDIMX_MYCOMPANY_NAME;
	$rfc = $conf->global->CFDIMX_MYCOMPANY_VATID;
	$forme = $conf->global->CFDIMX_MYCOMPANY_FORME;

	$address = $conf->global->CFDIMX_MYCOMPANY_STREET;
	$address .= (!empty($conf->global->CFDIMX_MYCOMPANY_NUMEXT)) ? " Int. " . $conf->global->CFDIMX_MYCOMPANY_NUMEXT . "," : "";
	$address .= (!empty($conf->global->CFDIMX_MYCOMPANY_NUMEXT)) ? " Ext. " . $conf->global->CFDIMX_MYCOMPANY_NUMINT . "," : "";
	$address .= (!empty($conf->global->CFDIMX_MYCOMPANY_NUMEXT)) ? " Col. " . $conf->global->CFDIMX_MYCOMPANY_NEIGHBORHOOD . "," : "";
	$address .= (!empty($conf->global->CFDIMX_MYCOMPANY_NUMEXT)) ? " C.P. " . $conf->global->CFDIMX_MYCOMPANY_ZIP . "," : "";
	$address .= (!empty($conf->global->CFDIMX_MYCOMPANY_NUMEXT)) ? " " . $conf->global->CFDIMX_MYCOMPANY_CITY . "," : "";
	$address .= (!empty($conf->global->CFDIMX_MYCOMPANY_NUMEXT)) ? " " . $conf->global->CFDIMX_MYCOMPANY_STATE : "";

	$sizeName = 9;
	$length = strlen($name);

	// switch ($length) {
	// 	case $length > 60:
	// 		$sizeName = 7;
	// 		break;
	// 	case $length > 25:
	// 		$sizeName = 9.4;
	// 		break;
	// 	case $length > 20:
	// 		$sizeName = 10;
	// 		break;
	// 	default:
	// 		$sizeName = 14;
	// 		break;
	// }

	$tipoComprobante = $object->tipoComprobante;
	$titleDoc = $object->titleDoc;

	// RAZON SOCIAL 
	$ancho_maximo_texto = $col_width - 42 - 2;

	$posy_text = 11;
	$pdf->SetFont('helvetica', 'B', $sizeName);
	$pdf->SetXY($col1_x + 45, $posy_text);

	$pdf->MultiCell($ancho_maximo_texto, 4, $name, 0, 'L');

	// RFC
	$posy_text = $posy_text + 8;
	$pdf->SetFont('helvetica', 'B', 7);
	$pdf->SetXY($col1_x + 45, $posy_text);
	$pdf->MultiCell($ancho_maximo_texto, 4, "RFC: ", 0, 'L');
	$pdf->SetFont('helvetica', '', 7);
	$pdf->SetXY($col1_x + 53, $posy_text);
	$pdf->MultiCell($ancho_maximo_texto, 4, $rfc, 0, 'L');

	// DOMICILIO FISCAL EMISOR
	$posy_text = $posy_text + 4;
	$pdf->SetFont('helvetica', 'B', 7);
	$pdf->SetXY($col1_x + 45, $posy_text);
	$pdf->MultiCell($ancho_maximo_texto, 4, "Domicilio Fiscal: ", 0, 'L');

	$posy_text = $posy_text + 4;
	$pdf->SetFont('helvetica', '', 7);
	$pdf->SetXY($col1_x + 45, $posy_text);
	$pdf->MultiCell($ancho_maximo_texto, 4, strtoupper($address), 0, 'L');

	// RÉGIMEN FISCAL
	$posy_text = $posy_text + 14;
	$pdf->SetFont('helvetica', 'B', 7);
	$pdf->SetXY($col1_x + 45, $posy_text);
	$pdf->MultiCell($ancho_maximo_texto, 4, "Régimen Fiscal: ", 0, 'L');
	$posy_text = $posy_text + 4;
	$pdf->SetFont('helvetica', '', 7);
	$pdf->SetXY($col1_x + 45, $posy_text);
	$pdf->MultiCell($ancho_maximo_texto, 4, $forme, 0, 'L');

	// --- COLUMNA 2: INFORMACIÓN DE LA FACTURA ---		
	$pdf->SetDrawColor($object->custom_color1[0], $object->custom_color1[1], $object->custom_color1[2]);
	$pdf->SetFillColor($object->custom_color1[0], $object->custom_color1[1], $object->custom_color1[2]);
	$pdf->SetTextColor($object->custom_color3[0], $object->custom_color3[1], $object->custom_color3[2]);
	$pdf->SetFont('helvetica', 'B', 10);
	$pdf->RoundedRect($col2_x, $posy, $col_width, 8, $radius, '1001', 'F');
	$pdf->SetXY($col2_x, $posy - 1);
	$pdf->Cell($col_width, 10, $titleDoc, 0, 1, 'C', 0);
	$posy = $pdf->GetY() - .90;

	$pdf->SetFillColor($object->custom_color2[0], $object->custom_color2[1], $object->custom_color2[2]);
	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetFont('helvetica', '', 9);
	$pdf->SetXY($col2_x, $posy);
	$pdf->RoundedRect($col2_x, $posy, $col_width, 36, $radius, '0110', 'F');

	$factura_info = array(
		"Tipo de Comprobante:" => $tipoComprobante,
		"Fecha de Expedición:" => (!empty($object->date_validation)) ? date("Y-m-d\TH:i:s", $object->date_validation) : date("Y-m-d\TH:i:s"),
		"Folio fiscal:"        => $object->uuid ?? 'N/A',
		"Folio Interno:"       => $object->ref,
		"Número de Pedido:"    => $object->ref,
		"No. Certificado:"     => $object->certificadoCfdi ?? 'N/A',
		"Exportación:"         => "No aplica"
	);

	foreach ($factura_info as $label => $value) {
		$pdf->SetX($col2_x + 1);
		$pdf->SetFont('helvetica', 'B', 8);
		$pdf->Cell(40, 5, $label, 0, 0, 'L');
		$pdf->SetFont('helvetica', '', 8);
		$pdf->Cell(50, 5, $value, 0, 1, 'L');
	}

	// --- PROTECCIÓN: GUARDAMOS LA POSICIÓN Y ESTADO ANTES DE LA PLECA ---
	$currentY = $pdf->GetY();
	$currentX = $pdf->GetX();

	cfdimx_log("Invoice current status: " . $object->statut, LOG_DEBUG);
	cfdimx_log("Object : " . json_encode($object), LOG_DEBUG);

	if ($object->statut == 3) {
		$pdf->StartTransform();

		// Estilos específicos para la pleca
		$pdf->SetFillColor(200, 0, 0);
		$pdf->SetTextColor(255, 255, 255);
		$pdf->SetFont('helvetica', 'B', 22);

		// Aplicamos la rotación
		$pdf->Rotate(-35, 185, 35);

		// Dibujamos el rectángulo
		$pdf->Rect(140, 12, 90, 12, 'F');

		// Texto centrado en la pleca
		$pdf->SetXY(140, 13);
		$pdf->Cell(90, 10, "CANCELADA", 0, 0, 'C');

		$pdf->StopTransform();

		// --- PROTECCIÓN EXTRA: RESETEAMOS ESTADOS MANUALMENTE ---
		$pdf->SetXY($currentX, $currentY); // Regresamos el "lápiz" a donde estaba
		$pdf->SetFont('helvetica', '', 8); // Reset de fuente
		$pdf->SetTextColor(0, 0, 0);       // Reset de color de texto
		$pdf->SetDrawColor(0, 0, 0);       // Reset de color de línea
	}

	cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$object->id}]", LOG_INFO);

	// Retornamos el Y que capturamos antes de la pleca para que el cuerpo no se mueva
	return $currentY;
}

/**
 * PRINT RECEPTOR SECTION
 */
function cfdimxCustomPdfReceptor(&$object)
{
	global $db, $pdf, $conf;

	cfdimx_log("Starting [{$object->id}]", LOG_INFO);
	cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	$posy = $pdf->GetY() + 3;
	$col_start_x = 10;
	$full_width = 198; // Ancho total para ocupar casi toda la hoja Carta (215.9mm)
	$radius = 2.5;
	$line_height = 6;

	// --- CAJA ÚNICA GRIS (FONDO) ---
	$pdf->SetDrawColor($object->custom_color2[0], $object->custom_color2[1], $object->custom_color2[2]);
	$pdf->SetFillColor($object->custom_color2[0], $object->custom_color2[1], $object->custom_color2[2]);
	// Un solo rectángulo que envuelve todo
	$pdf->RoundedRect($col_start_x, $posy, $full_width, 42, $radius, '1111', 'DF');

	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetFont('helvetica', '', 8);

	// Definición de posiciones X para las 4 columnas (ajustables)
	$c1 = $col_start_x + 2;  // Etiquetas Col 1
	$c2 = $c1 + 25;          // Valores Col 1
	$c3 = $col_start_x + 100; // Etiquetas Col 2
	$c4 = $c3 + 30;          // Valores Col 2

	// --- FILA 1 ---
	$pdf->SetXY($c1, $posy + 1);

	$pdf->SetFont('helvetica', 'B', 7);
	$pdf->Cell(25, $line_height, "Razón Social:", 0, 0, 'L');

	$pdf->SetFont('helvetica', '', 7);
	$pdf->Cell(75, $line_height, $object->receptor_nombre, 0, 0, 'L');

	$pdf->SetFont('helvetica', 'B', 7);
	$pdf->Cell(25, $line_height, "Moneda:", 0, 0, 'L');
	$pdf->SetFont('helvetica', '', 7);
	$pdf->Cell(40, $line_height, $object->multicurrency_code ?? $conf->currency, 0, 1, 'L');

	// if ($object->thirdparty == null) {
	// 	dol_include_once('/societe/class/societe.class.php');

	// 	$thirdparty = new Societe($db);

	// 	$result = $thirdparty->fetch($object->socid);

	// 	if ($result > 0) {
	// 		$object->thirdparty = $thirdparty;
	// 	}
	// }

	cfdimx_log("tercero: " . json_encode($object->thirdparty), LOG_DEBUG);

	cfdimx_log("object: " . json_encode($object), LOG_DEBUG);

	// --- FILA 2 ---
	$pdf->SetX($c1);
	$pdf->SetFont('helvetica', 'B', 7);
	$pdf->Cell(25, $line_height, "RFC:", 0, 0, 'L');
	$pdf->SetFont('helvetica', '', 7);
	$pdf->Cell(75, $line_height, $object->receptor_rfc, 0, 0, 'L');

	$pdf->SetFont('helvetica', 'B', 7);
	$pdf->Cell(25, $line_height, "Tipo de cambio:", 0, 0, 'L');
	$pdf->SetFont('helvetica', '', 7);
	//$pdf->Cell(75, $line_height, ($object->thirdparty->multicurrency_code == 'MXN') ? 'N/A' : '1', 0, 1, 'L');
	$pdf->Cell(75, $line_height, ($object->thirdparty->multicurrency_code == 'MXN') ? 'N/A' : '1', 0, 1, 'L');

	//--- FILA 3 (Domicilio con MultiCell por si es largo) ---
	$address = $object->receptor_address;
	$address .= (!empty($object->receptor_numext)) ? " Ext. " . $object->receptor_numext . "," : "";
	$address .= (!empty($object->receptor_numint)) ? " Int. " . $object->receptor_numint . "," : "";
	$address .= (!empty($object->receptor_colonia)) ? " Col. " . $object->receptor_colonia . "," : "";
	$address .= (!empty($object->receptor_zip)) ? " C.P. " . $object->receptor_zip . "," : "";
	$address .= (!empty($object->receptor_town)) ?  " " . $object->receptor_town . "," : "";
	$address .= (!empty($object->receptor_state)) ?  " " . $object->receptor_state . "," : "";
	$address .= (!empty($object->receptor_country)) ?  " " . $object->receptor_country . "," : "";

	$current_y = $pdf->GetY();
	$pdf->SetXY($c1, $current_y);
	$pdf->SetFont('helvetica', 'B', 7);
	$pdf->Cell(25, $line_height + 6, "Domicilio Fiscal:", 0, 0, 'L');
	$pdf->SetFont('helvetica', '', 7);
	$pdf->MultiCell(75, $line_height + 6, strtoupper($address), 0, 'L', false, 1, $c2, $current_y, true, 0, false, true, $line_height + 6, 'M');

	$pdf->SetXY($c3 + 2, $current_y);
	$pdf->SetFont('helvetica', 'B', 7);
	$pdf->Cell(25, $line_height + 6, "Método de Pago:", 0, 0, 'L');
	$pdf->SetFont('helvetica', '', 7);
	$pdf->Cell(75, $line_height + 6, $object->metodoPago, 0, 1, 'L');
	$pdf->SetY(max($pdf->GetY(), $current_y + $line_height + 6));

	//--- FILA 4 ---
	$current_y = $pdf->GetY();
	$pdf->SetXY($c1, $current_y);
	$pdf->SetFont('helvetica', 'B', 7);
	$pdf->Cell(25, $line_height + 3, "Régimen Fiscal:", 0, 0, 'L');
	$pdf->SetFont('helvetica', '', 7);
	$pdf->MultiCell(75, $line_height + 3, $object->receptor_regimen, 0, 'L', false, 1, $c2, $current_y, true, 0, false, true, $line_height + 3, 'M');

	$pdf->SetXY($c3 + 2, $current_y);
	$pdf->SetFont('helvetica', 'B', 7);
	$pdf->Cell(25, $line_height + 3, "Forma de Pago:", 0, 0, 'L');
	$pdf->SetFont('helvetica', '', 7);
	$pdf->Cell(75, $line_height + 3, $object->formaPago, 0, 1, 'L');
	$pdf->SetY(max($pdf->GetY(), $current_y + $line_height + 3));

	// --- FILA 5 ---
	$pdf->SetX($c1);
	$pdf->SetFont('helvetica', 'B', 7);
	$pdf->Cell(25, $line_height, "Uso de CFDI:", 0, 0, 'L');
	$pdf->SetFont('helvetica', '', 7);
	$pdf->Cell(75, $line_height, $object->receptor_uso, 0, 0, 'L');
	$pdf->SetFont('helvetica', 'B', 7);
	$pdf->Cell(26, $line_height, "Lugar Expedición:", 0, 0, 'L');
	$pdf->SetFont('helvetica', '', 7);
	$pdf->Cell(75, $line_height, $conf->global->CFDIMX_MYCOMPANY_ZIP, 0, 1, 'L');

	cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$object->id}]", LOG_INFO);

	return $pdf->GetY() + 5;
}

/**
 * PRINT FOOTER WITH NUMBER PAGE
 */
function cfdimxCustomPdfFooter()
{
	global $pdf, $object;

	cfdimx_log("Starting [{$object->id}]", LOG_INFO);
	cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	// Esto evita que TCPDF agregue una página en blanco cuando intentamos imprimir el calce a -15mm
	$bMargin = $pdf->getBreakMargin();
	$auto_page_break = $pdf->getAutoPageBreak();
	$pdf->SetAutoPageBreak(false, 0);

	$footer_height = 15;
	$margin_side = 10;
	$full_width = 196; // Ajustado para centrar con el contenido

	$pdf->SetY(-$footer_height);
	$pdf->SetFont('helvetica', '', 7);
	$pdf->SetTextColor(100, 100, 100);

	// --- LADO IZQUIERDO: TEXTO FIJO --- 
	$infoText = ($object->array_options['options_cfdi_tipofactura'] == "FAC")
		? "Este documento es una representación impresa de un CFDI - Versión: 4.0"
		: "Este documento no es un comprobante fiscal. Es una representación impresa de una nota de venta o remisión.";

	$pdf->SetX($margin_side);

	$pdf->Cell(130, 4, $infoText, 0, 0, 'L');

	// --- LADO DERECHO: PAGINACIÓN DINÁMICA --- 
	$texto_paginacion = "Hoja " . $pdf->getAliasNumPage() . " de " . $pdf->getAliasNbPages();

	$pdf->Cell($full_width - 130, 4, $texto_paginacion, 0, 1, 'R');

	$pdf->SetAutoPageBreak($auto_page_break, $bMargin);

	cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$object->id}]", LOG_INFO);
}

/**
 * PRINT IN NEW PAGES THE STATIC ELEMENTS
 */
function cfdimxDrawPageStaticElements(&$object)
{
	global $conf;

	if ($conf->global->CFDIMX_REPEATHEADER) {
		cfdimxCustomPdfHeader($object);
	}

	if ($conf->global->CFDIMX_REPEATRECEIVER) {
		cfdimxCustomPdfReceptor($object);
	}

	if (empty($GLOBALS['cfdimx_is_total_section'])) {
		cfdimxDrawDetailTableHeader($object);
	}
}

/**
 * PRINT HEADER FOR DETAILS
 */
function cfdimxDrawDetailTableHeader(&$object)
{
	global $pdf;

	cfdimx_log("Starting [{$object->id}]", LOG_INFO);
	cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	$posy = $pdf->GetY() + 4;
	$col_start_x = 10;
	$full_width = 198;
	$radius = 2.5;

	$pdf->SetDrawColor($object->custom_color1[0], $object->custom_color1[1], $object->custom_color1[2]);
	$pdf->SetFillColor($object->custom_color1[0], $object->custom_color1[1], $object->custom_color1[2]);
	$pdf->SetTextColor($object->custom_color3[0], $object->custom_color3[1], $object->custom_color3[2]);
	$pdf->SetFont('helvetica', 'B', 8);

	$pdf->RoundedRect($col_start_x, $posy, $full_width, 8, $radius, '1001', 'DF');

	$w_cant = 20;
	$w_desc = 75;
	$w_prod = 25;
	$w_unit = 25;
	$w_pu = 25;
	$w_import = 28;

	$pdf->SetXY($col_start_x, $posy);
	$pdf->Cell($w_cant, 8, "Cantidad", 0, 0, 'C');
	$pdf->Cell($w_desc, 8, "Descripción", 0, 0, 'L');
	$pdf->Cell($w_prod, 8, "C. Prod/Serv", 0, 0, 'C');
	$pdf->Cell($w_unit, 8, "Unidad", 0, 0, 'C');
	$pdf->Cell($w_pu, 8, "P. Unitario", 0, 0, 'R');
	$pdf->Cell($w_import - 2, 8, "Importe", 0, 1, 'R');

	cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$object->id}]", LOG_INFO);
}

/**
 * PRINT DETAIL FROM INVOICE
 */
function cfdimxCustomPdfDetail(&$object)
{
	global $conf, $pdf;

	cfdimx_log("Starting [{$object->id}]", LOG_INFO);
	cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	$col_start_x = 10;
	$full_width = 198;
	$radius = 2.5;

	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetFont('helvetica', '', 7);

	$i = 0;
	$total_lines = count($object->lineas);
	$tab_taxes = array();

	foreach ($object->lineas as $line) {

		$i++;

		if ($object->element == 'facture') {

			$qty = (float)number_format($line->qty, 6, ".", "");

			$txt_desc = "No. Identificación / SKU: " . $line->ref . " - " . $line->product_desc;
			$txt_desc .= ($line->date_start > 0 && $line->date_end > 0) ? "\n(De " . date("d/m/Y", $line->date_start) . " a " . date("d/m/Y", $line->date_end) . ")" : "";
			$txt_desc .= "\n" . $line->description;

			$txt_vat = "Sí objeto de impuesto";

			$claveProdServ = cfdimxGetValueFrom('product_extrafields', $line->fk_product, 'cfdi_claveprodserv', 'fk_object');

			$claveUnidad = cfdimxGetValueFrom('product_extrafields', $line->fk_product, 'cfdi_claveunidad', 'fk_object');
		} else {

			$qty = (float)number_format(1, 6, ".", "");

			$txt_desc = "Pago";

			$txt_vat = "No objeto de impuesto";

			$claveProdServ = "84111506";

			$claveUnidad = "ACT";
		}

		$pdf->setCellPaddings(1, 1.2, 1, 1.2);

		$h_desc_calc = $pdf->getStringHeight(75, $txt_desc);

		$h_base = max(6, $h_desc_calc);
		$h_cell_total = $h_base;

		cfdimxCheckAndAddPage($object, $h_cell_total + 5);

		$start_y = $pdf->GetY();

		$pdf->SetFillColor($object->custom_color2[0], $object->custom_color2[1], $object->custom_color2[2]);
		$pdf->RoundedRect($col_start_x, $start_y, $full_width, $h_cell_total, $radius, '0000', 'F');

		$pdf->SetTextColor(0, 0, 0);
		$pdf->SetFont('helvetica', '', 7);

		$pdf->SetXY($col_start_x, $start_y);

		$pdf->Cell(20, $h_base, $qty, 0, 0, 'C', 0, '', 0, false, 'T', 'M');
		$pdf->MultiCell(75, $h_base, $txt_desc, 0, 'J', false, 0, $pdf->GetX(), $start_y, true, 0, false, true, $h_base, 'M');
		$pdf->Cell(25, $h_base, $claveProdServ, 0, 0, 'C', 0, '', 0, false, 'T', 'M');
		$pdf->Cell(25, $h_base, $claveUnidad, 0, 0, 'C', 0, '', 0, false, 'T', 'M');
		$pdf->Cell(25, $h_base, "$ " . price(abs($line->subprice)), 0, 0, 'R', 0, '', 0, false, 'T', 'M');
		$pdf->Cell(26, $h_base, "$ " . price(abs($line->total_ht)), 0, 0, 'R', 0, '', 0, false, 'T', 'M');

		// Volvemos a la base del bloque para imprimir el impuesto
		$pdf->SetY($start_y + $h_cell_total);
		$pdf->setCellPaddings(1, 0, 1, 0);

		$pdf->SetFont('helvetica', 'I', 6.5);
		$pdf->SetTextColor(50, 50, 50);
		$pdf->SetX($col_start_x);

		$pdf->Cell($full_width - 1, 4, $txt_vat, 0, 1, 'R');

		$pdf->Ln(0.5);

		// Restauramos la fuente original para la siguiente partida
		$pdf->SetFont('helvetica', '', 8);

		if ($conf->global->CFDIMX_GROUPVAT) {
			//Agrupando por tasa
			$key = $line->tva_tx;
			if (!isset($tab_taxes[$key])) $tab_taxes[$key] = array('base' => 0, 'amount' => 0, 'type' => 'IVA', 'factor' => 'Tasa');
			$tab_taxes[$key]['type'] = "IVA";
			$tab_taxes[$key]['factor'] = "Tasa";
			$tab_taxes[$key]['base'] += abs($line->total_ht);
			$tab_taxes[$key]['amount'] += abs($line->total_tva);
		} else {
			//Sin agrupar
			$tab_taxes[$i]['type'] = "IVA";
			$tab_taxes[$i]['factor'] = "Tasa";
			$tab_taxes[$i]['cuota'] = (abs($line->tva_tx) > 0) ? abs($line->tva_tx) : 'Exento';
			$tab_taxes[$i]['base'] = (abs($line->tva_tx) > 0) ? abs($line->total_ht) : 'Exento';
			$tab_taxes[$i]['amount'] = (abs($line->total_tva) > 0) ? abs($line->total_tva) : '0';
		}
	}

	$GLOBALS['cfdimx_is_total_section'] = true;
	// Guardamos los impuestos en el objeto para usarlos en Total()	

	$object->custom_tab_taxes = $tab_taxes;

	/**
	 * TABLA DE IMPUESTOS
	 */

	$col_start_x = 10;
	$full_width = 198;
	$radius = 2.5;
	$w_left_col = $full_width - 60;

	if (is_array($object->custom_color1)) {
		$c1 = $object->custom_color1;
	} else {
		$c1 = function_exists('cfdimxHexToRgb') && !empty($object->custom_color1) ? cfdimxHexToRgb($object->custom_color1) : array(50, 50, 50);
	}

	$h_tax_table = 0;
	if ($conf->global->CFDIMX_SHOWVAT && !empty($object->custom_tab_taxes)) {
		$h_tax_table = (count($object->custom_tab_taxes) * 5) + 10;
	}

	$posy = $pdf->GetY() + 2;

	if ($conf->global->CFDIMX_SHOWVAT) {
		if ($object->element == 'facture') {
			if (!empty($object->custom_tab_taxes)) {
				if (cfdimxCheckAndAddPage($object, $h_tax_table)) {
					$posy = $pdf->GetY() + 2;
				}
				$w_tax = 28;
				$h_row = 5;
				$num_rows = count($object->custom_tab_taxes);
				$full_tax_width = $w_tax * 5;

				$pdf->SetFillColor($c1[0], $c1[1], $c1[2]);
				$pdf->SetDrawColor($c1[0], $c1[1], $c1[2]);
				$pdf->RoundedRect($col_start_x, $posy, $full_tax_width, $h_row, $radius, '1001', 'DF');

				$pdf->SetTextColor(255, 255, 255);
				$pdf->SetFont('helvetica', 'B', 7);
				$pdf->SetXY($col_start_x, $posy);
				$pdf->setCellPaddings(0, 0.5, 0, 0);

				$pdf->Cell($w_tax, $h_row, "Impuesto", 0, 0, 'C');
				$pdf->Cell($w_tax, $h_row, "Tipo Factor", 0, 0, 'C');
				$pdf->Cell($w_tax, $h_row, "Tasa o Cuota", 0, 0, 'C');
				$pdf->Cell($w_tax, $h_row, "Base", 0, 0, 'C');
				$pdf->Cell($w_tax, $h_row, "Importe", 0, 1, 'C');

				$pdf->SetTextColor(0, 0, 0);
				$pdf->SetFont('helvetica', '', 7);
				$pdf->setCellPaddings(0, 0.8, 0, 0.8);

				foreach ($object->custom_tab_taxes as $rate => $data) {

					$pdf->SetX($col_start_x);
					$pdf->Cell($w_tax, $h_row, $data['type'], 0, 0, 'C');
					$pdf->Cell($w_tax, $h_row, $data['factor'], 0, 0, 'C');
					$pdf->Cell($w_tax, $h_row, (is_numeric($data['cuota'])) ? number_format($data['cuota'] / 100, 4) : $data['cuota'], 0, 0, 'C');
					$pdf->Cell($w_tax, $h_row, (is_numeric($data['base'])) ?  price($data['base']) : $data['base'], 0, 0, 'C');
					$pdf->Cell($w_tax - 1, $h_row, (is_numeric($data['amount'])) ?  price($data['amount']) : $data['amount'], 0, 0, 'C');
					$pdf->Cell(1, $h_row, "", 0, 1, 'R');
				}
			}
		}
		$posy = $pdf->GetY() + 2;
	}
	/**
	 * TERMINA TABLA DE IMPUESTOS
	 */

	/**
	 * OBSERVACIONES
	 */
	if (!empty($object->note_public)) {

		if (cfdimxCheckAndAddPage($object, 10)) {
			$posy = $pdf->GetY() + 2; // Readjustamos Y por si saltó de hoja
		}

		$pdf->SetTextColor(0, 0, 0);
		$pdf->SetFont('helvetica', 'B', 9);
		$pdf->SetXY($col_start_x, $posy);
		$pdf->Cell(25, 5, "Observaciones:", 0, 0, 'L');
		$pdf->SetFont('helvetica', '', 7);
		$pdf->SetXY($col_start_x, $posy + 4);
		$pdf->Cell(140, 5, dol_string_nohtmltag($object->note_public), 0, 1, 'L');
		$posy = $pdf->GetY();
	}
	/**
	 * TERMINA OBSERVACIONES
	 */

	/**
	 * IMPORTE LETRAS
	 */
	if (cfdimxCheckAndAddPage($object, 10)) {
		$posy = $pdf->GetY() + 2; // Readjustamos Y por si saltó de hoja
	}
	if ($object->element == 'facture' || $object->element == 'payment') {
		$importe = abs($object->total);
	}
	$importe = 0.0;

	$pdf->SetFont('helvetica', 'B', 10);
	$pdf->SetTextColor($c1[0], $c1[1], $c1[2]);
	$pdf->SetXY($col_start_x, $posy + 3);
	$pdf->MultiCell($w_left_col, 5, cfdimxAmountInLetters($importe), 0, 'L');
	$posy = $pdf->GetY() + 3;
	/**
	 * TERMINA IMPORTE LETRAS
	 */

	/**
	 * CFDI'S RELACIONADOS
	 */
	if (!empty($object->tipoRelacion)) {
		if (cfdimxCheckAndAddPage($object, 10)) {
			$posy = $pdf->GetY() + 2; // Readjustamos Y por si saltó de hoja
		}

		$id = $object->tipoRelacion;
		$description = cfdimxGetValueFrom('cfdimx_catalogue', $id, 'name', 'id');
		$UUID = cfdimxGetValueFrom('facture_extrafields', $object->facture_source, 'cfdi_uuid', 'fk_object');

		$pdf->SetTextColor(0, 0, 0);
		$pdf->SetFont('helvetica', 'B', 9);
		$pdf->SetXY($col_start_x, $posy);
		$pdf->Cell(25, 5, "Relación de CFDI's:", 0, 0, 'L');

		$pdf->SetFont('helvetica', 'B', 7);
		$pdf->SetXY($col_start_x, $posy + 4);
		$pdf->Cell(140, 5, "T. Relación: ", 0, 1, 'L');
		$pdf->SetFont('helvetica', '', 7);
		$pdf->SetXY($col_start_x + 17, $posy + 4);
		$pdf->Cell(140, 5, dol_string_nohtmltag($description), 0, 1, 'L');
		$posy = $pdf->GetY();

		$pdf->SetFont('helvetica', 'B', 7);
		$pdf->SetXY($col_start_x, $posy);
		$pdf->Cell(140, 5, "UUID's: ", 0, 1, 'L');
		$pdf->SetFont('helvetica', '', 7);
		$pdf->SetXY($col_start_x + 17, $posy);
		$pdf->Cell(140, 5, dol_string_nohtmltag($UUID), 0, 1, 'L');
		$posy = $pdf->GetY() + 2;
	}
	/**
	 * TERMINA CFDI'S RELACIONADOS
	 */

	/**
	 * CONDICIONES DE PAGO
	 */
	if (!empty($object->cond_reglement_doc)) {
		if (cfdimxCheckAndAddPage($object, 15)) {
			$posy = $pdf->GetY() + 2; // Readjustamos Y por si saltó de hoja
		}

		$pdf->SetTextColor(0, 0, 0);
		$pdf->SetFont('helvetica', 'B', 9);
		$pdf->SetXY($col_start_x, $posy);
		$pdf->Cell(25, 5, "Condiciones de pago:", 0, 0, 'L');
		$pdf->SetFont('helvetica', '', 7);
		$pdf->SetXY($col_start_x, $posy + 4);
		$pdf->Cell(140, 5, dol_string_nohtmltag($object->cond_reglement_doc), 0, 1, 'L');
		//$posy = $pdf->GetY() + 4;
		//$pdf->SetY($posy);
	}
	/**
	 * TERMINA CONDICIONES DE PAGO
	 */

	cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$object->id}]", LOG_INFO);

	return $pdf->GetY();
}

/**
 * PRINT TOTAL SECTION (VAT+DIGITAL SIGN + QR)
 */
function cfdimxCustomPdfTotal(&$object)
{
	global $conf, $pdf;

	$GLOBALS['cfdimx_is_total_section'] = true;

	cfdimx_log("Starting [{$object->id}]", LOG_INFO);
	cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	$col_start_x = 10;
	$full_width = 198;
	//$radius = 2.5;
	$w_left_col = $full_width - 60;

	if (is_array($object->custom_color1)) {
		$c1 = $object->custom_color1;
	} else {
		$c1 = function_exists('cfdimxHexToRgb') && !empty($object->custom_color1) ? cfdimxHexToRgb($object->custom_color1) : array(50, 50, 50);
	}

	$posy_sellos = $pdf->GetY() + 2;
	$posy_qr = $pdf->GetY() + 2;
	$pdf->SetTextColor(0, 0, 0);
	$x_totals = $col_start_x + $full_width - 55;

	if ($object->element == 'facture') {

		if (cfdimxCheckAndAddPage($object, 0)) {
			$posy_sellos = $pdf->GetY(); // Readjustamos Y por si saltó de hoja
		}

		// --- CUADRO DE TOTALES ---		
		if (is_array($object->custom_color2)) {
			$c2 = $object->custom_color2;
		} else {
			$c2 = function_exists('cfdimxHexToRgb') && !empty($object->custom_color2) ? cfdimxHexToRgb($object->custom_color2) : array(240, 240, 240);
		}

		$x_totals = $col_start_x + $full_width - 55;

		$pdf->SetFillColor($c2[0], $c2[1], $c2[2]);
		$pdf->RoundedRect($x_totals, $posy_sellos, 55, 20, 2.5, '1111', 'F');

		$posy_totales = $posy_sellos + 2;

		$pdf->SetTextColor(0, 0, 0);
		$pdf->SetFont('helvetica', 'B', 8);
		$pdf->SetXY($x_totals + 2, $posy_totales);
		$pdf->Cell(25, 5, "SUBTOTAL:", 0, 0, 'L');
		$pdf->Cell(25, 5,  price(abs($object->base)), 0, 1, 'R');

		$pdf->SetX($x_totals + 2);
		$pdf->Cell(25, 5, "+ IVA (16%):", 0, 0, 'L');
		$pdf->Cell(25, 5,  price(abs($object->tva)), 0, 1, 'R');

		$pdf->SetDrawColor($c1[0], $c1[1], $c1[2]); // Línea del color principal
		$pdf->SetLineWidth(0.8);

		$pdf->Line($x_totals + 2, $pdf->GetY() + 1, $x_totals + 53, $pdf->GetY() + 1);
		$pdf->Ln(2);

		$pdf->SetX($x_totals + 2);
		$pdf->SetFont('helvetica', 'B', 9);
		$pdf->Cell(25, 5, "TOTAL:", 0, 0, 'L');
		$pdf->Cell(25, 5, "$ " . price(abs($object->total)), 0, 1, 'R');
		$posy_qr = $pdf->GetY() + 4;
	}


	// --- SELLOS Y QR ---	
	if ($object->element == 'facture' || $object->element == 'payment') {
		$pdf->SetY($posy_sellos);

		$cadena     = (!empty($object->cadenaOriginal) ? $object->cadenaOriginal : 'No disponible');
		$sello_cfdi = (!empty($object->selloCfdi) ? $object->selloCfdi : 'No disponible');
		$sello_sat  = (!empty($object->selloSat) ? $object->selloSat : 'No disponible');
		$cert_sat   = (!empty($object->certificadoSat) ? $object->certificadoSat : 'No disponible');

		$pdf->SetFont('helvetica', 'B', 8.5);
		$pdf->SetX($col_start_x);
		$pdf->MultiCell($w_left_col, 4, "CADENA ORIGINAL DEL COMPLEMENTO DE CERTIFICACION DIGITAL DEL SAT", 0, 'L');
		$pdf->SetFont('helvetica', '', 6);
		$pdf->MultiCell($w_left_col, 2.5, $cadena, 0, 'L');
		$pdf->Ln(0.5);
		$posy = $pdf->GetY() + 2;

		$pdf->SetXY($col_start_x, $posy);
		$pdf->SetFont('helvetica', 'B', 8.5);
		$pdf->MultiCell($w_left_col, 4, "SELLO DIGITAL DEL CFDI", 0, 'L');
		$pdf->SetFont('helvetica', '', 6);
		$pdf->MultiCell($w_left_col, 2.5, $sello_cfdi, 0, 'L');
		$pdf->Ln(0.5);
		$posy = $pdf->GetY() + 2;

		$pdf->SetXY($col_start_x, $posy);
		$pdf->SetFont('helvetica', 'B', 8.5);
		$pdf->MultiCell($w_left_col, 4, "SELLO DIGITAL DEL SAT", 0, 'L');
		$pdf->SetFont('helvetica', '', 6);
		$pdf->MultiCell($w_left_col, 2.5, $sello_sat, 0, 'L');
		$posy = $pdf->GetY() + 2;

		$pdf->SetXY($col_start_x, $posy);
		$pdf->SetFont('helvetica', 'B', 8.5);
		$pdf->Cell($w_left_col, 4, "No de Serie del Certificado del SAT: ", 0, 1, 'L');
		$pdf->SetFont('helvetica', '', 6);
		$pdf->Cell($w_left_col, 4, $cert_sat, 0, 1, 'L');

		// --- 4. CÓDIGO QR ---	
		$monto = $object->total_ttc;
		$monto_formateado = number_format($monto, 6, '.', '');
		$monto_final = rtrim(rtrim($monto_formateado, '0'), '.');

		$qr_url = "https://verificacfdi.facturaelectronica.sat.gob.mx/default.aspx?";
		$qr_url .= "&id=" . $object->array_options['options_cfdi_uuid'];
		$qr_url .= "&re=" . $conf->global->CFDIMX_MYCOMPANY_VATID ?? '';
		$qr_url .= "&rr=" . $object->thirdparty->idprof1 ?? '';
		$qr_url .= "&tt=" . $monto_final;
		$qr_url .= "&fe=" . substr($object->array_options['options_cfdi_sello_cfdi'], -8);
		if (!empty($qr_url)) {
			$pdf->SetXY($col_start_x, $posy_qr);
			$pdf->write2DBarcode($qr_url, 'QRCODE,H', $x_totals + 8, $posy_qr, 40, 40);
		}
	}

	$GLOBALS['cfdimx_is_total_section'] = false;


	cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$object->id}]", LOG_INFO);

	return $pdf->GetY();
}

/**
 * VALIDATE IF IS NECESARY ADD NEW PAGE
 */
function cfdimxCheckAndAddPage(&$object, $h)
{
	global $pdf;
	$boolean = false;

	if ($pdf->GetY() + $h > ($pdf->getPageHeight() - 20)) {
		// 1. Antes de saltar, dibujamos el footer de la página que termina
		cfdimxCustomPdfFooter();

		// 2. Saltamos de página
		$pdf->AddPage('P', 'LETTER');

		$pdf->SetY(10);

		if ($object->element == "facture") {

			cfdimxDrawPageStaticElements($object);
		}

		$boolean = true;
	}

	return $boolean;
}

/**
 * PAYMENTS SECTION
 */
function cfdimxPaymentDetail(&$object)
{
	global $pdf;

	cfdimx_log("Starting [{$object->id}]", LOG_INFO);
	cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	$posy = $pdf->GetY() + 68;

	/**
	 * GENERAL PAYMENT DATA
	 */
	if (cfdimxCheckAndAddPage($object, 120)) {
		$posy = $pdf->GetY() + 2; // Readjustamos Y por si saltó de hoja
	}
	$pdf->SetY($posy);
	$col_start_x = 10;
	$full_width = 198;
	$radius = 2.5;
	$w_left_col = $full_width - 60;

	$pdf->SetFont('helvetica', 'B', 8.5);
	$pdf->SetX($col_start_x);
	$pdf->MultiCell($w_left_col, 4, "DATOS GENERALES DEL COMPLEMENTO DE PAGO", 0, 'L');
	$pdf->Ln(0.5);
	$posy = $pdf->GetY() + 2;

	$pdf->SetDrawColor($object->custom_color1[0], $object->custom_color1[1], $object->custom_color1[2]);
	$pdf->SetFillColor($object->custom_color1[0], $object->custom_color1[1], $object->custom_color1[2]);
	$pdf->SetTextColor($object->custom_color3[0], $object->custom_color3[1], $object->custom_color3[2]);
	$pdf->SetFont('helvetica', 'B', 8);

	$pdf->RoundedRect($col_start_x, $posy, $full_width, 8, $radius, '1001', 'DF');

	// 196
	$w_col1 = 23;
	$w_col2 = 75;
	$w_col3 = 75;
	$w_col4 = 23;

	$pdf->SetXY($col_start_x, $posy);
	$pdf->Cell($w_col1, 8, "No.", 0, 0, 'C');
	$pdf->Cell($w_col2, 8, "Forma de pago", 0, 0, 'C');
	$pdf->Cell($w_col3, 8, "Fecha y hora de pago", 0, 0, 'C');
	$pdf->Cell($w_col4 - 5, 8, "Total Pago", 0, 1, 'R');

	$posy = $posy + 7;

	$pdf->SetXY($col_start_x, $posy);

	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetFont('helvetica', '', 7);

	$pdf->SetFillColor($object->custom_color2[0], $object->custom_color2[1], $object->custom_color2[2]);
	$pdf->RoundedRect($col_start_x, $posy + 1, $full_width, 8, $radius, '0110', 'F');

	$pdf->Cell($w_col1, 8, "1", 0, 0, 'C', 0, '', 0, false, 'T', 'M');
	$pdf->Cell($w_col2, 8, "03 - Transferencia electrónica de fondos", 0, 0, 'C', 0, '', 0, false, 'T', 'M');
	$pdf->Cell($w_col3, 8, "2026-04-28 12:00:00", 0, 0, 'C', 0, '', 0, false, 'T', 'M');
	$pdf->Cell($w_col4 - 5, 8, "$ " . price(abs(1740)) . " MXN", 0, 0, 'R', 0, '', 0, false, 'T', 'M');
	$posy = $pdf->GetY() + 2;

	/**
	 * RELATED DOCUMENTS
	 */
	// if (cfdimxCheckAndAddPage($object, 60)) {
	// 	$posy = $pdf->GetY() + 2; // Readjustamos Y por si saltó de hoja
	// }
	$pdf->SetTextColor(0, 0, 0);
	$pdf->SetFont('helvetica', 'B', 8.5);
	$pdf->SetX($col_start_x);
	$pdf->MultiCell($w_left_col, $posy, "DOCUMENTOS RELACIONADOS", 0, 'L');
	$pdf->Ln(0.5);
	$posy = $pdf->GetY() + 2;

	$pdf->SetDrawColor($object->custom_color1[0], $object->custom_color1[1], $object->custom_color1[2]);
	$pdf->SetFillColor($object->custom_color1[0], $object->custom_color1[1], $object->custom_color1[2]);
	$pdf->SetTextColor($object->custom_color3[0], $object->custom_color3[1], $object->custom_color3[2]);
	$pdf->SetFont('helvetica', 'B', 8);

	$pdf->RoundedRect($col_start_x, $posy, $full_width, 8, $radius, '1001', 'DF');

	// // 196
	// $w_col1 = 32;
	// $w_col2 = 32;
	// $w_col3 = 32;
	// $w_col4 = 32;
	// $w_col5 = 32;
	// $w_col6 = 32;

	// $pdf->SetXY($col_start_x, $posy);
	// $pdf->Cell($w_col1, 8, "Folio", 0, 0, 'C');
	// $pdf->Cell($w_col2, 8, "UUID", 0, 0, 'C');
	// $pdf->Cell($w_col3, 8, "Método de pago", 0, 0, 'C');
	// $pdf->Cell($w_col4, 8, "Saldo anterior", 0, 0, 'C');
	// $pdf->Cell($w_col5, 8, "Saldo pendiente", 0, 0, 'C');
	// $pdf->Cell($w_col6 - 5, 8, "Monto Pagado", 0, 1, 'R');


	cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$object->id}]", LOG_INFO);
}

/**
 * CREATE CUSTOM PDF FORMAT FOR CFDI
 */
function cfdimxCustomPdf(&$object, &$sPath, &$sFile)
{
	cfdimx_log("Starting [{$object->id}]", LOG_INFO);
	cfdimx_log("Starting [{$object->id}][{$object->ref}]", LOG_DEBUG);

	global $pdf, $conf;

	require_once DOL_DOCUMENT_ROOT . '/core/lib/pdf.lib.php';
	require_once DOL_DOCUMENT_ROOT . '/core/lib/date.lib.php';

	$GLOBALS['cfdimx_is_total_section'] = false;

	$pdf = pdf_getInstance();

	$pdf->SetMargins(10, 10, 10);

	$pdf->SetAutoPageBreak(true, 25);

	$pdf->SetPrintHeader(false);
	$pdf->setPrintFooter(false);

	$pdf->AddPage('P', 'LETTER');

	cfdimxCustomPdfHeader($object);
	cfdimxCustomPdfReceptor($object);
	if (empty($GLOBALS['cfdimx_is_total_section'])) {
		cfdimxDrawDetailTableHeader($object); // Dibujamos los encabezados de la tabla siempre
	}

	cfdimxCustomPdfDetail($object);

	$espacio_final = 10;
	cfdimxCheckAndAddPage($object, $espacio_final);

	cfdimxCustomPdfTotal($object);

	if ($object->element == 'payment') {
		cfdimxPaymentDetail($object);
	}

	cfdimxCustomPdfFooter();

	if ($object->statut == 0) {
		cfdimxCustomDraftText();
	}

	dol_mkdir($sPath);

	$pdf->Output($sPath . $sFile . ".pdf", 'F');

	cfdimx_log("Completed [{$object->id}][{$object->ref}]", LOG_DEBUG);
	cfdimx_log("Completed [{$object->id}]", LOG_INFO);

	return 1;
}
